# Delicate Two-Step Checkout

A WooCommerce plugin that provides a clean, two-step Classic Checkout experience with Google Places address autocomplete and courier serviceability/quote integration.

**Designed for South African e-commerce stores** (default country: ZA), but fully configurable for any country.

---

## What changed in 1.9.5

- **Live rates now fetched directly from Shiplogic** via the Delicate Courier Platform plugin's `dcp_shiplogic_fetch_rates()` helper. Previously the AJAX quote handler returned a stubbed `R0` response unless a third-party plugin hooked the `delicate_courier_quote` filter — which never happened in production, so the checkout always showed zero rates. The integration is now hard-coded and always-on as long as the **Delicate Courier Platform** plugin (v2.1.0+) is installed and configured.
- **Removed phantom setting**: the "Courier API Endpoint URL" admin field has been deleted. It was never read by any code path. The endpoint is now hard-coded inside the Delicate Courier Platform plugin (`https://webhooks2.delicatecourier.co.za`), so there is nothing for the merchant to misconfigure. The orphaned `dtsc_courier_endpoint` option is cleaned up on activation.
- **Unified logging**: every meaningful event in the quote handler is now written to **both** `dcp_log()` (visible in the Delicate Courier Platform debug log) **and** PHP's `error_log()` (visible in your WordPress/PHP error log). You can monitor checkout activity from either source.
- **Fixed broken tracking-reference injection**: the `http_request_args` filter that injects `custom_tracking_reference` into outgoing platform calls was checking against a function (`dcp_api_base_url()`) that no longer exists in the new courier plugin. It now checks against the `DCP_PLATFORM_BASE_URL` constant and the known production hosts (`webhooks2.delicatecourier.co.za`, defensive fallback to legacy `api2`).
- **The `delicate_courier_quote` filter still exists** as an extension point for advanced overrides — it just runs **after** the live rate has been fetched, so custom code can adjust the rate without having to fetch it themselves.

### Required: install Delicate Courier Platform 2.1.0+

This plugin now depends on the Delicate Courier Platform plugin being installed, activated, and configured (Store ID, Webhook Secret, Shiplogic Bearer Token, Shiplogic Account ID, Shiplogic Provider ID). Without it, the checkout will return an `unserviceable` response with a clear log line explaining why.

---

## Features

- **Two-step checkout flow**: Step 1 (Details & Delivery) → Step 2 (Payment & Order)
- **Google Places Autocomplete** on billing and/or shipping address fields
- **Live Shiplogic rates** via the Delicate Courier Platform plugin (hard-coded integration)
- **Responsive, modern design** with golden amber accent (matches Honey Bee Baker branding)
- **Ship vs. Collection** delivery method toggle
- **WooCommerce-compatible**: wraps the native checkout form, so payment gateways (Payfast, Yoco, etc.) work without modification
- **No build tooling**: vanilla JS, no webpack or npm required for the frontend

---

## Installation

1. Upload the `delicate-two-step-checkout` folder to `/wp-content/plugins/`
2. Activate the plugin in **Plugins → Installed Plugins**
3. Go to **WooCommerce → Two-Step Checkout** to configure settings

---

## Setup: Switch from Checkout Blocks to Classic Checkout

WooCommerce 8+ defaults to Checkout Blocks. This plugin requires the **Classic Checkout shortcode**.

### Step 1: Edit your Checkout page

1. Go to **Pages** in the WordPress admin
2. Find and edit your **Checkout** page
3. If using the Block Editor:
   - Delete the existing `Checkout` block
   - Add a **Shortcode** block
   - Enter: `[delicate_two_step_checkout]`
4. If using Classic Editor:
   - Replace all content with: `[delicate_two_step_checkout]`
5. Publish/Update the page

### Step 2: Verify WooCommerce Checkout page setting

1. Go to **WooCommerce → Settings → Advanced → Page Setup**
2. Ensure **Checkout page** is set to the page containing the shortcode
3. Save changes

### Step 3: Optional — Force Classic Checkout

If you still see the Block checkout rendering, add this to your theme's `functions.php`:

```php
add_filter( 'woocommerce_use_block_checkout', '__return_false' );
```

---

## Configure Google Places API

### Step 1: Get an API key

1. Go to [Google Cloud Console](https://console.cloud.google.com/)
2. Create or select a project
3. Enable the **Places API** and **Maps JavaScript API**
4. Go to **Credentials** → **Create Credentials** → **API Key**
5. Restrict the key:
   - **Application restrictions**: HTTP referrers → add your domain
   - **API restrictions**: Restrict to Places API + Maps JavaScript API

### Step 2: Enter the key in plugin settings

1. Go to **WooCommerce → Two-Step Checkout**
2. Enter your API key in **Google API Key**
3. Set **Country Restriction** to `za` (or your country code)
4. Enable autocomplete for billing and/or shipping
5. Save

---

## Courier Quote Integration

The plugin includes a stubbed courier quote system. To connect your real courier API, use the filter hook:

```php
add_filter( 'delicate_courier_quote', 'my_courier_quote', 10, 2 );

function my_courier_quote( $default_response, $payload ) {
    // $payload contains: address_1, address_2, city, state, postcode,
    //                    country, place_id, latitude, longitude,
    //                    first_name, last_name, email, phone

    // Call your courier API here...

    return array(
        'serviceable'  => true,
        'price'        => 127.00,
        'eta_minutes'  => 120,
        'status'       => 'ok',
        'message'      => 'Delivery in Pretoria (20km radius)',
    );
}
```

### Settings

- **Enable Courier Quoting**: When enabled, the customer must get a quote before proceeding to payment
- **Courier API Endpoint URL**: Optional — for direct HTTP integration
- **Courier API Timeout**: Request timeout in seconds

---

## Plugin Settings Reference

| Setting | Default | Description |
|---------|---------|-------------|
| Google API Key | (empty) | Your Google Maps Platform API key |
| Country Restriction | `za` | ISO 3166-1 alpha-2 code to restrict autocomplete results |
| Autocomplete on Billing | Yes | Attach Places autocomplete to billing address |
| Autocomplete on Shipping | Yes | Attach Places autocomplete to shipping address |
| Require Street Number | Yes | Validate that the selected address includes a street number |
| Require Address Line 2 | No | Require unit/apartment/complex number (useful for ZA) |
| Enable Courier Quoting | No | Enable the delivery quote step |
| Courier API Endpoint | (empty) | URL for external courier API |
| Courier API Timeout | 15 | Timeout in seconds |

---

## Testing Checklist

### Basic Flow
- [ ] Cart → Checkout page loads with Step 1 visible, Step 2 hidden
- [ ] Step indicator shows Step 1 as active
- [ ] Fill in email, phone, name, address → "Continue to payment" proceeds to Step 2
- [ ] Step 2 shows shipping options, payment methods, place order button
- [ ] "Back to details" returns to Step 1 with fields preserved
- [ ] Order submits successfully via WooCommerce

### Google Places
- [ ] Typing in address field shows autocomplete dropdown
- [ ] Selecting an address fills city, state, postcode, country fields
- [ ] Hidden fields (place_id, lat, lng) are populated
- [ ] Manual typing still works without autocomplete
- [ ] "Require street number" validation works when enabled

### Delivery
- [ ] "Ship" / "Collection" toggle shows/hides address fields
- [ ] "Same address for billing" checkbox shows/hides billing fields
- [ ] Shipping methods display correctly in Step 2

### Payment
- [ ] Payfast gateway renders and is selectable
- [ ] Yoco gateway renders and is selectable
- [ ] Payment gateway toggle shows/hides payment fields
- [ ] Order processes through the selected gateway

### Responsive
- [ ] Mobile layout: single column, sidebar on top
- [ ] Tablet: responsive grid
- [ ] All buttons are touch-friendly (min 44px tap target)

### Courier Quote (when enabled)
- [ ] "Continue to payment" triggers AJAX quote request
- [ ] Loading spinner shows during request
- [ ] Successful quote unlocks Step 2
- [ ] Failed quote shows error and keeps Step 2 locked
- [ ] Quote data saved to order meta

---

## Troubleshooting

### Checkout page shows blocks instead of the custom checkout
- Make sure you replaced the Checkout block with the `[delicate_two_step_checkout]` shortcode
- Add `add_filter('woocommerce_use_block_checkout', '__return_false');` to functions.php

### Google Places autocomplete not working
- Check browser console for API errors
- Verify the API key is correct and has Places API + Maps JavaScript API enabled
- Check key restrictions match your domain
- Ensure the country code is valid (lowercase, 2 letters)

### Payment gateways not showing
- Make sure WooCommerce payment gateways are enabled under WooCommerce → Settings → Payments
- Cart must require payment (total > 0)

### Styling conflicts with theme
- The plugin uses scoped CSS under `.dtsc-checkout-wrapper` to avoid conflicts
- If needed, increase specificity or add `!important` overrides in your theme

### Order meta not showing in admin
- Check the order edit screen — "Delicate Checkout Data" panel appears below shipping address
- Place ID and coordinates only save if Google Places was used

---

## File Structure

```
delicate-two-step-checkout/
├── delicate-two-step-checkout.php    # Main plugin file
├── README.md                         # This file
├── includes/
│   ├── class-admin-settings.php      # Admin settings page
│   ├── class-frontend-checkout.php   # Shortcode rendering
│   ├── class-ajax-quote.php          # AJAX courier quote handler
│   └── class-order-meta.php          # Order meta save/display
└── assets/
    ├── css/
    │   └── checkout.css              # All checkout styles
    └── js/
        ├── address-autocomplete.js   # Google Places integration
        └── two-step-checkout.js      # Step logic & validation
```

---

## License

GPL-2.0+
