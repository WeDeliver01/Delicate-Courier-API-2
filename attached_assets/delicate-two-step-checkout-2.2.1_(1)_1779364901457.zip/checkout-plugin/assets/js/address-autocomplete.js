/**
 * Delicate Checkout — Google Places Autocomplete
 * v1.3.0 — Rewritten for speed and single-select reliability.
 *
 * Fixes over v1.2.7:
 *  - Removed MutationObserver on body (was killing page performance)
 *  - Removed 50ms polling interval for icon removal (CSS-only now)
 *  - Mobile fix uses mousedown instead of touchstart capture phase
 *  - fillAddress has a _filling guard to prevent double-fills
 *  - .trigger('change') on all fields so WC detects values first time
 *  - Polling for Google API reduced from 20s to 5s with faster interval
 */

window._dtscGoogleLoaded = false;
window.dtscGoogleReady = function () {
    window._dtscGoogleLoaded = true;
    if (window.DTSC_Autocomplete && typeof window.DTSC_Autocomplete.onAPIReady === 'function') {
        window.DTSC_Autocomplete.onAPIReady();
    }
};

(function ($) {
    'use strict';

    var AC = window.DTSC_Autocomplete = {

        instances: {},
        initialized: false,
        _filling: false,

        componentMap: {
            street_number:               'short_name',
            route:                       'long_name',
            sublocality_level_1:         'long_name',
            sublocality:                 'long_name',
            locality:                    'long_name',
            administrative_area_level_1: 'short_name',
            administrative_area_level_2: 'long_name',
            country:                     'short_name',
            postal_code:                 'short_name',
        },

        onAPIReady: function () {
            if (this.initialized) return;
            this.initialized = true;

            this.injectStyles();
            this.blockDuplicateGoogleMaps();
            this.attachAll();

            var self = this;
            $(document.body).on('updated_checkout', function () {
                setTimeout(function () { self.reattachIfNeeded(); }, 200);
            });
        },

        blockDuplicateGoogleMaps: function () {
            if (typeof MutationObserver === 'undefined') return;
            var observer = new MutationObserver(function (mutations) {
                for (var i = 0; i < mutations.length; i++) {
                    var nodes = mutations[i].addedNodes;
                    for (var j = 0; j < nodes.length; j++) {
                        var node = nodes[j];
                        if (node.tagName === 'SCRIPT' && node.src &&
                            node.src.indexOf('maps.googleapis.com/maps/api/js') !== -1 &&
                            node.src.indexOf('dtscGoogleReady') === -1) {
                            node.parentNode.removeChild(node);
                        }
                    }
                }
            });
            observer.observe(document.head, { childList: true });
            observer.observe(document.body, { childList: true });
        },

        attachAll: function () {
            if (typeof dtscAutocomplete === 'undefined') return;
            if (dtscAutocomplete.autocompleteShipping === 'yes') this.attach('shipping');
            if (dtscAutocomplete.autocompleteBilling === 'yes') this.attach('billing');
        },

        reattachIfNeeded: function () {
            if (typeof dtscAutocomplete === 'undefined') return;
            var prefixes = [];
            if (dtscAutocomplete.autocompleteShipping === 'yes') prefixes.push('shipping');
            if (dtscAutocomplete.autocompleteBilling === 'yes') prefixes.push('billing');
            for (var i = 0; i < prefixes.length; i++) {
                var p = prefixes[i];
                var input = document.getElementById(p + '_address_1');
                if (!input) continue;
                if (this.instances[p + '_el'] && this.instances[p + '_el'] === input) continue;
                this.attach(p);
            }
        },

        attach: function (prefix) {
            var input = document.getElementById(prefix + '_address_1');
            if (!input) return;

            var self = this;
            var country = (typeof dtscAutocomplete !== 'undefined') ? dtscAutocomplete.countryRestriction : '';

            var opts = {
                types: ['address'],
                fields: ['address_components', 'geometry', 'place_id', 'formatted_address'],
            };
            if (country && country.length === 2) {
                opts.componentRestrictions = { country: country };
            }

            input.setAttribute('autocomplete', 'off');

            if (this.instances[prefix]) {
                try { google.maps.event.clearInstanceListeners(this.instances[prefix]); } catch (e) {}
            }

            try {
                var autocomplete = new google.maps.places.Autocomplete(input, opts);
                this.instances[prefix] = autocomplete;
                this.instances[prefix + '_el'] = input;

                // Prevent Enter from submitting form while dropdown is open
                input.addEventListener('keydown', function (e) {
                    if (e.keyCode === 13) {
                        var pac = document.querySelector('.pac-container');
                        if (pac && pac.offsetParent !== null) {
                            e.preventDefault();
                        }
                    }
                });

                // Core handler — fires when user clicks/taps a suggestion (desktop)
                autocomplete.addListener('place_changed', function () {
                    var place = autocomplete.getPlace();
                    if (place && place.address_components) {
                        self.fillAddress(prefix, place);
                    }
                });

                // MOBILE FIX: On iOS, tapping a pac-item blurs the input before
                // the click registers, so Google hides the dropdown and place_changed
                // never fires. We use mousedown (fires before blur) to catch this.
                this.attachMobileFix(prefix);

            } catch (err) {
                console.error('[DTSC] Autocomplete failed:', prefix, err.message);
            }
        },

        /**
         * Mobile fix using mousedown on pac-items.
         * mousedown fires before blur on ALL platforms.
         * If Google's place_changed fires naturally (desktop), the _filling
         * guard prevents a double fill. If it doesn't fire (mobile), we
         * resolve the address manually after a short timeout.
         */
        attachMobileFix: function (prefix) {
            var self = this;

            // Only bind once (event delegation handles all pac-items)
            if (this._mobileBound) return;
            this._mobileBound = true;

            $(document).on('mousedown touchend', '.pac-item', function (e) {
                if (self._filling) return;

                // Extract text from the pac-item
                var $item = $(this);
                var queryText = $item.find('.pac-item-query').text().trim();
                var restText = '';
                $item.contents().each(function () {
                    if (this.nodeType === 3) { // text node
                        var t = this.textContent.trim();
                        if (t) restText += ' ' + t;
                    }
                });
                $item.find('span').not('.pac-item-query,.pac-icon,.pac-icon-marker,.pac-icon-search,.pac-matched').each(function () {
                    var t = $(this).text().trim();
                    if (t && t !== queryText) restText = ' ' + t;
                });
                var fullText = (queryText + restText).replace(/\s+/g, ' ').trim();

                // Figure out which input is focused
                var activePrefix = 'shipping';
                var active = document.activeElement;
                if (active && active.id === 'billing_address_1') activePrefix = 'billing';
                if (active && active.id === 'shipping_address_1') activePrefix = 'shipping';

                // Set value for immediate visual feedback
                $('#' + activePrefix + '_address_1').val(fullText);

                // Wait briefly to see if Google's place_changed fires
                var filledByGoogle = false;
                var origFill = self.fillAddress.bind(self);
                self._fillOverride = function () {
                    filledByGoogle = true;
                };

                setTimeout(function () {
                    delete self._fillOverride;
                    if (!filledByGoogle && !self._filling) {
                        self.resolveFromText(fullText, activePrefix);
                    }
                }, 350);
            });
        },

        /**
         * Fallback resolver: text → predictions → place details → fillAddress
         */
        resolveFromText: function (text, prefix) {
            var self = this;
            var country = (typeof dtscAutocomplete !== 'undefined') ? dtscAutocomplete.countryRestriction : '';

            var service = new google.maps.places.AutocompleteService();
            var request = { input: text, types: ['address'] };
            if (country && country.length === 2) {
                request.componentRestrictions = { country: country };
            }

            service.getPlacePredictions(request, function (predictions, status) {
                if (status !== google.maps.places.PlacesServiceStatus.OK || !predictions || !predictions.length) return;

                var placesService = new google.maps.places.PlacesService(document.createElement('div'));
                placesService.getDetails({
                    placeId: predictions[0].place_id,
                    fields: ['address_components', 'geometry', 'place_id', 'formatted_address']
                }, function (place, s) {
                    if (s === google.maps.places.PlacesServiceStatus.OK && place) {
                        self.fillAddress(prefix, place);
                    }
                });
            });
        },

        /**
         * Fill checkout fields from place data.
         * The _filling guard prevents double-fills when both place_changed
         * and the mobile fix fire for the same selection.
         */
        fillAddress: function (prefix, place) {
            // If the mobile fix override is active, signal and bail
            if (this._fillOverride) {
                this._fillOverride();
                // Don't return — still fill the address
            }

            if (this._filling) return;
            this._filling = true;
            var self = this;

            var c = {};
            for (var i = 0; i < place.address_components.length; i++) {
                var comp = place.address_components[i];
                for (var j = 0; j < comp.types.length; j++) {
                    var t = comp.types[j];
                    if (this.componentMap[t]) {
                        c[t] = (this.componentMap[t] === 'short_name') ? comp.short_name : comp.long_name;
                    }
                }
            }

            var streetNum = c.street_number || '';
            var route = c.route || '';
            var addr = streetNum ? (streetNum + ' ' + route) : route;
            var city = c.locality || c.sublocality_level_1 || c.sublocality || c.administrative_area_level_2 || '';
            var state = c.administrative_area_level_1 || '';
            var zip = c.postal_code || '';
            var country = c.country || '';

            // Set values + trigger change so WC detects them immediately
            var $addr1 = $('#' + prefix + '_address_1');
            if (addr) { $addr1.val(addr).trigger('change').trigger('input'); }

            $('#' + prefix + '_city').val(city).trigger('change');
            $('#' + prefix + '_postcode').val(zip).trigger('change');

            var $state = $('#' + prefix + '_state');
            if ($state.is('select')) {
                if ($state.find('option[value="' + state + '"]').length) {
                    $state.val(state).trigger('change');
                }
            } else if (state) {
                $state.val(state).trigger('change');
            }

            if (country) {
                $('#' + prefix + '_country').val(country.toUpperCase()).trigger('change');
            }

            if (place.geometry && place.geometry.location) {
                var lat = typeof place.geometry.location.lat === 'function'
                    ? place.geometry.location.lat() : place.geometry.location.lat;
                var lng = typeof place.geometry.location.lng === 'function'
                    ? place.geometry.location.lng() : place.geometry.location.lng;
                $('#' + prefix + '_latitude').val(lat);
                $('#' + prefix + '_longitude').val(lng);
            }
            if (place.place_id) {
                $('#' + prefix + '_place_id').val(place.place_id);
            }

            // Street number validation
            if (typeof dtscAutocomplete !== 'undefined' &&
                dtscAutocomplete.requireStreetNumber === 'yes' && !streetNum) {
                var $row = $addr1.closest('.form-row');
                $row.addClass('woocommerce-invalid');
                $row.find('.dtsc-field-error').remove();
                $row.append('<span class="dtsc-field-error">Please include a street number.</span>');
            }

            // Fetch delivery quote (debounced)
            if (prefix === 'shipping' && typeof DTSC !== 'undefined' && DTSC.fetchDeliveryQuote) {
                setTimeout(function () { DTSC.fetchDeliveryQuote(); }, 200);
            }

            // Release fill guard
            setTimeout(function () { self._filling = false; }, 150);
        },

        getCoordinates: function (prefix) {
            return {
                placeId:   $('#' + prefix + '_place_id').val() || '',
                latitude:  parseFloat($('#' + prefix + '_latitude').val()) || 0,
                longitude: parseFloat($('#' + prefix + '_longitude').val()) || 0,
            };
        },

        /**
         * CSS-only icon removal — no MutationObserver, no polling.
         */
        injectStyles: function () {
            var css =
                '.pac-icon,.pac-icon-marker,.pac-icon-search{' +
                    'display:none!important;width:0!important;height:0!important;' +
                    'padding:0!important;margin:0!important;' +
                    'background:none!important;background-image:none!important;' +
                '}' +
                '.pac-item{padding:10px 14px!important;font-size:14px!important;cursor:pointer!important;}' +
                '.pac-container{z-index:999999!important;border-radius:4px;box-shadow:0 2px 6px rgba(0,0,0,.15);}' +
                '.pac-item:hover,.pac-item:active{background:#f5f5f5!important;}';
            var el = document.createElement('style');
            el.textContent = css;
            document.head.appendChild(el);
        }
    };

    /* ── DOM Ready ─── */
    $(function () {
        $(document).on('click', '.dtsc-toggle-address2, #dtsc-toggle-address2', function (e) {
            e.preventDefault();
            $(this).closest('.dtsc-address2-row').find('.dtsc-address2-wrapper').slideDown(200);
            $(this).hide();
        });

        if (window._dtscGoogleLoaded) {
            AC.onAPIReady();
        } else if (typeof google !== 'undefined' && google.maps && google.maps.places) {
            AC.onAPIReady();
        } else {
            var attempts = 0;
            var check = setInterval(function () {
                attempts++;
                if (typeof google !== 'undefined' && google.maps && google.maps.places) {
                    clearInterval(check);
                    AC.onAPIReady();
                } else if (attempts > 50) {
                    clearInterval(check);
                    console.error('[DTSC] Google Maps API failed to load');
                }
            }, 100);
        }
    });

})(jQuery);
