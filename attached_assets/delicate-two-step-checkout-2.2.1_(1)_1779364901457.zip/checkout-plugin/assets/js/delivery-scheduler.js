/**
 * Delivery Scheduler for Delicate Two-Step Checkout
 *
 * Uses appointment dates from cart items to determine the earliest
 * available delivery date. Earliest appointment minus 1 hour = earliest
 * delivery slot. Time slots are 2-hour intervals.
 */
(function ($) {
    'use strict';

    var DS = window.DTSC_Scheduler = {};

    var cfg;
    var state = {
        selectedDate: null,
        selectedTime: null,
        splitDelivery: false,
        viewMonth: null,
        earliestDate: null,
        earliestTime: null,
    };

    /* ── Initialise ──────────────────────────────────────────── */
    DS.init = function () {
        cfg = window.dtscScheduler || {};
        if (!cfg.enabled || cfg.enabled === 'no') {
            console.log('[DTSC Scheduler] Disabled, skipping init');
            return;
        }

        state.earliestDate = cfg.earliestDate || '';
        state.earliestTime = cfg.earliestTime || '';

        var now = new Date();
        var todayStr = DS.formatDate(now);

        if (!state.earliestDate) {
            // No appointment date found — use tomorrow as default
            var tomorrow = new Date(now.getTime() + 86400000);
            state.earliestDate = DS.formatDate(tomorrow);
            state.earliestTime = '06:00';
        } else {
            // Ensure earliestDate is not in the past
            if (state.earliestDate < todayStr) {
                state.earliestDate = todayStr;
            }
        }

        state.viewMonth = new Date(state.earliestDate + 'T12:00:00');
        state.viewMonth.setDate(1);

        // Parse blocked days once at init
        DS._blockedDayNums = DS.parseBlockedDays(cfg.blockedDays);
        DS._blockedDateStrs = DS.parseBlockedDates(cfg.blockedDates);
        DS._maxAdvance = parseInt(cfg.maxAdvanceDays, 10);
        if (isNaN(DS._maxAdvance) || DS._maxAdvance < 1) DS._maxAdvance = 90;

        console.log('[DTSC Scheduler] Config:', {
            earliestDate: state.earliestDate,
            earliestTime: state.earliestTime,
            blockedDays: DS._blockedDayNums,
            blockedDates: DS._blockedDateStrs,
            maxAdvance: DS._maxAdvance,
            appointmentDates: cfg.appointmentDates,
            timeSlotStart: cfg.timeSlotStart,
            timeSlotEnd: cfg.timeSlotEnd,
        });

        DS.buildUI();
        DS.bindEvents();

        // Find the first actually available date (not just earliestDate, which might be blocked)
        var searchDate = new Date(state.earliestDate + 'T12:00:00');
        var maxSearch = new Date(now.getTime() + DS._maxAdvance * 86400000);
        var foundDate = null;
        while (searchDate <= maxSearch) {
            if (DS.isDateAvailable(searchDate)) {
                foundDate = DS.formatDate(searchDate);
                break;
            }
            searchDate.setDate(searchDate.getDate() + 1);
        }

        if (foundDate) {
            // If there's a preselected date (from appointment) and it's available, use it
            var preselected = cfg.preselectedDate || '';
            if (preselected && preselected >= foundDate) {
                var preDate = new Date(preselected + 'T12:00:00');
                if (DS.isDateAvailable(preDate)) {
                    state.selectedDate = preselected;
                    state.viewMonth = new Date(preselected + 'T12:00:00');
                    state.viewMonth.setDate(1);
                } else {
                    state.selectedDate = foundDate;
                    state.viewMonth = new Date(foundDate + 'T12:00:00');
                    state.viewMonth.setDate(1);
                }
            } else {
                state.selectedDate = foundDate;
                state.viewMonth = new Date(foundDate + 'T12:00:00');
                state.viewMonth.setDate(1);
            }
        } else {
            state.selectedDate = state.earliestDate;
        }

        DS.renderCalendar();
        DS.renderTimeSlots();
        DS.updateSelection();
    };

    /* ── Parse helpers ───────────────────────────────────────── */
    DS.parseBlockedDays = function (val) {
        // val can be '0', '0,6', '', null, undefined, or even a number
        if (val === null || val === undefined || val === '') return [];
        var str = String(val);
        if (str.trim() === '') return [];
        return str.split(',').map(function (x) {
            return parseInt(x.trim(), 10);
        }).filter(function (x) {
            return !isNaN(x) && x >= 0 && x <= 6;
        });
    };

    DS.parseBlockedDates = function (val) {
        if (!val || String(val).trim() === '') return [];
        return String(val).split(',').map(function (x) {
            return x.trim();
        }).filter(function (x) {
            return x.length > 0;
        });
    };

    DS.formatDate = function (d) {
        var y = d.getFullYear();
        var m = String(d.getMonth() + 1).padStart(2, '0');
        var day = String(d.getDate()).padStart(2, '0');
        return y + '-' + m + '-' + day;
    };

    DS.formatDateDisplay = function (dateStr) {
        var d = new Date(dateStr + 'T12:00:00');
        var days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
        var months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
        return days[d.getDay()] + ', ' + d.getDate() + ' ' + months[d.getMonth()] + ' ' + d.getFullYear();
    };

    DS.formatTime12h = function (timeStr) {
        var parts = timeStr.split(':');
        var h = parseInt(parts[0], 10);
        var m = parts[1];
        var displayH = h > 12 ? h - 12 : (h === 0 ? 12 : h);
        var ampm = h >= 12 ? 'PM' : 'AM';
        return displayH + ':' + m + ' ' + ampm;
    };

    DS.timeToMinutes = function (timeStr) {
        var parts = timeStr.split(':');
        return parseInt(parts[0], 10) * 60 + parseInt(parts[1], 10);
    };

    /* ── Date availability ───────────────────────────────────── */
    DS.isDateAvailable = function (dateObj) {
        var check = new Date(dateObj.getTime());
        check.setHours(0, 0, 0, 0);

        // Before earliest date?
        var earliest = new Date(state.earliestDate + 'T00:00:00');
        earliest.setHours(0, 0, 0, 0);
        if (check.getTime() < earliest.getTime()) return false;

        // Beyond max advance days from today?
        var today = new Date();
        today.setHours(0, 0, 0, 0);
        var daysDiff = Math.round((check.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
        if (daysDiff > DS._maxAdvance) return false;

        // Blocked day of week? (0=Sun, 1=Mon, ... 6=Sat)
        if (DS._blockedDayNums.indexOf(check.getDay()) !== -1) return false;

        // Blocked specific date?
        var dateStr = DS.formatDate(check);
        if (DS._blockedDateStrs.indexOf(dateStr) !== -1) return false;

        return true;
    };

    /* ── Time availability ───────────────────────────────────── */
    DS.isTimeAvailable = function (timeStr) {
        if (!state.selectedDate) return false;

        var slotMinutes = DS.timeToMinutes(timeStr);
        var slotDuration = parseInt(cfg.timeSlotInterval, 10) || 120;
        var slotEndMinutes = slotMinutes + slotDuration;

        // If the selected date is TODAY, restrict based on current time.
        // Block the slot only if it has already ENDED — so a customer can
        // still book the 15:30 slot even if it is currently 15:45,
        // as long as the slot window hasn't fully passed.
        var todayStr = DS.formatDate(new Date());
        if (state.selectedDate === todayStr) {
            var now = new Date();
            var nowMinutes = now.getHours() * 60 + now.getMinutes();
            // Block only when the entire slot window is in the past
            if (slotEndMinutes <= nowMinutes) return false;
        }

        // On the earliest date, block slots whose window ends before
        // the earliest allowed time (appointment lead time). A slot is
        // still bookable if it overlaps with or starts after earliestTime.
        if (state.earliestTime && state.selectedDate === state.earliestDate) {
            var earliestMinutes = DS.timeToMinutes(state.earliestTime);
            // Block the slot only if it ends before the earliest time
            if (slotEndMinutes <= earliestMinutes) return false;
        }

        return true;
    };

    /* ── Build UI ────────────────────────────────────────────── */
    DS.buildUI = function () {
        var $section = $('#dtsc-delivery-schedule-section');
        if (!$section.length) {
            console.warn('[DTSC Scheduler] Section #dtsc-delivery-schedule-section not found');
            return;
        }

        var leadInfo = '';
        if (cfg.i18n && cfg.i18n.leadTimeNotice) {
            leadInfo = '<div class="dtsc-lead-info">';
            leadInfo += '<p class="dtsc-lead-info-text">';
            leadInfo += '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg> ';
            leadInfo += cfg.i18n.leadTimeNotice;
            leadInfo += '</p></div>';
        }

        var html = leadInfo;
        html += '<div class="dtsc-scheduler-calendar-wrap">';
        html += '  <div class="dtsc-calendar" id="dtsc-calendar"></div>';
        html += '</div>';
        html += '<div class="dtsc-scheduler-time-wrap">';
        html += '  <label class="dtsc-time-label">' + (cfg.i18n ? cfg.i18n.selectTime : 'Select a time slot') + '</label>';
        html += '  <div class="dtsc-time-slots" id="dtsc-time-slots"></div>';
        html += '</div>';
        html += '<div class="dtsc-scheduler-selection" id="dtsc-scheduler-selection" style="display:none;"></div>';

        if (cfg.hasMultipleDates || cfg.cartItemCount > 1) {
            var splitNotice = cfg.i18n ? cfg.i18n.splitDeliveryNotice : 'Split deliveries will be arranged by the bakery at the same courier rate per delivery.';
            html += '<div class="dtsc-split-delivery-wrap"' + (cfg.hasMultipleDates ? '' : '') + '>';
            if (cfg.hasMultipleDates) {
                html += '  <div class="dtsc-split-info" style="padding:10px 14px;background:#FFF8E1;border:1px solid #FFD54F;border-radius:6px;margin-bottom:10px;font-size:13px;">';
                html += '    ⚠️ Your cart has items with different appointment dates. You can choose to have them delivered together on the earliest date, or select split delivery below.';
                html += '  </div>';
            }
            html += '  <div class="dtsc-split-toggle"><label class="dtsc-checkbox-label">';
            html += '    <input type="checkbox" id="dtsc-split-delivery" name="dtsc_split_delivery" value="1" />';
            html += '    ' + (cfg.i18n ? cfg.i18n.splitDeliveryLabel : 'I need items delivered on different dates');
            html += '  </label></div>';
            html += '  <div class="dtsc-split-notice" id="dtsc-split-notice" style="display:none;">';
            html += '    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>';
            html += '    <span>' + splitNotice + '</span>';
            html += '  </div></div>';
        }

        html += '<input type="hidden" id="dtsc_delivery_date" name="dtsc_delivery_date" value="" />';
        html += '<input type="hidden" id="dtsc_delivery_time" name="dtsc_delivery_time" value="" />';

        $section.find('.dtsc-scheduler-content').html(html);
    };

    /* ── Render calendar ─────────────────────────────────────── */
    DS.renderCalendar = function () {
        var $cal = $('#dtsc-calendar');
        if (!$cal.length) return;

        var year = state.viewMonth.getFullYear();
        var month = state.viewMonth.getMonth();
        var monthNames = ['January', 'February', 'March', 'April', 'May', 'June',
            'July', 'August', 'September', 'October', 'November', 'December'];
        var dayNames = ['Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa', 'Su'];

        var html = '<div class="dtsc-cal-header">';
        html += '<button type="button" class="dtsc-cal-prev" id="dtsc-cal-prev">&lsaquo;</button>';
        html += '<span class="dtsc-cal-month-year">' + monthNames[month] + ' ' + year + '</span>';
        html += '<button type="button" class="dtsc-cal-next" id="dtsc-cal-next">&rsaquo;</button>';
        html += '</div>';

        html += '<div class="dtsc-cal-grid">';
        for (var i = 0; i < 7; i++) {
            html += '<div class="dtsc-cal-day-name">' + dayNames[i] + '</div>';
        }

        var firstDay = new Date(year, month, 1).getDay();
        var startOffset = (firstDay === 0) ? 6 : firstDay - 1;
        var daysInMonth = new Date(year, month + 1, 0).getDate();

        for (var j = 0; j < startOffset; j++) {
            html += '<div class="dtsc-cal-day dtsc-cal-day-empty"></div>';
        }

        var availCount = 0;
        for (var d = 1; d <= daysInMonth; d++) {
            var thisDate = new Date(year, month, d, 12, 0, 0); // noon to avoid DST issues
            var dateStr = DS.formatDate(thisDate);
            var available = DS.isDateAvailable(thisDate);
            var isSelected = (state.selectedDate === dateStr);
            var isToday = (dateStr === DS.formatDate(new Date()));

            if (available) availCount++;

            var hasAppointment = false;
            if (cfg.appointmentDates && cfg.appointmentDates.length) {
                for (var a = 0; a < cfg.appointmentDates.length; a++) {
                    if (cfg.appointmentDates[a].date === dateStr) {
                        hasAppointment = true;
                        break;
                    }
                }
            }

            var cls = 'dtsc-cal-day';
            if (!available) cls += ' dtsc-cal-day-disabled';
            if (isSelected) cls += ' dtsc-cal-day-selected';
            if (isToday) cls += ' dtsc-cal-day-today';
            if (hasAppointment) cls += ' dtsc-cal-day-appointment';

            html += '<div class="' + cls + '" data-date="' + dateStr + '"';
            if (available) html += ' role="button" tabindex="0"';
            html += '>' + d;
            if (hasAppointment) html += '<span class="dtsc-appt-dot"></span>';
            html += '</div>';
        }

        html += '</div>';
        $cal.html(html);

        console.log('[DTSC Scheduler] Rendered', monthNames[month], year, '— available days:', availCount, '/ total:', daysInMonth);
    };

    /* ── Render time slots (2-hour intervals within working hours) ── */
    DS.renderTimeSlots = function () {
        var $wrap = $('#dtsc-time-slots');
        if (!$wrap.length) return;

        var startStr = cfg.timeSlotStart || '08:30';
        var endStr = cfg.timeSlotEnd || '16:30';

        // Saturday override: store closes at 11am, deliveries until 12pm
        if (state.selectedDate) {
            var selDate = new Date(state.selectedDate + 'T12:00:00');
            if (selDate.getDay() === 6) { // Saturday
                var satEnd = cfg.saturdayEndTime || '12:00';
                endStr = satEnd;
            }
        }

        // Handle both "8:30" and "830" formats
        var startMin, endMin;
        if (String(startStr).indexOf(':') !== -1) {
            var sp = String(startStr).split(':');
            startMin = parseInt(sp[0], 10) * 60 + parseInt(sp[1] || 0, 10);
        } else {
            var sv = parseInt(startStr, 10);
            startMin = Math.floor(sv / 100) * 60 + (sv % 100);
        }
        if (String(endStr).indexOf(':') !== -1) {
            var ep = String(endStr).split(':');
            endMin = parseInt(ep[0], 10) * 60 + parseInt(ep[1] || 0, 10);
        } else {
            var ev = parseInt(endStr, 10);
            endMin = Math.floor(ev / 100) * 60 + (ev % 100);
        }

        var html = '';

        for (var totalMin = startMin; totalMin < endMin; totalMin += 120) {
            var h = Math.floor(totalMin / 60);
            var m = totalMin % 60;
            var timeStr = String(h).padStart(2, '0') + ':' + String(m).padStart(2, '0');

            var slotEnd = Math.min(totalMin + 120, endMin);
            var endH = Math.floor(slotEnd / 60);
            var endM = slotEnd % 60;
            var endTimeStr = String(endH).padStart(2, '0') + ':' + String(endM).padStart(2, '0');

            var available = DS.isTimeAvailable(timeStr);

            var cls = 'dtsc-time-slot';
            if (!available) cls += ' dtsc-time-slot-disabled';
            if (state.selectedTime === timeStr) cls += ' dtsc-time-slot-selected';

            html += '<button type="button" class="' + cls + '" data-time="' + timeStr + '"';
            if (!available) html += ' disabled';
            html += '>';
            html += DS.formatTime12h(timeStr) + ' \u2013 ' + DS.formatTime12h(endTimeStr);
            html += '</button>';
        }

        $wrap.html(html);
    };

    /* ── Update selection display & hidden fields ────────────── */
    DS.updateSelection = function () {
        var $sel = $('#dtsc-scheduler-selection');
        var $dateInput = $('#dtsc_delivery_date');
        var $timeInput = $('#dtsc_delivery_time');

        if (state.selectedDate && state.selectedTime) {
            var startMinutes = DS.timeToMinutes(state.selectedTime);
            var endMinutes = startMinutes + 120;
            var endH = Math.floor(endMinutes / 60);
            var endM = endMinutes % 60;
            var endTimeStr = String(endH).padStart(2, '0') + ':' + String(endM).padStart(2, '0');

            var displayStart = DS.formatTime12h(state.selectedTime);
            var displayEnd = DS.formatTime12h(endTimeStr);

            var scheduledLabel = (cfg.i18n && cfg.i18n.scheduledFor) ? cfg.i18n.scheduledFor : 'Delivery scheduled for';

            $sel.html(
                '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>' +
                '<span>' + scheduledLabel + ' <strong>' + DS.formatDateDisplay(state.selectedDate) + '</strong> between <strong>' + displayStart + ' \u2013 ' + displayEnd + '</strong></span>'
            ).show();

            $dateInput.val(state.selectedDate);
            $timeInput.val(state.selectedTime + ' - ' + endTimeStr);

            console.log('[DTSC Scheduler] Selection:', state.selectedDate, state.selectedTime, '-', endTimeStr);
        } else {
            $sel.hide();
            $dateInput.val('');
            $timeInput.val('');
        }
    };

    /* ── Events ──────────────────────────────────────────────── */
    DS.bindEvents = function () {

        // Calendar navigation
        $(document).on('click.dtsc-scheduler', '#dtsc-cal-prev', function (e) {
            e.preventDefault();
            e.stopPropagation();
            state.viewMonth.setMonth(state.viewMonth.getMonth() - 1);
            DS.renderCalendar();
        });

        $(document).on('click.dtsc-scheduler', '#dtsc-cal-next', function (e) {
            e.preventDefault();
            e.stopPropagation();
            state.viewMonth.setMonth(state.viewMonth.getMonth() + 1);
            DS.renderCalendar();
        });

        // Date selection — use native addEventListener for maximum reliability
        // jQuery delegated events can be blocked by stopImmediatePropagation elsewhere
        document.addEventListener('click', function (e) {
            var dayEl = e.target.closest('.dtsc-cal-day');
            if (!dayEl) return;

            // Skip disabled and empty days
            if (dayEl.classList.contains('dtsc-cal-day-disabled') ||
                dayEl.classList.contains('dtsc-cal-day-empty')) {
                return;
            }

            e.preventDefault();

            var dateVal = dayEl.getAttribute('data-date');
            console.log('[DTSC Scheduler] Day clicked:', dateVal);

            if (!dateVal || dateVal.length !== 10) {
                console.warn('[DTSC Scheduler] Invalid date value:', dateVal);
                return;
            }

            state.selectedDate = dateVal;
            state.selectedTime = null;
            DS.renderCalendar();
            DS.renderTimeSlots();
            DS.updateSelection();
        }, false);

        // Time slot selection — also native for reliability
        document.addEventListener('click', function (e) {
            var slotEl = e.target.closest('.dtsc-time-slot');
            if (!slotEl) return;

            if (slotEl.classList.contains('dtsc-time-slot-disabled') || slotEl.disabled) {
                return;
            }

            e.preventDefault();

            var timeVal = slotEl.getAttribute('data-time');
            console.log('[DTSC Scheduler] Time slot clicked:', timeVal);

            if (!timeVal) return;

            state.selectedTime = timeVal;

            // Update visual state
            var allSlots = document.querySelectorAll('.dtsc-time-slot');
            for (var i = 0; i < allSlots.length; i++) {
                allSlots[i].classList.remove('dtsc-time-slot-selected');
            }
            slotEl.classList.add('dtsc-time-slot-selected');

            DS.updateSelection();
        }, false);

        // Split delivery toggle
        $(document).on('change.dtsc-scheduler', '#dtsc-split-delivery', function () {
            state.splitDelivery = $(this).is(':checked');
            $('#dtsc-split-notice').toggle(state.splitDelivery);
        });

        console.log('[DTSC Scheduler] Events bound (native click handlers)');
    };

    /* ── Validation ─────────────────────────────────────────── */
    DS.validate = function () {
        if (!cfg || !cfg.enabled || cfg.enabled !== 'yes') return true;
        if (!cfg.required || cfg.required !== 'yes') return true;

        var valid = true;
        DS.clearError();

        if (!state.selectedDate) {
            DS.showError(cfg.i18n ? cfg.i18n.dateRequired : 'Please select a delivery date.');
            valid = false;
        }
        if (!state.selectedTime) {
            DS.showError(cfg.i18n ? cfg.i18n.timeRequired : 'Please select a delivery time slot.');
            valid = false;
        }

        return valid;
    };

    DS.showError = function (msg) {
        var $section = $('#dtsc-delivery-schedule-section');
        $section.find('.dtsc-scheduler-error').remove();
        $section.append('<div class="dtsc-scheduler-error">' + msg + '</div>');
    };

    DS.clearError = function () {
        $('#dtsc-delivery-schedule-section .dtsc-scheduler-error').remove();
    };

    /* ── Get current selection (for external access) ────────── */
    DS.getSelection = function () {
        return {
            date: state.selectedDate || '',
            time: state.selectedTime || '',
        };
    };

    /* ── DOM Ready ──────────────────────────────────────────── */
    $(function () {
        DS.init();
    });

})(jQuery);
