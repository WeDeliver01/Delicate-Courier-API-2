/**
 * Delicate Checkout — Single-Page Logic
 *
 * Handles: delivery/collection toggle, validation, T&C,
 * coupon apply/remove, payment gateway toggle, order notes,
 * delivery scheduler integration.
 */
(function ($) {
    'use strict';

    var DTSC = {

        deliveryMethod: 'delivery',
        quoteStatus: 'none', // none, loading, ok, not-serviceable, special-trip, error

        // -- Optimistic UI state ----------------------------------------------
        // Tracks fire-and-forget AJAX calls so out-of-order responses and
        // rapid user toggles don't corrupt UI state. Each pending action
        // carries an incrementing seq number; when a response arrives with
        // a seq older than the latest, it's discarded (the user has since
        // taken another action and we don't want stale data overwriting
        // the current UI).
        _pendingSeq: 0,
        _latestFulfillmentSeq: 0,

        /**
         * Compute the order total locally from the values already on the
         * page (subtotal + shipping + fees - discount). Used to update the
         * summary optimistically; the server's authoritative figure
         * arrives shortly via refreshOrderSummary() and reconciles any
         * tiny rounding/tax/coupon delta.
         *
         * Reads numeric values out of the existing rendered summary rows
         * — we don't store totals in JS state because WooCommerce/coupon
         * plugins also write to these rows and we want them to remain the
         * source of truth between user actions.
         */
        computeOptimisticTotal: function (newShippingCost) {
            var parseRand = function (selector) {
                var txt = ($(selector).text() || '').replace(/[^\d.,-]/g, '').replace(/,/g, '');
                var n = parseFloat(txt);
                return isNaN(n) ? 0 : n;
            };
            // Subtotal and fees stay constant across a fulfillment toggle.
            var subtotal = parseRand('.dtsc-order-totals .cart-subtotal .amount, .dtsc-order-totals tr.cart-subtotal td');
            var fees     = 0;
            $('.dtsc-order-totals tr.fee td').each(function () {
                fees += parseRand(this);
            });
            // Discount is signed negative in the summary HTML; treat as positive
            // and subtract.
            var discount = 0;
            $('.dtsc-order-totals tr.cart-discount td').each(function () {
                discount += Math.abs(parseRand(this));
            });
            return Math.max(0, subtotal + (parseFloat(newShippingCost) || 0) + fees - discount);
        },

        /**
         * Optimistically write a shipping cost + total into the summary
         * sidebar without waiting for the server. The shipping line and
         * the total update instantly; refreshOrderSummary() runs in the
         * background and reconciles if anything differs (e.g. shipping-
         * dependent tax changes).
         */
        applyOptimisticShipping: function (cost, label) {
            if (label === 'collect' || label === 'collection') {
                $('#dtsc-shipping-label').text('Collection');
                $('#dtsc-shipping-total').html('<strong style="color:#2e7d32;">Free</strong>');
            } else if (cost > 0) {
                $('#dtsc-shipping-label').text('Shipping');
                $('#dtsc-shipping-total').html('<strong>R' + cost.toFixed(2) + '</strong>');
            } else {
                $('#dtsc-shipping-label').text('Shipping');
                $('#dtsc-shipping-total').text('—');
            }
            // Optimistic total. Updated again by refreshOrderSummary() when
            // the server response arrives — that one may include
            // shipping-tax adjustments we couldn't compute here.
            var optTotal = this.computeOptimisticTotal(cost);
            // Look for the total in the rendered summary; write into all
            // matching spots so the side panel and the bottom-of-page total
            // stay in sync.
            $('.dtsc-order-totals .order-total .amount, .dtsc-order-totals tr.order-total td .amount').each(function () {
                $(this).text('R' + optTotal.toFixed(2));
            });
        },

        /**
         * Fire a fulfillment-sync AJAX and let the response reconcile
         * authoritative totals. Tracks a seq number so rapid toggles
         * resolve in the right order — only the latest user action's
         * response is allowed to overwrite the UI.
         *
         * Rollback: if the server returns success=false (rare — nonce
         * expired, plugin deactivated mid-session), show a small inline
         * toast and revert deliveryMethod. We don't roll back the
         * shipping number itself because the user's most recent intent
         * is what should win — they've already moved on visually.
         */
        syncFulfillmentOptimistic: function (params) {
            var self = this;
            var mySeq = ++this._pendingSeq;
            this._latestFulfillmentSeq = mySeq;

            $.ajax({
                type: 'POST',
                url: dtscCheckout.ajaxUrl,
                data: $.extend({
                    action: 'dtsc_set_fulfillment',
                    security: dtscCheckout.orderSummaryNonce
                }, params),
                dataType: 'json'
            }).done(function (resp) {
                // Out-of-order guard: if a newer toggle has fired since we
                // started, drop this response on the floor. Otherwise the
                // user's rapid toggle Delivery → Collection → Delivery
                // would briefly show stale Collection totals when the
                // first Collection response lands last.
                if (mySeq !== self._latestFulfillmentSeq) {
                    return;
                }
                if (resp && resp.success === false) {
                    self._toast('Could not save delivery preference — please try again.', 'warning');
                    return;
                }
                // Reconcile: pull authoritative totals from server. If they
                // match our optimistic estimate, nothing visible changes;
                // if they differ (e.g. shipping-dependent tax), the user
                // sees the correction land within a few hundred ms.
                self.refreshOrderSummary();
            }).fail(function () {
                if (mySeq !== self._latestFulfillmentSeq) return;
                self._toast('Connection issue saving preference. Your selection is still active.', 'warning');
            });
        },

        /**
         * Non-blocking inline toast for optimistic-UI rollback messages.
         * Auto-dismisses; never a modal — modals belong only on
         * data-integrity failures (payment, irreversible deletes).
         */
        _toast: function (msg, level) {
            var bg = (level === 'warning') ? '#fff3cd' : '#d4edda';
            var fg = (level === 'warning') ? '#856404' : '#155724';
            var $t = $('<div class="dtsc-toast" role="status" aria-live="polite"></div>')
                .text(msg)
                .css({
                    position: 'fixed', right: '20px', bottom: '20px',
                    background: bg, color: fg, padding: '12px 18px',
                    borderRadius: '6px', boxShadow: '0 4px 12px rgba(0,0,0,0.15)',
                    zIndex: 99999, fontSize: '14px', maxWidth: '320px',
                    opacity: 0, transition: 'opacity 200ms ease'
                });
            $('body').append($t);
            // Fade in next tick; fade out + remove after 4s.
            setTimeout(function () { $t.css('opacity', 1); }, 10);
            setTimeout(function () {
                $t.css('opacity', 0);
                setTimeout(function () { $t.remove(); }, 250);
            }, 4000);
        },
        // -- end optimistic UI state ------------------------------------------

        /**
         * Apply a quote success result to the UI. Shared between the live
         * AJAX success handler and the sessionStorage cache-hit path so
         * the two paths produce identical UI state. `fromCache` controls
         * the optimistic-summary behavior: cached hits skip the server
         * round-trip to refresh the order summary since we already have
         * the totals consistent from a prior session-state.
         */
        _applyQuoteSuccess: function (d, fromCache) {
            var $result = $('#dtsc-quote-result');
            var priceHtml = d.price > 0
                ? '<strong>R' + parseFloat(d.price).toFixed(2) + '</strong>'
                : '<strong>Free</strong>';
            $result.html(this.buildQuoteCard('success',
                '<div class="dtsc-quote-success-row">' +
                    '<span class="dtsc-quote-text">' + this.escapeHtml(d.message || 'Standard delivery') + '</span>' +
                    '<span class="dtsc-quote-price">' + priceHtml + '</span>' +
                '</div>'
            ));
            $('#dtsc-shipping-total').html(priceHtml);
            if (!$('#dtsc_shipping_cost').length) {
                $('form.dtsc-checkout-form').append('<input type="hidden" id="dtsc_shipping_cost" name="dtsc_shipping_cost" value="" />');
            }
            $('#dtsc_shipping_cost').val(d.price);
            this.quoteStatus = 'ok';
            $('#dtsc_special_trip').val('no');

            // OPTIMISTIC: update the order total in the sidebar with the
            // new shipping cost, then reconcile with server. The user
            // sees the right number immediately; the server's
            // refreshOrderSummary lands a few hundred ms later and
            // corrects any shipping-dependent tax delta.
            this.applyOptimisticShipping(parseFloat(d.price) || 0, 'delivery');
            this.syncFulfillmentOptimistic({
                fulfillment_type: 'delivery',
                shipping_cost: d.price
            });
        },

        init: function () {
            this.bindEvents();
            this.initPaymentToggle();
            this.bindPlaceOrder();

            // Remove WC "No shipping method" notices — our plugin handles shipping.
            (function removeShippingNotices() {
                $('.woocommerce-error li').each(function () {
                    var t = $(this).text().toLowerCase();
                    if (t.indexOf('shipping') !== -1 && (t.indexOf('selected') !== -1 || t.indexOf('available') !== -1)) {
                        var $ul = $(this).closest('ul.woocommerce-error');
                        if ($(this).siblings('li').length === 0) { $ul.remove(); } else { $(this).remove(); }
                    }
                });
            })();
            $(document.body).on('updated_checkout', function () {
                setTimeout(function () {
                    $('.woocommerce-error li').each(function () {
                        var t = $(this).text().toLowerCase();
                        if (t.indexOf('shipping') !== -1 && (t.indexOf('selected') !== -1 || t.indexOf('available') !== -1)) {
                            var $ul = $(this).closest('ul.woocommerce-error');
                            if ($(this).siblings('li').length === 0) { $ul.remove(); } else { $(this).remove(); }
                        }
                    });
                }, 100);
            });
            
            // Clear stale address fields on page load — fresh checkout every time.
            // Only clear shipping/billing address fields, not contact info (name/email/phone).
            var addressFields = [
                '#shipping_address_1', '#shipping_address_2', '#shipping_city',
                '#shipping_state', '#shipping_postcode',
                '#shipping_place_id', '#shipping_latitude', '#shipping_longitude',
                '#billing_address_1', '#billing_address_2', '#billing_city',
                '#billing_state', '#billing_postcode',
                '#billing_place_id', '#billing_latitude', '#billing_longitude'
            ];
            addressFields.forEach(function (sel) {
                var $f = $(sel);
                if ($f.length && $f.attr('type') !== 'hidden') {
                    // Only clear visible fields — hidden country fields should stay as ZA
                    $f.val('');
                }
                // Also clear hidden place/lat/lng fields
                if (sel.indexOf('place_id') !== -1 || sel.indexOf('latitude') !== -1 || sel.indexOf('longitude') !== -1) {
                    $f.val('');
                }
            });

            // Auto-fetch delivery quote on load if address is already filled
            var self = this;
            setTimeout(function () {
                if (self.deliveryMethod === 'delivery') {
                    var city = ($('#shipping_city').val() || '').trim();
                    var postcode = ($('#shipping_postcode').val() || '').trim();
                    if (city && postcode) {
                        self.fetchDeliveryQuote();
                    }
                }
            }, 500);
        },

        /**
         * Bind Place Order using document-level capture.
         * Using document rather than element so gateway button replacements don't break binding.
         */
        bindPlaceOrder: function () {
            var placeOrderBtn = document.getElementById('place_order');
            if (!placeOrderBtn) {
                console.error('[DTSC] #place_order button NOT found');
                return;
            }

            console.log('[DTSC] Binding place order via document capture listener');

            // Capture clicks at document level — fires before any element handler
            document.addEventListener('click', function (e) {
                var target = e.target;
                while (target && target !== document) {
                    if (target.id === 'place_order' || target.name === 'woocommerce_checkout_place_order') {
                        break;
                    }
                    target = target.parentNode;
                }
                if (!target || target === document) return;

                e.preventDefault();
                e.stopPropagation();
                e.stopImmediatePropagation();

                console.log('[DTSC] Place Order clicked (document capture)');

                var btn = document.getElementById('place_order');
                if (btn && (btn.disabled || btn.classList.contains('dtsc-btn-loading'))) {
                    console.log('[DTSC] Button disabled, ignoring click');
                    return false;
                }

                // Sync fields
                DTSC.syncContactToShipping();

                // Safety net: if the special trip panel is open, ensure flags are set
                // even if the user didn't click the confirm button.
                if ($('#dtsc-special-trip-panel').is(':visible') || DTSC.quoteStatus === 'special-trip') {
                    DTSC.quoteStatus = 'special-trip';
                    $('#dtsc_delivery_method').val('collect');
                    $('#dtsc_special_trip').val('yes');
                }

                if (DTSC.deliveryMethod === 'delivery' && DTSC.quoteStatus !== 'special-trip' && $('#dtsc_same_as_billing').is(':checked')) {
                    DTSC.copyShippingToBilling();
                }
                if (DTSC.deliveryMethod === 'collect' && DTSC.quoteStatus !== 'special-trip') {
                    // Regular collection — fill billing with store address
                    DTSC.copyContactToBilling();
                    DTSC.ensureBillingAddressForCollection();
                }
                if (DTSC.quoteStatus === 'special-trip') {
                    // Special trip — customer entered a delivery address in shipping fields.
                    // Copy shipping to billing (their real address), don't overwrite with store.
                    DTSC.copyShippingToBilling();
                    DTSC.copyContactToBilling();
                }

                // Validate
                if (!DTSC.validateForm()) {
                    console.log('[DTSC] Validation failed');
                    return false;
                }

                console.log('[DTSC] Validation passed, submitting...');
                DTSC.submitCheckout();
                return false;
            }, true);

            // Block native form submit via DOM event
            document.addEventListener('submit', function (e) {
                var form = e.target;
                if (form && (form.classList.contains('checkout') || form.classList.contains('dtsc-checkout-form'))) {
                    e.preventDefault();
                    e.stopImmediatePropagation();
                    console.log('[DTSC] Native form submit blocked (event)');
                    DTSC.submitCheckout();
                    return false;
                }
            }, true);

            // Override the native HTMLFormElement.submit() method on our form.
            // PayFast calls form[0].submit() directly which bypasses ALL event listeners.
            // This is the only way to intercept it.
            var checkoutForm = document.querySelector('form.checkout, form.dtsc-checkout-form');
            if (checkoutForm) {
                var nativeSubmit = checkoutForm.submit.bind(checkoutForm);
                checkoutForm.submit = function() {
                    console.log('[DTSC] Native form.submit() intercepted — running DTSC submit instead');
                    DTSC.submitCheckout();
                };
                console.log('[DTSC] Overrode native form.submit()');
            }
        },

        bindEvents: function () {
            var self = this;

            console.log('[DTSC] bindEvents running, #place_order exists:', $('#place_order').length);

            // Delivery method toggle
            $(document).on('click', '.dtsc-delivery-btn', function (e) {
                e.preventDefault();
                self.toggleDeliveryMethod($(this));
            });

            // Same as billing
            $(document).on('change', '#dtsc_same_as_billing', function () {
                $('#dtsc-billing-fields')[$(this).is(':checked') ? 'slideUp' : 'slideDown'](300);
            });

            // Login toggle
            $(document).on('click', '.dtsc-login-toggle', function (e) {
                e.preventDefault();
                $('.dtsc-login-form').slideToggle(200);
            });

            // Create account toggle — show/hide password field
            $(document).on('change', '#createaccount', function () {
                $('#dtsc-account-password')[$(this).is(':checked') ? 'slideDown' : 'slideUp'](200);
            });

            // Self-receiving toggle — show/hide recipient fields & alt phone
            $(document).on('change', '#dtsc_self_receiving', function () {
                var isSelf = $(this).is(':checked');
                // When self-receiving: hide recipient fields, show alt phone
                // When someone else: show recipient fields, hide alt phone (customer phone is the alt)
                $('#dtsc-recipient-fields')[isSelf ? 'slideUp' : 'slideDown'](300);
                $('#dtsc-alt-phone-row')[isSelf ? 'slideDown' : 'slideUp'](300);
                // Clear fields when hiding
                if (isSelf) {
                    $('#dtsc_recipient_name, #dtsc_recipient_phone').val('');
                } else {
                    $('#dtsc_delivery_phone').val('');
                }
            });

            // Address2 toggle (backup — autocomplete.js also handles this)
            $(document).on('click', '#dtsc-toggle-address2', function (e) {
                e.preventDefault();
                $('.dtsc-address2-wrapper').slideToggle(200);
                $(this).hide();
            });

            // Trigger WC shipping recalculation when delivery address fields change
            var addressTimer = null;
            $(document).on('change', '#shipping_city, #shipping_postcode, #shipping_state, #shipping_country', function () {
                clearTimeout(addressTimer);
                addressTimer = setTimeout(function () {
                    self.updateOrderReview();
                }, 500);
            });
            $(document).on('blur', '#shipping_city, #shipping_postcode', function () {
                clearTimeout(addressTimer);
                addressTimer = setTimeout(function () {
                    self.updateOrderReview();
                }, 300);
            });

            // Order notes
            $(document).on('change', '#dtsc-toggle-notes', function () {
                $('.dtsc-notes-field')[$(this).is(':checked') ? 'slideDown' : 'slideUp'](200);
            });

            // Coupons
            $(document).on('click', '#dtsc-apply-coupon', function (e) {
                e.preventDefault();
                self.applyCoupon();
            });
            $(document).on('keypress', '#dtsc-coupon-code', function (e) {
                if (e.which === 13) { e.preventDefault(); self.applyCoupon(); }
            });
            $(document).on('click', '.dtsc-remove-coupon', function (e) {
                e.preventDefault();
                self.removeCoupon($(this).data('coupon'));
            });

            // Clear validation on input
            $(document).on('input change', '.dtsc-checkout-form input, .dtsc-checkout-form select', function () {
                var $row = $(this).closest('.form-row');
                if ($row.hasClass('woocommerce-invalid') && $(this).val().trim()) {
                    $row.removeClass('woocommerce-invalid woocommerce-invalid-required-field');
                    $row.find('.dtsc-field-error').remove();
                }
            });

            // Terms checkbox — clear error
            $(document).on('change', '#dtsc-terms-checkbox', function () {
                if ($(this).is(':checked')) {
                    $('#dtsc-terms-error').hide();
                    $('#dtsc-terms-wrap').removeClass('dtsc-terms-has-error');
                }
            });
        },

        /* ── Submit Checkout via WooCommerce AJAX ─────── */
        submitCheckout: function () {
            var $form = $('form.checkout, form.dtsc-checkout-form').first();
            var $btn = $('#place_order');
            var originalText = $btn.text() || 'Place Order';

            // Show loading state immediately
            $btn.prop('disabled', true).addClass('dtsc-btn-loading');
            $btn.html('Processing… <span class="dtsc-spinner"></span>');

            // Remove any previous errors
            $('.woocommerce-error, .woocommerce-message, .woocommerce-NoticeGroup, #dtsc-validation-summary').remove();

            // Serialize form data
            var formData = $form.serialize();
            
            // Force required fields into the data string (in case hidden fields aren't serialized)
            formData += '&woocommerce_checkout_place_order=1';

            // BOMBPROOF: Force special trip flags into the POST data.
            // Remove any existing dtsc_special_trip and dtsc_delivery_method values
            // and re-add them from our JS state. This bypasses any DOM serialization issues.
            formData = formData.replace(/&?dtsc_special_trip=[^&]*/g, '');
            formData = formData.replace(/&?dtsc_delivery_method=[^&]*/g, '');
            if (DTSC.quoteStatus === 'special-trip') {
                formData += '&dtsc_special_trip=yes&dtsc_delivery_method=collect';
                console.log('[DTSC] Injecting special trip flags into POST data');
            } else {
                formData += '&dtsc_special_trip=no&dtsc_delivery_method=' + encodeURIComponent(DTSC.deliveryMethod);
            }

            // Always force billing/shipping country for South Africa
            if (formData.indexOf('billing_country=') === -1) {
                formData += '&billing_country=ZA';
            } else {
                formData = formData.replace(/billing_country=[^&]*/g, 'billing_country=ZA');
            }
            if (formData.indexOf('shipping_country=') === -1) {
                formData += '&shipping_country=ZA';
            } else {
                formData = formData.replace(/shipping_country=[^&]*/g, 'shipping_country=ZA');
            }

            // CRITICAL: Force ship_to_different_address=1 so WooCommerce treats the
            // shipping address as an independent record from the billing address.
            // Without this, WC_Checkout copies billing_* into shipping_* at order
            // creation time and ShipLogic ends up with the billing address as the
            // delivery destination. This is the front-line guard — there are also
            // server-side enforcements in PHP. Strip any pre-existing value first
            // so the form's hidden input or session can never override us.
            formData = formData.replace(/&?ship_to_different_address=[^&]*/g, '');
            formData += '&ship_to_different_address=1';

            // Post to WooCommerce checkout endpoint
            var checkoutUrl = dtscCheckout.wcAjaxUrl.replace('%%endpoint%%', 'checkout');

            console.log('[DTSC] Submitting checkout to:', checkoutUrl);
            console.log('[DTSC] quoteStatus:', DTSC.quoteStatus, 'deliveryMethod:', DTSC.deliveryMethod);
            console.log('[DTSC] POST contains dtsc_special_trip=yes:', formData.indexOf('dtsc_special_trip=yes') !== -1);

            // Sync shipping cost to server session before submitting the order.
            // This ensures the order meta handler reads the correct shipping amount.
            var shippingCost = 0;
            if (DTSC.deliveryMethod === 'collect' && DTSC.quoteStatus !== 'special-trip') {
                shippingCost = 0;
            } else if ($('#dtsc_shipping_cost').length) {
                shippingCost = parseFloat($('#dtsc_shipping_cost').val()) || 0;
            }

            // Also inject shipping cost into formData so order meta can read it
            formData = formData.replace(/&?dtsc_shipping_cost=[^&]*/g, '');
            formData += '&dtsc_shipping_cost=' + shippingCost;

            // Sync to server session — but FIRE-AND-FORGET. The shipping
            // cost is already injected into formData above (line 348), so
            // the server's order-meta handler reads it from the POST body
            // directly; this side-channel write is only for session-level
            // consistency, which is not on the critical path of order
            // submission. Running it synchronously here used to freeze the
            // browser tab for 500ms–2s right when the user clicked
            // "Place Order" — the worst possible moment to make a UI
            // unresponsive. Async + no callback = optimistic write.
            $.ajax({
                type: 'POST',
                url: dtscCheckout.ajaxUrl,
                data: {
                    action: 'dtsc_set_fulfillment',
                    security: dtscCheckout.orderSummaryNonce,
                    fulfillment_type: DTSC.quoteStatus === 'special-trip' ? 'collect' : DTSC.deliveryMethod,
                    special_trip: DTSC.quoteStatus === 'special-trip' ? 'yes' : 'no',
                    shipping_cost: shippingCost
                }
                // async defaults to true — explicitly NOT specifying it
                // here to avoid anyone reintroducing async: false.
            });

            $.ajax({
                type: 'POST',
                url: checkoutUrl,
                data: formData,
                dataType: 'text', // Parse manually — plugins can inject scripts before JSON
                timeout: 60000,
                success: function (responseText) {
                    console.log('[DTSC] Raw response length:', responseText.length);
                    
                    // Extract JSON from response — other plugins (e.g. GA) may inject <script> before it
                    var result = null;
                    try {
                        // Try direct parse first
                        result = JSON.parse(responseText);
                    } catch (e) {
                        // Try finding JSON starting from {"result" — handles injected scripts before JSON
                        var searchKeys = ['{"result"', '{ "result"'];
                        for (var k = 0; k < searchKeys.length && !result; k++) {
                            var firstBrace = responseText.indexOf(searchKeys[k]);
                            if (firstBrace !== -1) {
                                var jsonStr = responseText.substring(firstBrace);
                                // Use a balanced-brace parser to extract the full object
                                var depth = 0, endIdx = -1;
                                for (var ci = 0; ci < jsonStr.length; ci++) {
                                    if (jsonStr[ci] === '{') depth++;
                                    else if (jsonStr[ci] === '}') {
                                        depth--;
                                        if (depth === 0) { endIdx = ci; break; }
                                    }
                                }
                                if (endIdx !== -1) {
                                    try {
                                        result = JSON.parse(jsonStr.substring(0, endIdx + 1));
                                    } catch (e2) {
                                        console.error('[DTSC] Could not parse extracted JSON');
                                    }
                                }
                            }
                        }
                    }
                    
                    console.log('[DTSC] Parsed result:', result);

                    if (!result) {
                        // Check if we got redirected to an HTML page (cart empty, order already placed)
                        if (responseText.indexOf('<!DOCTYPE') !== -1 || responseText.indexOf('<html') !== -1) {
                            console.log('[DTSC] Got HTML page — order likely already placed');
                            window.location.href = dtscCheckout.checkoutUrl;
                            return;
                        }
                        DTSC.showCheckoutError($form, $btn, originalText, 'Could not process the response. Please check your orders or try again.');
                        return;
                    }

                    // Handle reload flag (some gateways request this)
                    if (result.reload === true || result.reload === 'true') {
                        window.location.reload();
                        return;
                    }

                    // Handle refresh flag
                    if (result.refresh === true || result.refresh === 'true') {
                        $(document.body).trigger('update_checkout');
                    }

                    if (result.result === 'success' && result.redirect) {
                        console.log('[DTSC] SUCCESS — raw redirect:', result.redirect);
                        
                        // Decode HTML entities and escaped slashes
                        var redirectUrl = result.redirect
                            .replace(/&amp;/g, '&')
                            .replace(/\\u0026/g, '&')
                            .replace(/\\\//g, '/')
                            .replace(/&#038;/g, '&');

                        console.log('[DTSC] Decoded redirect URL:', redirectUrl);
                        console.log('[DTSC] customBase:', dtscCheckout.checkoutUrl);
                        console.log('[DTSC] wcBase:', dtscCheckout.wcCheckoutUrl);

                        // If the redirect is to an external URL (e.g. PayFast payment page),
                        // do NOT rewrite it — just follow it directly.
                        var currentHost = window.location.hostname;
                        try {
                            var redirectHost = new URL(redirectUrl).hostname;
                            if (redirectHost !== currentHost) {
                                console.log('[DTSC] External redirect (e.g. PayFast) — following directly:', redirectUrl);
                                $(document.body).trigger('checkout_place_order_success', [result]);
                                $btn.html('Redirecting… <span class="dtsc-spinner"></span>');
                                window.location.href = redirectUrl;
                                return;
                            }
                        } catch (e) {
                            // Not a valid absolute URL — continue with rewrite logic
                        }

                        // PayFast and other redirect gateways return an order-pay URL.
                        // Our PHP filter (dtsc_fix_order_pay_url) now builds these as
                        // query-string URLs on our shortcode page, but older cached
                        // responses or other gateways may still return pretty-permalink
                        // format. Rewrite /order-pay/ID/ to ?order-pay=ID format on
                        // our shortcode page so the shortcode handler can detect it.
                        var orderPayMatch = redirectUrl.match(/\/order-pay\/(\d+)\/?\??(.*)/);
                        if (orderPayMatch) {
                            var base = (dtscCheckout.checkoutUrl || '').replace(/\/$/, '');
                            var orderId = orderPayMatch[1];
                            var existingParams = orderPayMatch[2] || '';
                            // Build query-string version: ?order-pay=ID&pay_for_order=true&key=xxx
                            var sep = base.indexOf('?') !== -1 ? '&' : '?';
                            // If the existing params already contain key= and pay_for_order=, use them
                            if (existingParams && existingParams.indexOf('key=') !== -1) {
                                redirectUrl = base + sep + 'order-pay=' + orderId + '&' + existingParams;
                            } else {
                                redirectUrl = base + sep + 'order-pay=' + orderId + (existingParams ? '&' + existingParams : '');
                            }
                            console.log('[DTSC] Rewrote order-pay URL to:', redirectUrl);
                        }

                        // Trigger WC events that payment gateways may listen for
                        $(document.body).trigger('checkout_place_order_success', [result]);

                        $btn.html('Redirecting… <span class="dtsc-spinner"></span>');
                        window.location.href = redirectUrl;
                        return;
                    }

                    if (result.result === 'success' && !result.redirect) {
                        window.location.href = dtscCheckout.checkoutUrl;
                        return;
                    }

                    if (result.result === 'failure') {
                        var errorHtml = '';
                        if (result.messages) {
                            var $tmp = $('<div>').html(result.messages);
                            var textErrors = [];
                            $tmp.find('.wc-block-components-notice-banner__content').each(function() {
                                textErrors.push($(this).text().trim());
                            });
                            $tmp.find('.woocommerce-error li, .woocommerce-error').each(function() {
                                var t = $(this).text().trim();
                                if (t && textErrors.indexOf(t) === -1) textErrors.push(t);
                            });
                            if (textErrors.length) {
                                errorHtml = '<ul class="woocommerce-error" role="alert">';
                                for (var i = 0; i < textErrors.length; i++) {
                                    errorHtml += '<li>' + textErrors[i] + '</li>';
                                }
                                errorHtml += '</ul>';
                            } else {
                                errorHtml = result.messages;
                            }
                        } else {
                            errorHtml = '<ul class="woocommerce-error" role="alert"><li>An error occurred. Please try again.</li></ul>';
                        }
                        DTSC.showCheckoutError($form, $btn, originalText, errorHtml, true);
                        return;
                    }

                    DTSC.showCheckoutError($form, $btn, originalText, 'Unexpected response. Please try again.');
                },
                error: function (xhr, status, error) {
                    console.error('[DTSC] AJAX error:', status, error);

                    var msg = 'Something went wrong. Please try again.';
                    if (status === 'timeout') {
                        msg = 'The request timed out. Please check your connection and try again.';
                    } else if (xhr.status === 0) {
                        msg = 'Could not connect to the server. Please check your internet connection.';
                    } else if (xhr.responseText) {
                        // Try to parse error from response
                        try {
                            var resp = JSON.parse(xhr.responseText);
                            if (resp.messages) msg = resp.messages;
                            else if (resp.message) msg = resp.message;
                        } catch (e) {
                            // Response wasn't JSON — might be a PHP error page
                            console.error('[DTSC] Non-JSON response:', xhr.responseText.substring(0, 500));
                        }
                    }
                    DTSC.showCheckoutError($form, $btn, originalText, msg);
                }
            });
        },

        /* ── Show checkout error and reset button ─────── */
        showCheckoutError: function ($form, $btn, originalText, message, isHtml) {
            var html = isHtml ? message : '<ul class="woocommerce-error" role="alert"><li>' + message + '</li></ul>';
            $form.find('.woocommerce-NoticeGroup').remove();
            $form.prepend('<div class="woocommerce-NoticeGroup woocommerce-NoticeGroup-checkout">' + html + '</div>');
            $('html, body').animate({ scrollTop: $form.offset().top - 100 }, 400);

            $btn.prop('disabled', false).removeClass('dtsc-btn-loading');
            $btn.text(originalText);

            $(document.body).trigger('checkout_error', [message]);
        },

        /* ── Fetch Delivery Quote from Courier API ───── */
        updateOrderReview: function () {
            // Only fetch quote for delivery method
            if (this.deliveryMethod !== 'delivery') return;
            this.fetchDeliveryQuote();
        },

        /**
         * Refresh the order summary sidebar from the server.
         * Called after shipping cost changes (quote received, collection toggle, etc.)
         * so the cart total reflects the actual shipping cost.
         */
        refreshOrderSummary: function () {
            var self = this;
            $.ajax({
                type: 'POST',
                url: dtscCheckout.ajaxUrl,
                data: {
                    action: 'dtsc_get_order_summary',
                    security: dtscCheckout.orderSummaryNonce
                },
                dataType: 'json',
                success: function (resp) {
                    if (resp.success && resp.data && resp.data.html) {
                        var $container = $('.dtsc-order-totals');
                        if ($container.length) {
                            $container.replaceWith(resp.data.html);
                        }
                        // Re-apply shipping label based on current state
                        if (self.deliveryMethod === 'collect' || self.deliveryMethod === 'collection') {
                            $('#dtsc-shipping-label').text('Collection');
                            $('#dtsc-shipping-total').html('<strong style="color:#2e7d32;">Free</strong>');
                        } else if (self.quoteStatus === 'ok' && $('#dtsc_shipping_cost').length) {
                            var cost = parseFloat($('#dtsc_shipping_cost').val());
                            if (cost > 0) {
                                $('#dtsc-shipping-total').html('<strong>R' + cost.toFixed(2) + '</strong>');
                            }
                        } else if (self.quoteStatus === 'special-trip') {
                            $('#dtsc-shipping-total').html('<strong>Quote Pending</strong>');
                        }
                    }
                }
            });
        },

        fetchDeliveryQuote: function () {
            var address1 = ($('#shipping_address_1').val() || '').trim();
            var city = ($('#shipping_city').val() || '').trim();
            var postcode = ($('#shipping_postcode').val() || '').trim();

            // Need at least address + city + postcode
            if (!address1 || !city || !postcode) return;

            // Client-side cache lookup. If the user resolved this exact
            // destination earlier in the session (e.g. they toggled to
            // Collection then back to Delivery, or they refreshed the
            // page mid-checkout with sessionStorage intact), we already
            // have the rate and can show it instantly without the 1-2s
            // round-trip to the platform. Keyed on the full destination
            // so a city/postcode change invalidates correctly.
            //
            // TTL: 5 minutes — same as the server-side transient cache in
            // the DCP courier plugin. Keeps stale rates out without
            // hammering Shiplogic for every keystroke-corrected address.
            var cacheKey = 'dtsc.rate:' + [address1, city, postcode].join('|').toLowerCase();
            try {
                var cached = sessionStorage.getItem(cacheKey);
                if (cached) {
                    var c = JSON.parse(cached);
                    if (c && c.expires > Date.now() && c.data) {
                        DTSC._applyQuoteSuccess(c.data, true /* fromCache */);
                        return;
                    }
                    sessionStorage.removeItem(cacheKey);
                }
            } catch (e) {
                // sessionStorage unavailable (private browsing in some
                // browsers, quota issues). Fall through to live fetch.
            }
            DTSC._activeQuoteCacheKey = cacheKey;

            var $panel = $('#dtsc-quote-panel');
            var $result = $('#dtsc-quote-result');

            // Reset quote status
            DTSC.quoteStatus = 'loading';

            $panel.slideDown(200);
            $result.html(DTSC.buildQuoteCard('loading',
                '<div class="dtsc-quote-loading-row">' +
                    '<span class="dtsc-quote-spinner" aria-hidden="true"></span>' +
                    '<span class="dtsc-quote-loading-text" id="dtsc-quote-progress">Locating address…</span>' +
                '</div>'
            ));

            // Progressive loading copy. The wall-clock duration of the
            // upstream call (plugin → platform → Shiplogic) is ~1–2s; a
            // static "Calculating…" message for that long reads as a hang.
            // Three short-lived messages give the same wait an arc, which
            // measurably reduces perceived wait time (Nielsen-Norman
            // affirmation effect). Cleared in success/error handlers.
            var progressSteps = [
                { ms: 400,  text: 'Checking coverage…' },
                { ms: 1000, text: 'Getting best rate…' }
            ];
            var progressTimers = [];
            progressSteps.forEach(function (step) {
                progressTimers.push(setTimeout(function () {
                    var $p = $('#dtsc-quote-progress');
                    if ($p.length) { $p.text(step.text); }
                }, step.ms));
            });
            var clearProgress = function () {
                progressTimers.forEach(function (t) { clearTimeout(t); });
            };

            $.ajax({
                type: 'POST',
                url: dtscCheckout.ajaxUrl,
                data: {
                    action: 'dtsc_get_quote',
                    nonce: dtscCheckout.quoteNonce,
                    address_1: address1,
                    address_2: ($('#shipping_address_2').val() || '').trim(),
                    city: city,
                    state: ($('#shipping_state').val() || '').trim(),
                    postcode: postcode,
                    country: ($('#shipping_country').val() || 'ZA'),
                    place_id: ($('#shipping_place_id').val() || ''),
                    latitude: ($('#shipping_latitude').val() || ''),
                    longitude: ($('#shipping_longitude').val() || ''),
                    first_name: ($('#billing_first_name').val() || '').trim(),
                    last_name: ($('#billing_last_name').val() || '').trim(),
                    email: ($('#billing_email').val() || '').trim(),
                    phone: ($('#billing_phone').val() || '').trim()
                },
                dataType: 'json',
                success: function (resp) {
                    clearProgress();
                    if (resp.success && resp.data) {
                        // Cache the rate for the rest of the session.
                        try {
                            var key = DTSC._activeQuoteCacheKey;
                            if (key && typeof sessionStorage !== 'undefined') {
                                sessionStorage.setItem(key, JSON.stringify({
                                    expires: Date.now() + (5 * 60 * 1000), // 5 min, same TTL as server transient
                                    data: resp.data
                                }));
                            }
                        } catch (e) { /* quota / private browsing — ignore */ }
                        DTSC._applyQuoteSuccess(resp.data, false);
                    } else {
                        // Not serviceable — show special trip request option
                        var msg = (resp.data && resp.data.message) ? resp.data.message : 'Delivery not available.';
                        $result.html(DTSC.buildQuoteCard('not-serviceable',
                            '<div class="dtsc-quote-error-msg">' +
                                '<svg class="dtsc-quote-warning-icon" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>' +
                                '<span>We don\'t currently deliver to your area.</span>' +
                            '</div>' +
                            '<p class="dtsc-quote-options-intro">You can either:</p>' +
                            '<div class="dtsc-quote-options">' +
                                '<button type="button" class="dtsc-quote-option-btn dtsc-special-trip-btn" id="dtsc-request-special-trip">' +
                                    '📦 Request a Special Trip' +
                                '</button>' +
                                '<button type="button" class="dtsc-quote-option-btn dtsc-switch-collect-btn" id="dtsc-switch-to-collect">' +
                                    '🏠 Switch to Collection' +
                                '</button>' +
                            '</div>' +
                            '<div id="dtsc-special-trip-panel" class="dtsc-special-trip-panel" style="display:none;">' +
                                '<div id="dtsc-special-trip-estimate" class="dtsc-special-trip-estimate">' +
                                    '<div class="dtsc-quote-loading-row">' +
                                        '<span class="dtsc-quote-spinner" aria-hidden="true"></span>' +
                                        '<span class="dtsc-quote-loading-text">Calculating estimated delivery cost…</span>' +
                                    '</div>' +
                                '</div>' +
                                '<div class="dtsc-special-trip-field">' +
                                    '<label for="dtsc_special_trip_note">Additional notes for delivery <span style="color:var(--dtsc-text-3);">(optional)</span></label>' +
                                    '<textarea id="dtsc_special_trip_note" name="dtsc_special_trip_note" rows="2" placeholder="e.g. Preferred time, gate code, landmarks…"></textarea>' +
                                '</div>' +
                                '<div class="dtsc-special-trip-confirm">' +
                                    '<button type="button" id="dtsc-confirm-special-trip" class="dtsc-quote-option-btn dtsc-special-trip-btn" style="width:100%;">' +
                                        '✅ Accept Estimate & Place Order' +
                                    '</button>' +
                                '</div>' +
                            '</div>'
                        ));
                        $('#dtsc-shipping-total').html('TBC');
                        DTSC.quoteStatus = 'not-serviceable';

                        // Special Trip button — set ALL flags immediately so the order
                        // is always processed correctly even if user skips the confirm button.
                        $('#dtsc-request-special-trip').on('click', function () {
                            $('#dtsc-special-trip-panel').slideDown(300);
                            $(this).addClass('dtsc-option-active');
                            // Set special trip state immediately
                            DTSC.quoteStatus = 'special-trip';
                            $('#dtsc_delivery_method').val('collect');
                            $('#dtsc_special_trip').val('yes');
                            $('#dtsc_shipping_cost').remove();
                            // Show calculating state — estimate will update this once Distance Matrix returns
                            $('#dtsc-shipping-total').html('<strong>Calculating…</strong>');
                            // Calculate estimated delivery cost using Google Distance Matrix
                            DTSC.calculateSpecialTripEstimate();
                        });

                        // Confirm special trip — visual confirmation only (flags already set above)
                        $(document).off('click', '#dtsc-confirm-special-trip').on('click', '#dtsc-confirm-special-trip', function () {
                            // Show the estimate in sidebar
                            var estText = $('#dtsc-special-trip-estimate').data('estimate-text') || 'Quote Pending';
                            $('#dtsc-shipping-total').html('<strong>' + estText + '</strong>');
                            // Show confirmation
                            $(this).prop('disabled', true).text('✅ Estimate accepted — complete your order below');
                        });

                        // Switch to collection
                        $('#dtsc-switch-to-collect').on('click', function () {
                            $('.dtsc-delivery-btn[data-method="collect"]').trigger('click');
                        });
                    }
                },
                error: function () {
                    clearProgress();
                    $result.html(DTSC.buildQuoteCard('error',
                        '<div class="dtsc-quote-error-msg">' +
                            '<svg class="dtsc-quote-warning-icon" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>' +
                            '<span>Could not get delivery quote. Please try again.</span>' +
                        '</div>'
                    ));
                    DTSC.quoteStatus = 'error';
                }
            });
        },

        /**
         * Calculate estimated delivery cost for a special trip using
         * Google Distance Matrix API (client-side).
         *
         * Uses the bakery address as origin and the customer's shipping
         * address as destination. Multiplies the distance in km by the
         * configured rate range (default R9–R12/km).
         */
        calculateSpecialTripEstimate: function () {
            var $estimate = $('#dtsc-special-trip-estimate');
            var config = dtscCheckout.specialTrip || {};
            var bakeryAddress = config.bakeryAddress || '5 Graham Road, Shere, Pretoria, South Africa';
            var rateMin = parseFloat(config.rateMin) || 9;
            var rateMax = parseFloat(config.rateMax) || 12;
            var minCharge = parseFloat(config.minCharge) || 150;

            // Build destination from shipping fields
            var addr = ($('#shipping_address_1').val() || '').trim();
            var city = ($('#shipping_city').val() || '').trim();
            var state = ($('#shipping_state').val() || '').trim();
            var postcode = ($('#shipping_postcode').val() || '').trim();
            var destination = [addr, city, state, postcode].filter(Boolean).join(', ');

            if (!destination || !addr) {
                $estimate.html(
                    '<div class="dtsc-notice-warning" style="padding:10px;border-radius:4px;background:#FFF8E1;border:1px solid #FFD54F;font-size:13px;">' +
                        '⚠️ Please enter your delivery address above to see an estimated cost.' +
                    '</div>'
                );
                return;
            }

            // Check if Distance Matrix service is available
            if (!window.google || !google.maps || !google.maps.DistanceMatrixService) {
                $estimate.html(
                    '<div class="dtsc-special-trip-badge">⏳ The bakery will contact you with a delivery quote</div>'
                );
                return;
            }

            $estimate.html(
                '<div class="dtsc-quote-loading-row">' +
                    '<span class="dtsc-quote-spinner" aria-hidden="true"></span>' +
                    '<span class="dtsc-quote-loading-text">Calculating distance &amp; estimated cost…</span>' +
                '</div>'
            );

            var service = new google.maps.DistanceMatrixService();
            service.getDistanceMatrix({
                origins: [bakeryAddress],
                destinations: [destination],
                travelMode: google.maps.TravelMode.DRIVING,
                unitSystem: google.maps.UnitSystem.METRIC,
            }, function (response, status) {
                if (status !== 'OK' || !response.rows || !response.rows[0] ||
                    !response.rows[0].elements || !response.rows[0].elements[0] ||
                    response.rows[0].elements[0].status !== 'OK') {
                    // Distance Matrix failed — fall back to manual quote
                    $estimate.html(
                        '<div class="dtsc-special-trip-badge">⏳ The bakery will contact you with a delivery quote</div>'
                    );
                    // Still allow order placement
                    $estimate.data('estimate-text', 'Quote Pending');
                    return;
                }

                var element = response.rows[0].elements[0];
                var distanceKm = element.distance.value / 1000; // meters → km
                var distanceText = element.distance.text;
                var durationText = element.duration.text;

                // Calculate price range
                var costLow = Math.max(minCharge, Math.round(distanceKm * rateMin));
                var costHigh = Math.max(minCharge, Math.round(distanceKm * rateMax));

                // Save to hidden fields for order meta
                if (!$('#dtsc_special_trip_distance').length) {
                    $('form.dtsc-checkout-form').append(
                        '<input type="hidden" id="dtsc_special_trip_distance" name="dtsc_special_trip_distance" value="" />' +
                        '<input type="hidden" id="dtsc_special_trip_estimate_low" name="dtsc_special_trip_estimate_low" value="" />' +
                        '<input type="hidden" id="dtsc_special_trip_estimate_high" name="dtsc_special_trip_estimate_high" value="" />'
                    );
                }
                $('#dtsc_special_trip_distance').val(distanceKm.toFixed(1));
                $('#dtsc_special_trip_estimate_low').val(costLow);
                $('#dtsc_special_trip_estimate_high').val(costHigh);

                var estimateText = 'R' + costLow + ' – R' + costHigh;
                $estimate.data('estimate-text', estimateText);

                // Store the low estimate as the shipping cost so the order total is correct.
                // The customer sees the range, but the order is charged at the low estimate.
                // Bakery can adjust the final amount after confirming with the customer.
                if (!$('#dtsc_shipping_cost').length) {
                    $('form.dtsc-checkout-form').append('<input type="hidden" id="dtsc_shipping_cost" name="dtsc_shipping_cost" value="" />');
                }
                $('#dtsc_shipping_cost').val(costLow);

                // Update sidebar shipping line with the estimate range
                $('#dtsc-shipping-total').html('<strong>' + estimateText + '</strong>');

                // Tell the server about the estimated shipping cost so the order summary total updates
                $.post(dtscCheckout.ajaxUrl, {
                    action: 'dtsc_set_fulfillment',
                    security: dtscCheckout.orderSummaryNonce,
                    fulfillment_type: 'collect',
                    special_trip: 'yes',
                    shipping_cost: costLow
                }, function () {
                    DTSC.refreshOrderSummary();
                });

                $estimate.html(
                    '<div style="background:#f0faf0;border:1px solid #c3e6c3;border-radius:6px;padding:14px;margin-bottom:12px;">' +
                        '<p style="margin:0 0 8px;font-weight:600;color:#2e5e2e;">📍 Estimated Delivery Cost</p>' +
                        '<div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px;">' +
                            '<div>' +
                                '<span style="font-size:1.4em;font-weight:700;color:#1a1a1a;">' + estimateText + '</span>' +
                                '<span style="font-size:0.85em;color:#666;margin-left:6px;">(estimated)</span>' +
                            '</div>' +
                            '<div style="text-align:right;font-size:0.8em;color:#666;">' +
                                '<div>📏 ' + distanceText + ' from bakery</div>' +
                                '<div>🕐 ~' + durationText + ' drive</div>' +
                            '</div>' +
                        '</div>' +
                        '<p style="margin:8px 0 0;font-size:0.8em;color:#888;">Final delivery cost will be confirmed by the bakery.</p>' +
                    '</div>'
                );
            });
        },

        /* ── Delivery / Collection ──────────────────────── */
        toggleDeliveryMethod: function ($btn) {
            $('.dtsc-delivery-btn').removeClass('dtsc-delivery-btn-active');
            $btn.addClass('dtsc-delivery-btn-active');
            this.deliveryMethod = $btn.data('method');
            $('#dtsc_delivery_method').val(this.deliveryMethod);

            if (this.deliveryMethod === 'delivery') {
                $('#dtsc-shipping-fields').slideDown(300);
                $('#dtsc-collection-fields').slideUp(200);
                $('#dtsc-delivery-schedule-section').slideDown(300);
                $('#dtsc-quote-panel').slideDown(200);
                if ($('#dtsc_same_as_billing').is(':checked')) {
                    $('#dtsc-billing-fields').slideUp(200);
                }
                // OPTIMISTIC: update sidebar instantly. If a rate is already
                // cached from an earlier autocomplete resolve, show it; else
                // show the dash and let fetchDeliveryQuote() populate it.
                var cachedCost = ($('#dtsc_shipping_cost').length && this.quoteStatus === 'ok')
                    ? (parseFloat($('#dtsc_shipping_cost').val()) || 0)
                    : 0;
                this.applyOptimisticShipping(cachedCost, 'delivery');
                // Server sync — fire-and-forget. Server-side state will
                // catch up; UI is already correct.
                this.syncFulfillmentOptimistic({ fulfillment_type: 'delivery' });
                // Fetch quote if address is filled. Will overwrite the
                // optimistic shipping number with the real one when ready.
                this.fetchDeliveryQuote();
            } else {
                $('#dtsc-shipping-fields').slideUp(300);
                $('#dtsc-collection-fields').slideDown(200);
                $('#dtsc-billing-fields').slideDown(300);
                $('#dtsc-delivery-schedule-section').slideUp(300);
                $('#dtsc-quote-panel').slideUp(200);
                // OPTIMISTIC: zero shipping, instant total update.
                this.quoteStatus = 'none';
                $('#dtsc_shipping_cost').remove();
                $('#dtsc_special_trip').val('no');
                this.applyOptimisticShipping(0, 'collect');
                // Server sync — fire-and-forget with reconciliation.
                this.syncFulfillmentOptimistic({
                    fulfillment_type: 'collect',
                    shipping_cost: 0
                });
            }
        },

        /* ── Validation ─────────────────────────────────── */
        validateForm: function () {
            console.log('[DTSC] validateForm called, deliveryMethod:', this.deliveryMethod);
            var valid = true;
            var firstError = null;
            var errorMessages = [];

            $('.dtsc-checkout-form .form-row').removeClass('woocommerce-invalid woocommerce-invalid-required-field');
            $('.dtsc-field-error').remove();
            $('#dtsc-terms-error').hide();
            $('#dtsc-terms-wrap').removeClass('dtsc-terms-has-error');
            $('#dtsc-validation-summary').remove();

            var fields = [
                { id: 'billing_first_name', type: 'text', label: 'First name' },
                { id: 'billing_last_name', type: 'text', label: 'Last name' },
                { id: 'billing_email', type: 'email', label: 'Email address' },
                { id: 'billing_phone', type: 'phone', label: 'Phone number' },
            ];

            if (this.deliveryMethod === 'delivery') {
                fields = fields.concat([
                    { id: 'shipping_address_1', type: 'text', label: 'Delivery street address' },
                    { id: 'shipping_city', type: 'text', label: 'Delivery city' },
                    { id: 'shipping_postcode', type: 'text', label: 'Delivery postal code' },
                ]);
                if (dtscCheckout.requireAddress2 === 'yes') {
                    fields.push({ id: 'shipping_address_2', type: 'text', label: 'Apartment / unit number' });
                }
                if ($('#dtsc_self_receiving').is(':checked')) {
                    // Self-receiving: require alt phone
                    fields.push({ id: 'dtsc_delivery_phone', type: 'phone', label: 'Alternative delivery phone number' });
                } else {
                    // Someone else receiving: require recipient details
                    fields.push({ id: 'dtsc_recipient_name', type: 'text', label: 'Recipient name' });
                    fields.push({ id: 'dtsc_recipient_phone', type: 'phone', label: 'Recipient phone number' });
                }
            } else {
                fields = fields.concat([
                    { id: 'billing_address_1', type: 'text', label: 'Billing street address' },
                    { id: 'billing_city', type: 'text', label: 'Billing city' },
                    { id: 'billing_postcode', type: 'text', label: 'Billing postal code' },
                ]);
            }

            for (var i = 0; i < fields.length; i++) {
                var f = fields[i];
                var $input = $('#' + f.id);
                var $row = $input.closest('.form-row');
                var val = ($input.val() || '').trim();

                if (!val) {
                    $row.addClass('woocommerce-invalid woocommerce-invalid-required-field');
                    $row.append('<span class="dtsc-field-error" role="alert">' + dtscCheckout.i18n.fieldRequired + '</span>');
                    valid = false;
                    errorMessages.push(f.label + ' is required');
                    if (!firstError) firstError = $row;
                    continue;
                }
                if (f.type === 'email' && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(val)) {
                    $row.addClass('woocommerce-invalid');
                    $row.append('<span class="dtsc-field-error" role="alert">' + dtscCheckout.i18n.invalidEmail + '</span>');
                    valid = false;
                    errorMessages.push('Please enter a valid email address');
                    if (!firstError) firstError = $row;
                }
                if (f.type === 'phone' && !/^[\d\s\+\-\(\)]{7,20}$/.test(val)) {
                    $row.addClass('woocommerce-invalid');
                    $row.append('<span class="dtsc-field-error" role="alert">' + dtscCheckout.i18n.invalidPhone + '</span>');
                    valid = false;
                    errorMessages.push('Please enter a valid phone number for ' + f.label);
                    if (!firstError) firstError = $row;
                }
            }

            // Scheduler validation — required for delivery AND special trip
            if (this.deliveryMethod === 'delivery' || this.quoteStatus === 'special-trip') {
                var dateVal = ($('#dtsc_delivery_date').val() || '').trim();
                var timeVal = ($('#dtsc_delivery_time').val() || '').trim();

                // Run scheduler's own validation if available (clears/shows its UI errors)
                if (window.DTSC_Scheduler && typeof DTSC_Scheduler.validate === 'function') {
                    DTSC_Scheduler.validate();
                }

                // Always enforce date + time regardless of scheduler required setting
                if (!dateVal) {
                    valid = false;
                    errorMessages.push('Please select a delivery date');
                    if (!firstError) firstError = $('#dtsc-delivery-schedule-section');
                }
                if (!timeVal) {
                    valid = false;
                    errorMessages.push('Please select a delivery time slot');
                    if (!firstError) firstError = $('#dtsc-delivery-schedule-section');
                }
            }

            // Delivery quote validation — skip for special trip (processes as collection)
            if (this.deliveryMethod === 'delivery' && this.quoteStatus !== 'special-trip') {
                if (this.quoteStatus === 'none' || this.quoteStatus === 'loading') {
                    valid = false;
                    errorMessages.push('Please wait for your delivery quote or enter a complete delivery address');
                    if (!firstError) firstError = $('#dtsc-quote-panel');
                } else if (this.quoteStatus === 'not-serviceable') {
                    valid = false;
                    errorMessages.push('Delivery is not available to your area. Please request a special trip or switch to collection.');
                    if (!firstError) firstError = $('#dtsc-quote-panel');
                } else if (this.quoteStatus === 'error') {
                    valid = false;
                    errorMessages.push('Could not get a delivery quote. Please try again.');
                    if (!firstError) firstError = $('#dtsc-quote-panel');
                }
                // quoteStatus === 'ok' or 'special-trip' — allowed to proceed
            }

            // Payment method
            if (!$('input[name="payment_method"]:checked').length && $('input[name="payment_method"]').length) {
                valid = false;
                errorMessages.push('Please select a payment method');
                if (!firstError) firstError = $('.dtsc-payment-section');
            }

            // Terms — always required when checkbox exists
            var $tc = $('#dtsc-terms-checkbox');
            if ($tc.length && !$tc.is(':checked')) {
                $('#dtsc-terms-error').text(dtscCheckout.i18n.termsRequired).show();
                $('#dtsc-terms-wrap').addClass('dtsc-terms-has-error');
                valid = false;
                errorMessages.push('Please accept the terms and conditions');
                if (!firstError) firstError = $('#dtsc-terms-wrap');
            }

            // Show summary of errors at the top of the form
            if (!valid && errorMessages.length) {
                var summaryHtml = '<div id="dtsc-validation-summary" class="dtsc-validation-summary" role="alert">';
                summaryHtml += '<strong>Please fix the following to place your order:</strong><ul>';
                for (var j = 0; j < errorMessages.length; j++) {
                    summaryHtml += '<li>' + errorMessages[j] + '</li>';
                }
                summaryHtml += '</ul></div>';
                $('.dtsc-checkout-form').prepend(summaryHtml);
            }

            if (firstError && firstError.length) {
                var scrollTarget = $('#dtsc-validation-summary').length ? $('#dtsc-validation-summary') : firstError;
                $('html, body').animate({ scrollTop: scrollTarget.offset().top - 100 }, 400);
            }
            console.log('[DTSC] validateForm result:', valid, 'errors:', errorMessages);
            return valid;
        },

        /* ── Copy fields ──────────────────────────────────
         *
         * Copies the customer's shipping ADDRESS into the billing ADDRESS
         * fields when "billing same as delivery" is checked. We deliberately
         * do NOT copy first_name / last_name / company / email / phone:
         *
         *   - The billing name is the buyer (from the Contact section).
         *   - The shipping name is the recipient (set by syncContactToShipping
         *     for self-receiving orders, or supplied via dtsc_recipient_*
         *     for gift orders).
         *
         * Copying names in either direction was the original source of the
         * confusion between "buyer" and "recipient". Keep this function
         * strictly an address-only copy.
         * ─────────────────────────────────────────────── */

        /* ── Branded quote-card helpers ──────────────────
         *
         * Three small helpers used by the quote-result renderer below.
         * They live here as DTSC methods so they can be unit-called and
         * so the rendering code stays readable. The visual structure is
         * always the same:
         *   ┌────────────────────────────┐
         *   │ Delivery to: <address>     │  ← header
         *   │ <body content for state>   │  ← varies per state
         *   │ Powered by 🏷 Delicate …    │  ← footer
         *   └────────────────────────────┘
         * ─────────────────────────────────────────────── */

        // Build a single-line, human-readable address from whatever the
        // customer has typed into the shipping fields so far. Returns ''
        // if no useful address has been entered yet — callers can fall
        // back to a generic label in that case.
        getFormattedShippingAddress: function () {
            var pieces = [
                ($('#shipping_address_1').val() || '').trim(),
                ($('#shipping_address_2').val() || '').trim(),
                ($('#shipping_city').val()      || '').trim(),
                ($('#shipping_state').val()     || '').trim(),
                ($('#shipping_postcode').val()  || '').trim()
            ];
            return pieces.filter(function (p) { return p; }).join(', ');
        },

        // Escape user-supplied strings before injecting them into HTML
        // we build by string concatenation. Small, dependency-free.
        escapeHtml: function (str) {
            if (str === null || str === undefined) return '';
            return String(str)
                .replace(/&/g, '&amp;')
                .replace(/</g, '&lt;')
                .replace(/>/g, '&gt;')
                .replace(/"/g, '&quot;')
                .replace(/'/g, '&#39;');
        },

        // Build the full quote-card HTML. `state` is one of:
        //   'success' | 'loading' | 'not-serviceable' | 'error'
        // `bodyHtml` is the state-specific middle content (already escaped
        // / trusted markup that we construct ourselves below).
        buildQuoteCard: function (state, bodyHtml) {
            var address = this.escapeHtml(this.getFormattedShippingAddress()) ||
                          '<span class="dtsc-quote-address-pending">Address not yet entered</span>';

            var header =
                '<div class="dtsc-quote-card-header">' +
                    '<p class="dtsc-quote-header-label">Delivery to</p>' +
                    '<p class="dtsc-quote-header-address">' + address + '</p>' +
                '</div>';

            var footer =
                '<div class="dtsc-quote-card-footer">' +
                    '<span class="dtsc-quote-poweredby-label">Powered by</span>' +
                    '<span class="dtsc-quote-poweredby-name">Delicate Courier</span>' +
                '</div>';

            return '<div class="dtsc-quote-card dtsc-quote-card-' + state + '">' +
                       header +
                       '<div class="dtsc-quote-card-body">' + bodyHtml + '</div>' +
                       footer +
                   '</div>';
        },

        copyShippingToBilling: function () {
            var addressFields = ['address_1', 'address_2', 'city', 'state', 'postcode', 'country'];
            for (var i = 0; i < addressFields.length; i++) {
                var v = $('#shipping_' + addressFields[i]).val();
                if (v) $('#billing_' + addressFields[i]).val(v);
            }
            // Always ensure country is set
            if (!$('#billing_country').val()) {
                $('#billing_country').val('ZA');
            }
            $('#billing_place_id').val($('#shipping_place_id').val());
            $('#billing_latitude').val($('#shipping_latitude').val());
            $('#billing_longitude').val($('#shipping_longitude').val());
        },

        syncContactToShipping: function () {
            // Copy name from contact info to shipping hidden fields
            $('#shipping_first_name').val($('#billing_first_name').val());
            $('#shipping_last_name').val($('#billing_last_name').val());
        },

        copyContactToBilling: function () {
            // For collection, ensure billing country is set
            if (!$('#billing_country').val()) {
                $('#billing_country').val('ZA').trigger('change');
            }
        },

        /* ── Ensure billing address fields are populated for collection orders ── */
        ensureBillingAddressForCollection: function () {
            // If billing address fields are already filled (user entered them), skip
            var addr1 = ($('#billing_address_1').val() || '').trim();
            if (addr1) return;

            // Populate with a placeholder address so WooCommerce can process the order.
            // WC requires billing_address_1, billing_city, billing_postcode, billing_state.
            // Use store/collection address values.
            var $form = $('form.dtsc-checkout-form');

            // Inject/update hidden billing address fields into the form data via hidden inputs
            var storeDefaults = [
                { id: 'billing_address_1', name: 'billing_address_1', val: '5 Graham Road, Stocks Centre' },
                { id: 'billing_address_2', name: 'billing_address_2', val: 'Shere, Silverlakes' },
                { id: 'billing_city',      name: 'billing_city',      val: 'Pretoria' },
                { id: 'billing_state',     name: 'billing_state',     val: 'GP' },
                { id: 'billing_postcode',  name: 'billing_postcode',  val: '0081' },
                { id: 'billing_country',   name: 'billing_country',   val: 'ZA' },
            ];

            storeDefaults.forEach(function (f) {
                var $el = $('#' + f.id);
                if ($el.length) {
                    // Visible/hidden WC field exists — set its value
                    if (!$el.val()) {
                        $el.val(f.val);
                    }
                } else {
                    // Field doesn't exist in DOM — inject a hidden input
                    var existing = $form.find('input[name="' + f.name + '"][data-dtsc-fallback]');
                    if (existing.length) {
                        existing.val(f.val);
                    } else {
                        $form.append(
                            '<input type="hidden" data-dtsc-fallback="1" name="' + f.name + '" value="' + f.val + '" />'
                        );
                    }
                }
            });
        },

        /* ── Payment Toggle ─────────────────────────────── */
        initPaymentToggle: function () {
            $(document).on('change', 'input[name="payment_method"]', function () {
                var selected = $(this).val();
                $('.payment_box').hide();
                // Show description for selected gateway
                var $box = $('.payment_box.payment_method_' + selected);
                // Only show if it has real content (not staff-only hidden boxes)
                if ($box.length && !$box.hasClass('dtsc-staff-hidden')) {
                    $box.slideDown(200);
                }
                $('.wc_payment_method').removeClass('dtsc-payment-active');
                $(this).closest('.wc_payment_method').addClass('dtsc-payment-active');
            });
            $('input[name="payment_method"]:checked').closest('.wc_payment_method').addClass('dtsc-payment-active');

            // Hide staff-only descriptions with a CSS class (non-destructive)
            this.tagStaffDescriptions();
            $(document.body).on('updated_checkout', $.proxy(this.tagStaffDescriptions, this));
        },

        /**
         * Tag payment descriptions containing "staff use only" with a CSS class.
         * The <li> (radio + label) stays visible; only the description box is hidden.
         */
        tagStaffDescriptions: function () {
            $('.payment_box').each(function () {
                var txt = $(this).text().toLowerCase();
                if (txt.indexOf('staff use only') > -1 || txt.indexOf('for staff') > -1) {
                    $(this).addClass('dtsc-staff-hidden').hide();
                }
            });
        },

        /* ── Coupons ────────────────────────────────────── */
        applyCoupon: function () {
            var code = $('#dtsc-coupon-code').val().trim();
            if (!code) {
                $('#dtsc-coupon-message').html('<span class="dtsc-coupon-error-msg">' + dtscCheckout.i18n.couponEmpty + '</span>').show();
                return;
            }

            var $btn = $('#dtsc-apply-coupon');
            var $msg = $('#dtsc-coupon-message');
            $btn.prop('disabled', true).text('Applying…');
            $msg.hide();

            // WooCommerce coupon handlers use /?wc-ajax=apply_coupon, NOT admin-ajax.php
            var wcAjaxUrl = dtscCheckout.wcAjaxUrl.replace('%%endpoint%%', 'apply_coupon');

            $.ajax({
                url: wcAjaxUrl,
                type: 'POST',
                data: {
                    coupon_code: code,
                    security: dtscCheckout.applyCouponNonce
                },
                success: function (res) {
                    $btn.prop('disabled', false).text('Apply');

                    if (res && typeof res === 'string') {
                        // WC returns HTML notices
                        var isError = res.indexOf('woocommerce-error') !== -1 ||
                                      (res.indexOf('error') !== -1 && res.indexOf('woocommerce-message') === -1);

                        if (isError) {
                            var errorText = res.replace(/<[^>]*>/g, '').trim();
                            $msg.html('<span class="dtsc-coupon-error-msg">' + (errorText || dtscCheckout.i18n.couponError) + '</span>').show();
                        } else {
                            $msg.html('<span class="dtsc-coupon-success">' + dtscCheckout.i18n.couponApplied + '</span>').show();
                            $('#dtsc-coupon-code').val('');
                            self.updateOrderReview();
                            setTimeout(function () { location.reload(); }, 1000);
                        }
                    } else {
                        // Non-string response — could be empty on success in some WC versions
                        $msg.html('<span class="dtsc-coupon-success">' + dtscCheckout.i18n.couponApplied + '</span>').show();
                        $('#dtsc-coupon-code').val('');
                        self.updateOrderReview();
                        setTimeout(function () { location.reload(); }, 1000);
                    }
                },
                error: function () {
                    $btn.prop('disabled', false).text('Apply');
                    $msg.html('<span class="dtsc-coupon-error-msg">' + dtscCheckout.i18n.couponError + '</span>').show();
                }
            });
        },

        removeCoupon: function (code) {
            if (!code) return;

            var wcAjaxUrl = dtscCheckout.wcAjaxUrl.replace('%%endpoint%%', 'remove_coupon');

            $.ajax({
                url: wcAjaxUrl,
                type: 'POST',
                data: {
                    coupon: code,
                    security: dtscCheckout.removeCouponNonce
                },
                success: function () {
                    self.updateOrderReview();
                    setTimeout(function () { location.reload(); }, 500);
                }
            });
        },
    };

    $(function () { DTSC.init(); });
    
    // Expose globally for cross-script communication (address autocomplete, etc.)
    window.DTSC = DTSC;

})(jQuery);
