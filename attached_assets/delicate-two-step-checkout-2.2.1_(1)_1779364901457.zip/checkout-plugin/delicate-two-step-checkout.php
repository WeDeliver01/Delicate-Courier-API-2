<?php
/**
 * Plugin Name: Delicate Two-Step Checkout
 * Plugin URI:  https://delicatecourier.co.za
 * Description: A two-step WooCommerce Classic Checkout with Google Places address autocomplete and courier serviceability/quote integration.
 * Version:     2.2.1
 * Author:      Delicate Courier
 * Author URI:  https://delicatecourier.co.za
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * WC requires at least: 7.0
 * License:     GPL-2.0+
 * Text Domain: delicate-two-step-checkout
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'DTSC_VERSION', '2.2.1' );
define( 'DTSC_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'DTSC_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'DTSC_PLUGIN_BASENAME', plugin_basename( __FILE__ ) );

/**
 * Check for WooCommerce dependency.
 */
function dtsc_check_woocommerce() {
    if ( ! class_exists( 'WooCommerce' ) ) {
        add_action( 'admin_notices', function () {
            echo '<div class="error"><p><strong>Delicate Two-Step Checkout</strong> requires WooCommerce to be installed and active.</p></div>';
        } );
        return false;
    }
    return true;
}

/**
 * Initialize the plugin.
 */
function dtsc_init() {
    if ( ! dtsc_check_woocommerce() ) {
        return;
    }

    // Load includes.
    require_once DTSC_PLUGIN_DIR . 'includes/class-admin-settings.php';
    require_once DTSC_PLUGIN_DIR . 'includes/class-frontend-checkout.php';
    require_once DTSC_PLUGIN_DIR . 'includes/class-ajax-quote-v2.php';
    require_once DTSC_PLUGIN_DIR . 'includes/class-order-meta.php';

    // Init classes.
    new DTSC_Admin_Settings();
    new DTSC_Frontend_Checkout();
    new DTSC_Ajax_Quote_V2();
    new DTSC_Order_Meta();
}
add_action( 'plugins_loaded', 'dtsc_init' );

/**
 * Intercept Delicate Courier Platform API requests to inject the WooCommerce
 * order number as a custom tracking reference in the shipment payload.
 *
 * DCP sends orders to its platform via wp_remote_request to /api/webhooks/plugin/order.
 * We hook into http_request_args to modify the JSON body before it's sent,
 * adding 'custom_tracking_reference' so the platform can pass it to Shiplogic
 * as the custom waybill reference.
 */
add_filter( 'http_request_args', 'dtsc_inject_custom_tracking_ref', 10, 2 );
function dtsc_inject_custom_tracking_ref( $parsed_args, $url ) {
    // Only intercept POST requests to the DCP platform order endpoint
    if ( empty( $parsed_args['method'] ) || $parsed_args['method'] !== 'POST' ) {
        return $parsed_args;
    }

    // Hard-coded platform host check. Accepts:
    //   1. The v2.1.0+ courier plugin's DCP_PLATFORM_BASE_URL constant
    //      (lets a future host change propagate without re-shipping this plugin).
    //   2. The known production host webhooks2.delicatecourier.co.za.
    //   3. Defensive: the legacy api2 host, in case an older DCP plugin is active.
    $allowed_hosts = array(
        'webhooks2.delicatecourier.co.za',
        'api2.delicatecourier.co.za',
    );
    if ( defined( 'DCP_PLATFORM_BASE_URL' ) ) {
        $constant_host = wp_parse_url( DCP_PLATFORM_BASE_URL, PHP_URL_HOST );
        if ( $constant_host ) {
            $allowed_hosts[] = $constant_host;
        }
    }
    $url_host = wp_parse_url( $url, PHP_URL_HOST );
    if ( ! $url_host || ! in_array( $url_host, $allowed_hosts, true ) ) {
        return $parsed_args;
    }

    if ( strpos( $url, '/api/webhooks/plugin/order' ) === false ) {
        return $parsed_args;
    }

    // Decode the JSON body
    $body = isset( $parsed_args['body'] ) ? $parsed_args['body'] : '';
    if ( empty( $body ) || ! is_string( $body ) ) {
        return $parsed_args;
    }
    $data = json_decode( $body, true );
    if ( ! is_array( $data ) ) {
        return $parsed_args;
    }

    // Inject the order number as custom_tracking_reference
    $order_number = isset( $data['order_number'] ) ? $data['order_number'] : '';
    if ( ! empty( $order_number ) ) {
        $data['custom_tracking_reference'] = $order_number;
    }

    // Also inject the original shipping rate (pre-markup) for correct shipment booking
    $woo_order_id = isset( $data['woo_order_id'] ) ? intval( $data['woo_order_id'] ) : 0;
    if ( $woo_order_id > 0 ) {
        $order = wc_get_order( $woo_order_id );
        if ( $order ) {
            $original_rate = $order->get_meta( '_dcp_original_shipping_rate' );
            if ( $original_rate && floatval( $original_rate ) > 0 ) {
                $data['original_shipping_rate'] = floatval( $original_rate );
            }
            $data['custom_tracking_reference'] = $order->get_order_number();
        }
    }

    // Re-encode and update the request body
    $parsed_args['body'] = wp_json_encode( $data );

    return $parsed_args;
}

/**
 * Tell WooCommerce the cart never needs shipping on the frontend.
 * Our plugin handles delivery/collection entirely via JS + order meta.
 */
add_filter( 'woocommerce_cart_needs_shipping', 'dtsc_disable_wc_shipping' );
function dtsc_disable_wc_shipping( $needs_shipping ) {
    if ( is_admin() && ! wp_doing_ajax() ) {
        return $needs_shipping;
    }
    return false;
}
add_filter( 'woocommerce_cart_no_shipping_available_html', '__return_empty_string' );
add_filter( 'woocommerce_no_shipping_available_html', '__return_empty_string' );

/**
 * Add our courier shipping cost as a WC cart fee.
 *
 * CRITICAL: This hook fires on every calculate_totals() call.
 * WC's add_fee() does NOT deduplicate — calling it twice adds two fees.
 * We use a static flag to prevent re-entry within the same request.
 */
add_action( 'woocommerce_cart_calculate_fees', 'dtsc_add_shipping_as_fee' );
function dtsc_add_shipping_as_fee( $cart ) {
    // Static flag to prevent re-entry within the same request
    static $already_added = false;
    if ( $already_added ) {
        return;
    }

    if ( is_admin() && ! defined( 'DOING_AJAX' ) ) {
        return;
    }
    if ( ! WC()->session ) {
        return;
    }

    // Read cost from session (primary source)
    $cost = floatval( WC()->session->get( 'dcp_checkout_shipping_cost', 0 ) );

    // Fallback: read from POST data (set by our JS before submission)
    // phpcs:ignore WordPress.Security.NonceVerification.Missing
    if ( $cost <= 0 && ! empty( $_POST['dtsc_shipping_cost'] ) ) {
        $post_cost = floatval( $_POST['dtsc_shipping_cost'] );
        if ( $post_cost > 0 ) {
            $cost = $post_cost;
            // Also write it to session so it's available for the order meta handler
            WC()->session->set( 'dcp_checkout_shipping_cost', $cost );
        }
    }

    if ( $cost <= 0 ) {
        return;
    }

    // Don't add fee if collection (and not special trip)
    $fulfillment = WC()->session->get( 'dtsc_fulfillment_type', 'delivery' );
    $special = WC()->session->get( 'dtsc_special_trip', 'no' );

    // Also check POST fallback for fulfillment type
    // phpcs:ignore WordPress.Security.NonceVerification.Missing
    if ( ! $fulfillment && ! empty( $_POST['dtsc_delivery_method'] ) ) {
        $fulfillment = sanitize_text_field( $_POST['dtsc_delivery_method'] );
    }
    // phpcs:ignore WordPress.Security.NonceVerification.Missing
    if ( ! empty( $_POST['dtsc_special_trip'] ) && $_POST['dtsc_special_trip'] === 'yes' ) {
        $special = 'yes';
    }

    if ( ( $fulfillment === 'collect' || $fulfillment === 'collection' ) && $special !== 'yes' ) {
        return;
    }

    // Check if fee already exists (safety net)
    $fees = $cart->get_fees();
    foreach ( $fees as $fee ) {
        if ( $fee->name === __( 'Delivery', 'delicate-two-step-checkout' ) ) {
            $already_added = true;
            return;
        }
    }

    $already_added = true;
    $cart->add_fee( __( 'Delivery', 'delicate-two-step-checkout' ), $cost, true );
}

/**
 * Strip any shipping packages/methods added by other plugins
 * so they don't add their own shipping cost on top of our fee.
 */
add_filter( 'woocommerce_shipping_packages', 'dtsc_strip_third_party_shipping' );
function dtsc_strip_third_party_shipping( $packages ) {
    if ( is_admin() && ! wp_doing_ajax() ) {
        return $packages;
    }
    // Return empty packages — we handle shipping via our cart fee
    return array();
}

/**
 * CRITICAL: Strip shipping errors during checkout validation.
 *
 * Even with woocommerce_cart_needs_shipping returning false, other plugins
 * or WC itself may add shipping errors during
 * the wc-ajax=checkout request. This hook fires AFTER all validation
 * and removes any shipping-related errors so the order goes through.
 */
add_action( 'woocommerce_after_checkout_validation', 'dtsc_strip_shipping_errors', 9999, 2 );
function dtsc_strip_shipping_errors( $data, $errors ) {
    // Remove all shipping-related errors.
    $codes = $errors->get_error_codes();
    foreach ( $codes as $code ) {
        // WC uses 'shipping' as the error code for shipping validation failures.
        if ( $code === 'shipping' ) {
            $errors->remove( $code );
            continue;
        }
        // Also check error messages for the word "shipping" from other plugins.
        $messages = $errors->get_error_messages( $code );
        foreach ( $messages as $msg ) {
            if ( stripos( $msg, 'shipping' ) !== false && stripos( $msg, 'selected' ) !== false ) {
                $errors->remove( $code );
                break;
            }
        }
    }
}

/**
 * Also override WC's shipping validation at the cart level during checkout.
 * WC_Checkout calls WC()->cart->needs_shipping() during validate_checkout —
 * if another plugin re-enables it, this ensures chosen_shipping_methods passes.
 */
add_filter( 'woocommerce_shipping_chosen_method', 'dtsc_force_shipping_method', 9999 );
function dtsc_force_shipping_method( $method ) {
    if ( is_admin() && ! wp_doing_ajax() ) {
        return $method;
    }
    // Return a fake method ID so WC thinks a method was chosen.
    return $method ? $method : 'free_shipping:0';
}

/**
 * Ensure chosen_shipping_methods session is never empty during checkout.
 * WC checks this array during validation — if empty, it triggers the error.
 */
add_action( 'woocommerce_checkout_process', 'dtsc_ensure_shipping_method_chosen', 1 );
function dtsc_ensure_shipping_method_chosen() {
    if ( ! WC()->session ) return;
    $chosen = WC()->session->get( 'chosen_shipping_methods' );
    if ( empty( $chosen ) || ! is_array( $chosen ) || empty( $chosen[0] ) ) {
        WC()->session->set( 'chosen_shipping_methods', array( 'free_shipping:0' ) );
    }
}

/**
 * Clear stale checkout session data every time the checkout page loads.
 * This ensures no old addresses, shipping quotes, or fulfillment flags
 * carry over between sessions or page refreshes.
 */
add_action( 'template_redirect', 'dtsc_clear_checkout_session_on_load' );
function dtsc_clear_checkout_session_on_load() {
    global $post;
    if ( ! $post || ! has_shortcode( $post->post_content, 'delicate_two_step_checkout' ) ) {
        return;
    }
    // Don't clear on order-received or order-pay pages.
    if ( isset( $_GET['order-received'] ) || isset( $_GET['order-pay'] ) || isset( $_GET['pay_for_order'] ) ) {
        return;
    }
    if ( ! function_exists( 'WC' ) || ! WC()->session ) {
        return;
    }
    // Clear our plugin's session data so the page starts fresh.
    WC()->session->set( 'dtsc_fulfillment_type', null );
    WC()->session->set( 'dtsc_special_trip', null );
    WC()->session->set( 'dtsc_courier_quote', null );
    WC()->session->set( 'dtsc_special_trip_estimate', null );
    WC()->session->set( 'dcp_checkout_shipping_cost', null );
    // Invalidate WC's shipping cache so rates recalculate fresh.
    $packages = WC()->cart ? WC()->cart->get_shipping_packages() : array();
    foreach ( $packages as $key => $pkg ) {
        WC()->session->__unset( 'shipping_for_package_' . $key );
    }
}

/**
 * Prevent page caching on our checkout page.
 * Tells caching plugins (LiteSpeed, WP Rocket, W3TC, etc.) not to cache this page.
 */
add_action( 'template_redirect', 'dtsc_prevent_checkout_caching' );
function dtsc_prevent_checkout_caching() {
    global $post;
    if ( ! $post || ! has_shortcode( $post->post_content, 'delicate_two_step_checkout' ) ) {
        return;
    }
    if ( ! defined( 'DONOTCACHEPAGE' ) ) {
        define( 'DONOTCACHEPAGE', true );
    }
    if ( ! defined( 'DONOTCACHEOBJECT' ) ) {
        define( 'DONOTCACHEOBJECT', true );
    }
    if ( ! defined( 'DONOTCACHEDB' ) ) {
        define( 'DONOTCACHEDB', true );
    }
    // LiteSpeed Cache specific.
    do_action( 'litespeed_control_set_nocache', 'DTSC checkout page' );
    // Send no-cache headers.
    nocache_headers();
}

/**
 * Find the URL of the page that contains [delicate_two_step_checkout].
 *
 * Priority:
 *  1. Admin-configured custom URL (dtsc_custom_checkout_url option).
 *  2. Auto-discovered: searches published pages for the shortcode.
 *  3. Falls back to WooCommerce checkout URL.
 *
 * Result is cached in a transient for 1 hour to avoid repeated DB queries.
 */
function dtsc_get_checkout_page_url() {
    // 1. Manual override always wins.
    $custom = trim( get_option( 'dtsc_custom_checkout_url', '' ) );
    if ( $custom ) {
        return trailingslashit( $custom );
    }

    // 2. Try cached value.
    $cached = get_transient( 'dtsc_shortcode_page_url' );
    if ( $cached ) {
        return $cached;
    }

    // 3. Search all published pages for the shortcode.
    $pages = get_posts( array(
        'post_type'      => 'page',
        'post_status'    => 'publish',
        'posts_per_page' => -1,
        'fields'         => 'ids',
    ) );

    foreach ( $pages as $page_id ) {
        $content = get_post_field( 'post_content', $page_id );
        if ( $content && has_shortcode( $content, 'delicate_two_step_checkout' ) ) {
            $found_url = trailingslashit( get_permalink( $page_id ) );
            set_transient( 'dtsc_shortcode_page_url', $found_url, HOUR_IN_SECONDS );
            return $found_url;
        }
    }

    // 4. Nothing found — fall back to WC default.
    return wc_get_checkout_url();
}

// Clear the cached URL whenever a page is saved (shortcode may have moved).
add_action( 'save_post', 'dtsc_clear_shortcode_page_cache' );
function dtsc_clear_shortcode_page_cache() {
    delete_transient( 'dtsc_shortcode_page_url' );
}

/**
 * Redirect to the correct order-received page after checkout.
 *
 * WooCommerce builds the thank-you URL from its own Checkout page permalink.
 * When [delicate_two_step_checkout] lives on a DIFFERENT page, this produces
 * a URL that renders the wrong template (empty cart / default WC checkout).
 *
 * We intercept the URL and rebuild it using the page that actually has the
 * shortcode, so the customer always lands on the correct order confirmation.
 */
add_filter( 'woocommerce_get_checkout_order_received_url', 'dtsc_fix_order_received_url', 999, 2 );
function dtsc_fix_order_received_url( $url, $order ) {
    $checkout_url = dtsc_get_checkout_page_url();
    $separator = ( strpos( $checkout_url, '?' ) !== false ) ? '&' : '?';
    return $checkout_url . $separator . 'order-received=' . $order->get_id() . '&key=' . $order->get_order_key();
}

/**
 * Fix the order-pay URL for PayFast and other redirect gateways.
 *
 * WC builds the order-pay URL from its registered checkout page using pretty
 * permalinks (/checkout/order-pay/123/). When our shortcode lives on a
 * DIFFERENT page, that pretty-permalink format won't set the query var.
 *
 * We rewrite the URL so it points to our shortcode page using query-string
 * parameters (?order-pay=123&pay_for_order=true&key=xxx) which the shortcode
 * handler in render_shortcode() already detects.
 */
add_filter( 'woocommerce_get_checkout_payment_url', 'dtsc_fix_order_pay_url', 999, 2 );
function dtsc_fix_order_pay_url( $url, $order ) {
    $checkout_url = dtsc_get_checkout_page_url();
    $separator    = ( strpos( $checkout_url, '?' ) !== false ) ? '&' : '?';
    return $checkout_url . $separator . http_build_query( array(
        'order-pay'     => $order->get_id(),
        'pay_for_order' => 'true',
        'key'           => $order->get_order_key(),
    ) );
}

/**
 * Flush rewrite rules on activation to ensure WC endpoints work on our page.
 */
register_activation_hook( __FILE__, function() {
    update_option( 'dtsc_flush_rewrite_rules', 'yes' );
    flush_rewrite_rules();
});
add_action( 'init', function() {
    if ( get_option( 'dtsc_flush_rewrite_rules' ) === 'yes' ) {
        flush_rewrite_rules();
        delete_option( 'dtsc_flush_rewrite_rules' );
    }
}, 999 );

/**
 * Order status rules for offline payment methods.
 *
 * Consolidated into a SINGLE hook (woocommerce_thankyou) to prevent multiple
 * status transitions — each transition fires a WooCommerce webhook, so
 * having three hooks all setting the same status was sending 2-3 duplicate
 * webhook calls to BaseCloud per order.
 *
 * - COD / Paid in Store  → PROCESSING (payment already taken)
 * - BACS / Cheque        → ON HOLD (awaiting bank transfer confirmation)
 */
add_action( 'woocommerce_thankyou', 'dtsc_set_offline_order_status', 10, 1 );
function dtsc_set_offline_order_status( $order_id ) {
    $order = wc_get_order( $order_id );
    if ( ! $order ) return;

    $payment_method = $order->get_payment_method();

    if ( in_array( $payment_method, array( 'cod', 'pay_in_store' ), true ) ) {
        if ( ! $order->has_status( 'processing' ) ) {
            $order->update_status( 'processing', 'Paid in Store — payment taken, order confirmed.' );
        }
        return;
    }

    if ( in_array( $payment_method, array( 'bacs', 'cheque' ), true ) ) {
        if ( ! $order->has_status( 'on-hold' ) ) {
            $order->update_status( 'on-hold', sprintf( 'Awaiting payment confirmation via %s.', $order->get_payment_method_title() ) );
        }
        return;
    }
}

/**
 * Force COD initial status to processing so WooCommerce never auto-holds it
 * before our thankyou hook runs. This prevents a pending → on-hold → processing
 * double transition that would fire two webhooks.
 */
add_filter( 'woocommerce_cod_process_payment_order_status', 'dtsc_cod_initial_status', 10, 2 );
function dtsc_cod_initial_status( $status, $order ) {
    return 'processing';
}


/**
 * Activation hook — set defaults.
 */
function dtsc_activate() {
    $defaults = array(
        'dtsc_google_api_key'       => '',
        'dtsc_country_restriction'  => 'za',
        'dtsc_autocomplete_billing' => 'yes',
        'dtsc_autocomplete_shipping'=> 'yes',
        'dtsc_require_street_number'=> 'yes',
        'dtsc_require_address_2'    => 'no',
        'dtsc_courier_timeout'      => 15,
        'dtsc_courier_enabled'      => 'no',
        'dtsc_bakery_address'       => '5 Graham Road, Shere, Pretoria, South Africa',
        'dtsc_special_trip_rate_min' => 9,
        'dtsc_special_trip_rate_max' => 12,
        'dtsc_special_trip_min_charge' => 150,
        'dtsc_special_trip_rate_low' => '9',
        'dtsc_special_trip_rate_high' => '12',
        'dtsc_bakery_origin'        => 'Stocks Centre, 5 Graham Road, Shere, Pretoria, South Africa',
    );
    foreach ( $defaults as $key => $value ) {
        if ( false === get_option( $key ) ) {
            add_option( $key, $value );
        }
    }

    // Clean up obsolete options from earlier versions. The endpoint setting
    // was never read by any code path; the integration is hard-coded to the
    // Delicate Courier Platform plugin's dcp_shiplogic_fetch_rates() in 1.9.5+.
    delete_option( 'dtsc_courier_endpoint' );

    // Force PHP OPcache to invalidate this plugin's files so a fresh upload
    // is picked up immediately, not 30+ minutes later when opcache happens
    // to recompile. Silently no-op on hosts where opcache_reset() is
    // disabled or unavailable. This is what makes deactivate-reactivate
    // reliably ship new code after a re-upload.
    if ( function_exists( 'opcache_reset' ) ) {
        @opcache_reset();
    }
}
register_activation_hook( __FILE__, 'dtsc_activate' );

/**
 * Add settings link on plugins page.
 */
function dtsc_settings_link( $links ) {
    $url  = admin_url( 'admin.php?page=dtsc-settings' );
    $link = '<a href="' . esc_url( $url ) . '">Settings</a>';
    array_unshift( $links, $link );
    return $links;
}
add_filter( 'plugin_action_links_' . DTSC_PLUGIN_BASENAME, 'dtsc_settings_link' );

/**
 * CRITICAL SAFETY NET — Force `ship_to_different_address` to 1 on every
 * checkout submission that targets our plugin.
 *
 * Why this exists
 * ----------------
 * WooCommerce's checkout processor (WC_Checkout::process_checkout) reads
 * `$_POST['ship_to_different_address']`. When it is missing or falsy WC
 * copies every `billing_*` field into the matching `shipping_*` field on
 * the order — overwriting whatever the customer actually typed into the
 * delivery address fields. That is exactly the bug the client reported:
 * ShipLogic shipments were being booked to billing addresses because at
 * order-create time WC had silently merged the two address records.
 *
 * The frontend already injects this flag in two places (a hidden input on
 * the form and an explicit append in the AJAX submit code in
 * two-step-checkout.js). This hook is the third and final guard: even if
 * those are stripped, blocked, or removed by a future change, the server
 * will still see ship_to_different_address=1 and keep the two addresses
 * separate. Shipping and billing must NEVER overlap in this plugin.
 */
add_action( 'woocommerce_checkout_process', 'dtsc_force_separate_addresses', 1 );
function dtsc_force_separate_addresses() {
    // Only act when a shipping address is actually being submitted —
    // i.e. this is our checkout flow and not some other WC endpoint.
    if ( isset( $_POST['shipping_address_1'] ) || isset( $_POST['dtsc_delivery_method'] ) ) {
        $_POST['ship_to_different_address']     = 1;
        $_REQUEST['ship_to_different_address']  = 1;
    }
}

/**
 * Defensive second pass — at order-create time, re-set both addresses
 * directly from the raw POST values so neither side can leak into the other.
 *
 * Runs at priority 1 (BEFORE DTSC_Order_Meta::save_order_meta which is at 10).
 * This guarantees billing and shipping are written to the order as two
 * independent records, regardless of any third-party filter that might
 * have copied one into the other in the meantime.
 */
add_action( 'woocommerce_checkout_create_order', 'dtsc_enforce_address_separation', 1, 2 );
function dtsc_enforce_address_separation( $order, $data ) {
    // Map of WC order setter → POST key for the BILLING address.
    $billing_map = array(
        'set_billing_first_name' => 'billing_first_name',
        'set_billing_last_name'  => 'billing_last_name',
        'set_billing_company'    => 'billing_company',
        'set_billing_address_1'  => 'billing_address_1',
        'set_billing_address_2'  => 'billing_address_2',
        'set_billing_city'       => 'billing_city',
        'set_billing_state'      => 'billing_state',
        'set_billing_postcode'   => 'billing_postcode',
        'set_billing_country'    => 'billing_country',
        'set_billing_email'      => 'billing_email',
        'set_billing_phone'      => 'billing_phone',
    );

    // Map of WC order setter → POST key for the SHIPPING address.
    $shipping_map = array(
        'set_shipping_first_name' => 'shipping_first_name',
        'set_shipping_last_name'  => 'shipping_last_name',
        'set_shipping_company'    => 'shipping_company',
        'set_shipping_address_1'  => 'shipping_address_1',
        'set_shipping_address_2'  => 'shipping_address_2',
        'set_shipping_city'       => 'shipping_city',
        'set_shipping_state'      => 'shipping_state',
        'set_shipping_postcode'   => 'shipping_postcode',
        'set_shipping_country'    => 'shipping_country',
    );

    // Apply billing first.
    foreach ( $billing_map as $setter => $post_key ) {
        if ( isset( $_POST[ $post_key ] ) && method_exists( $order, $setter ) ) {
            $value = sanitize_text_field( wp_unslash( $_POST[ $post_key ] ) );
            // Email gets its own sanitizer.
            if ( $post_key === 'billing_email' ) {
                $value = sanitize_email( wp_unslash( $_POST[ $post_key ] ) );
            }
            $order->{$setter}( $value );
        }
    }

    // Apply shipping ONLY from shipping_* POST keys. Never fall back to
    // billing values — if a shipping field is empty in POST it stays empty
    // on the order rather than silently inheriting from billing.
    foreach ( $shipping_map as $setter => $post_key ) {
        if ( isset( $_POST[ $post_key ] ) && method_exists( $order, $setter ) ) {
            $value = sanitize_text_field( wp_unslash( $_POST[ $post_key ] ) );
            $order->{$setter}( $value );
        }
    }

    // Phone on shipping is a newer WC field — set it if available and submitted.
    if ( isset( $_POST['shipping_phone'] ) && method_exists( $order, 'set_shipping_phone' ) ) {
        $order->set_shipping_phone( sanitize_text_field( wp_unslash( $_POST['shipping_phone'] ) ) );
    }
}
