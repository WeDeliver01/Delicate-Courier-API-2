<?php
/**
 * Admin Settings Page for Delicate Two-Step Checkout.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class DTSC_Admin_Settings {

    public function __construct() {
        add_action( 'admin_menu', array( $this, 'add_menu_page' ) );
        add_action( 'admin_init', array( $this, 'register_settings' ) );
    }

    /**
     * Add the settings page under WooCommerce menu.
     */
    public function add_menu_page() {
        add_submenu_page(
            'woocommerce',
            'Two-Step Checkout Settings',
            'Two-Step Checkout',
            'manage_woocommerce',
            'dtsc-settings',
            array( $this, 'render_settings_page' )
        );
    }

    /**
     * Register all settings fields.
     */
    public function register_settings() {
        // Google Places section.
        add_settings_section(
            'dtsc_google_section',
            'Google Places Autocomplete',
            function () {
                echo '<p>Configure the Google Maps / Places API integration for address autocomplete.</p>';
            },
            'dtsc-settings'
        );

        $this->add_field( 'dtsc_google_api_key', 'Google API Key', 'text', 'dtsc_google_section', 'Enter your Google Maps Platform API key (must have Places API enabled).' );
        $this->add_field( 'dtsc_country_restriction', 'Country Restriction', 'text', 'dtsc_google_section', 'ISO 3166-1 alpha-2 country code (e.g. za for South Africa). Leave blank for no restriction.' );
        $this->add_field( 'dtsc_autocomplete_billing', 'Autocomplete on Billing Address', 'checkbox', 'dtsc_google_section' );
        $this->add_field( 'dtsc_autocomplete_shipping', 'Autocomplete on Shipping Address', 'checkbox', 'dtsc_google_section' );
        $this->add_field( 'dtsc_require_street_number', 'Require Street Number', 'checkbox', 'dtsc_google_section', 'Require that selected addresses include a street number.' );
        $this->add_field( 'dtsc_require_address_2', 'Require Address Line 2 (Unit/Complex)', 'checkbox', 'dtsc_google_section', 'Require customers to fill in unit/complex/apartment number (recommended for ZA).' );

        // Checkout Page section.
        add_settings_section(
            'dtsc_page_section',
            'Checkout Page',
            function () {
                echo '<p>If your checkout shortcode is on a <strong>different page</strong> than the WooCommerce Checkout page (e.g. a custom page at <code>/checkout/checkout_test/</code>), enter its URL below. This ensures the order-received redirect and all internal links point to the correct page.</p>';
            },
            'dtsc-settings'
        );
        $this->add_field( 'dtsc_custom_checkout_url', 'Custom Checkout Page URL', 'text', 'dtsc_page_section', 'Full URL of the page containing <code>[delicate_two_step_checkout]</code>. Leave blank to use the WooCommerce default checkout page.' );

        // Courier Quote section.
        add_settings_section(
            'dtsc_courier_section',
            'Courier Quote Integration',
            function () {
                echo '<p>Live delivery quotes are fetched from Shiplogic via the <strong>Delicate Courier Platform</strong> plugin. There is no endpoint to configure here — the integration is hard-coded. Ensure the Delicate Courier Platform plugin is installed, activated, and configured (Store ID, Webhook Secret, Shiplogic Bearer Token) on the <strong>Delicate Courier</strong> admin page.</p>';
            },
            'dtsc-settings'
        );

        $this->add_field( 'dtsc_courier_enabled', 'Enable Courier Quoting', 'checkbox', 'dtsc_courier_section', 'When enabled, Step 1 will fetch a live Shiplogic rate via the Delicate Courier Platform plugin before unlocking payment.' );
        $this->add_field( 'dtsc_courier_timeout', 'Courier API Timeout (seconds)', 'number', 'dtsc_courier_section' );

        // Special Trip Delivery Pricing section.
        add_settings_section(
            'dtsc_special_trip_section',
            'Special Trip Delivery Pricing',
            function () {
                echo '<p>When a customer requests delivery to an area outside standard coverage, the checkout calculates an estimated delivery cost based on driving distance from the bakery. The customer sees a price range (min–max per km) before placing the order.</p>';
            },
            'dtsc-settings'
        );

        $this->add_field( 'dtsc_bakery_address', 'Bakery Address (Origin)', 'text', 'dtsc_special_trip_section', 'Full address of the bakery for distance calculation. E.g. <code>5 Graham Road, Shere, Pretoria, South Africa</code>' );
        $this->add_field( 'dtsc_special_trip_rate_min', 'Minimum Rate per km (R)', 'number', 'dtsc_special_trip_section', 'Lower bound of the delivery cost per km. Default: 9.' );
        $this->add_field( 'dtsc_special_trip_rate_max', 'Maximum Rate per km (R)', 'number', 'dtsc_special_trip_section', 'Upper bound of the delivery cost per km. Default: 12.' );
        $this->add_field( 'dtsc_special_trip_min_charge', 'Minimum Delivery Charge (R)', 'number', 'dtsc_special_trip_section', 'Minimum delivery fee regardless of distance. Default: 150.' );

        // Delivery Scheduler section.
        add_settings_section(
            'dtsc_scheduler_section',
            'Delivery Date & Time Scheduler',
            function () {
                echo '<p>Allow customers to choose a delivery date and time. Lead times are read from each product\'s custom field to calculate the earliest available date.</p>';
            },
            'dtsc-settings'
        );

        $this->add_field( 'dtsc_scheduler_enabled', 'Enable Delivery Scheduler', 'checkbox', 'dtsc_scheduler_section', 'Show the date & time picker on the checkout page.' );
        $this->add_field( 'dtsc_scheduler_required', 'Require Delivery Date', 'checkbox', 'dtsc_scheduler_section', 'Customers must select a date and time before proceeding.' );
        $this->add_field( 'dtsc_lead_time_meta_key', 'Lead Time Meta Key', 'text', 'dtsc_scheduler_section', 'The product custom field key that stores lead time in hours (e.g. <code>_lead_time_hours</code>). Default: <code>_lead_time_hours</code>.' );
        $this->add_field( 'dtsc_default_lead_hours', 'Default Lead Time (hours)', 'number', 'dtsc_scheduler_section', 'Lead time if a product has no custom field set. Default: 24.' );
        $this->add_field( 'dtsc_daily_cutoff_hour', 'Daily Cutoff Hour (24h)', 'number', 'dtsc_scheduler_section', 'Orders placed after this hour add an extra day. Default: 14 (2 PM).' );
        $this->add_field( 'dtsc_time_slot_start', 'First Time Slot (hour, 24h)', 'number', 'dtsc_scheduler_section', 'E.g. 8 for 8:00 AM. Default: 8.' );
        $this->add_field( 'dtsc_time_slot_end', 'Last Time Slot (hour, 24h)', 'number', 'dtsc_scheduler_section', 'E.g. 17 for 5:00 PM. Default: 17.' );
        $this->add_field( 'dtsc_time_slot_interval', 'Time Slot Interval (minutes)', 'number', 'dtsc_scheduler_section', 'Gap between available time slots. Default: 60.' );
        $this->add_field( 'dtsc_blocked_days', 'Blocked Days of Week', 'text', 'dtsc_scheduler_section', 'Comma-separated day numbers to block (0=Sun, 1=Mon … 6=Sat). E.g. <code>0</code> to block Sundays.' );
        $this->add_field( 'dtsc_blocked_dates', 'Blocked Specific Dates', 'text', 'dtsc_scheduler_section', 'Comma-separated dates to block (YYYY-MM-DD). E.g. <code>2026-12-25,2026-12-26</code>.' );
        $this->add_field( 'dtsc_max_advance_days', 'Max Advance Booking (days)', 'number', 'dtsc_scheduler_section', 'How far in advance customers can book. Default: 30. Max: 270 (9 months).' );
    }

    /**
     * Helper to register a setting and add a field.
     */
    private function add_field( $id, $title, $type, $section, $description = '' ) {
        register_setting( 'dtsc_settings_group', $id, array(
            'sanitize_callback' => ( $type === 'checkbox' ) ? array( $this, 'sanitize_checkbox' ) : 'sanitize_text_field',
        ) );

        add_settings_field(
            $id,
            $title,
            array( $this, 'render_field' ),
            'dtsc-settings',
            $section,
            array(
                'id'          => $id,
                'type'        => $type,
                'description' => $description,
            )
        );
    }

    /**
     * Render a settings field.
     */
    public function render_field( $args ) {
        $id    = $args['id'];
        $type  = $args['type'];
        $value = get_option( $id, '' );
        $desc  = $args['description'];

        if ( $type === 'checkbox' ) {
            printf(
                '<input type="checkbox" id="%1$s" name="%1$s" value="yes" %2$s /> <label for="%1$s">Enabled</label>',
                esc_attr( $id ),
                checked( $value, 'yes', false )
            );
        } elseif ( $type === 'number' ) {
            printf(
                '<input type="number" id="%1$s" name="%1$s" value="%2$s" class="small-text" min="1" max="270" />',
                esc_attr( $id ),
                esc_attr( $value )
            );
        } else {
            printf(
                '<input type="text" id="%1$s" name="%1$s" value="%2$s" class="regular-text" />',
                esc_attr( $id ),
                esc_attr( $value )
            );
        }

        if ( $desc ) {
            printf( '<p class="description">%s</p>', wp_kses( $desc, array( 'code' => array() ) ) );
        }
    }

    /**
     * Sanitize checkbox values.
     */
    public function sanitize_checkbox( $value ) {
        return ( $value === 'yes' ) ? 'yes' : 'no';
    }

    /**
     * Render the settings page.
     */
    public function render_settings_page() {
        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            return;
        }
        ?>
        <div class="wrap">
            <h1>Delicate Two-Step Checkout Settings</h1>
            <form method="post" action="options.php">
                <?php
                settings_fields( 'dtsc_settings_group' );
                do_settings_sections( 'dtsc-settings' );
                submit_button();
                ?>
            </form>

            <hr />
            <h2>Shortcode</h2>
            <p>Use the shortcode <code>[delicate_two_step_checkout]</code> on your checkout page.</p>
            <p>Make sure to switch from Checkout Blocks to the Classic Checkout shortcode. See the README for detailed instructions.</p>
        </div>
        <?php
    }
}
