<?php
/**
 * AJAX Courier Quote Handler for Delicate Two-Step Checkout.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class DTSC_Ajax_Quote_V2 {

    public function __construct() {
        add_action( 'wp_ajax_dtsc_get_quote', array( $this, 'handle_quote_request' ) );
        add_action( 'wp_ajax_nopriv_dtsc_get_quote', array( $this, 'handle_quote_request' ) );

        // Special trip distance-based estimate.
        add_action( 'wp_ajax_dtsc_special_trip_estimate', array( $this, 'handle_special_trip_estimate' ) );
        add_action( 'wp_ajax_nopriv_dtsc_special_trip_estimate', array( $this, 'handle_special_trip_estimate' ) );
    }

    /**
     * Calculate estimated delivery cost for special trip requests.
     *
     * Uses Google Distance Matrix API to get driving distance from the bakery
     * to the customer's delivery address, then multiplies by the per-km rate
     * range configured in settings.
     */
    public function handle_special_trip_estimate() {
        if ( ! check_ajax_referer( 'dtsc_quote_nonce', 'nonce', false ) ) {
            wp_send_json_error( array( 'message' => 'Security check failed.' ), 403 );
        }

        $destination = sanitize_text_field( wp_unslash( $_POST['destination'] ?? '' ) );
        if ( empty( $destination ) ) {
            wp_send_json_error( array( 'message' => 'No destination address provided.' ) );
        }

        // Get settings.
        $api_key    = get_option( 'dtsc_google_api_key', '' );
        $origin     = get_option( 'dtsc_bakery_address', '' );
        $rate_min   = floatval( get_option( 'dtsc_special_trip_rate_min', 9 ) );
        $rate_max   = floatval( get_option( 'dtsc_special_trip_rate_max', 12 ) );
        $min_charge = floatval( get_option( 'dtsc_special_trip_min_charge', 150 ) );

        if ( $rate_min <= 0 ) $rate_min = 9;
        if ( $rate_max <= 0 ) $rate_max = 12;
        if ( $rate_max < $rate_min ) $rate_max = $rate_min + 3;
        if ( $min_charge <= 0 ) $min_charge = 150;

        // Default origin if not set.
        if ( empty( $origin ) ) {
            $origin = 'Stocks Centre, 5 Graham Road, Shere, Pretoria, South Africa';
        }

        if ( empty( $api_key ) ) {
            wp_send_json_error( array( 'message' => 'Google API key not configured.' ) );
        }

        // Call Google Distance Matrix API.
        $url = add_query_arg( array(
            'origins'      => $origin,
            'destinations' => $destination,
            'mode'         => 'driving',
            'units'        => 'metric',
            'key'          => $api_key,
        ), 'https://maps.googleapis.com/maps/api/distancematrix/json' );

        $response = wp_remote_get( $url, array( 'timeout' => 10 ) );

        if ( is_wp_error( $response ) ) {
            wp_send_json_error( array( 'message' => 'Could not calculate distance. Please try again.' ) );
        }

        $body = json_decode( wp_remote_retrieve_body( $response ), true );

        if ( empty( $body['rows'][0]['elements'][0] ) ||
             $body['rows'][0]['elements'][0]['status'] !== 'OK' ) {
            wp_send_json_error( array( 'message' => 'Could not calculate distance to your address.' ) );
        }

        $element     = $body['rows'][0]['elements'][0];
        $distance_m  = intval( $element['distance']['value'] ); // metres
        $distance_km = round( $distance_m / 1000, 1 );
        $duration    = $element['duration']['text'] ?? '';

        // Calculate cost range.
        $cost_low  = round( $distance_km * $rate_min, 0 );
        $cost_high = round( $distance_km * $rate_max, 0 );

        // Apply minimum charge.
        if ( $cost_low < $min_charge ) $cost_low = $min_charge;
        if ( $cost_high < $min_charge ) $cost_high = $min_charge;

        // Store in session for order meta.
        if ( function_exists( 'WC' ) && WC()->session ) {
            WC()->session->set( 'dtsc_special_trip_estimate', array(
                'distance_km' => $distance_km,
                'cost_low'    => $cost_low,
                'cost_high'   => $cost_high,
                'duration'    => $duration,
                'destination' => $destination,
                'origin'      => $origin,
            ) );
        }

        wp_send_json_success( array(
            'distance_km'    => $distance_km,
            'distance_text'  => $element['distance']['text'],
            'duration_text'  => $duration,
            'cost_low'       => $cost_low,
            'cost_high'      => $cost_high,
            'cost_formatted' => 'R' . number_format( $cost_low, 0 ) . ' – R' . number_format( $cost_high, 0 ),
            'rate_min'       => $rate_min,
            'rate_max'       => $rate_max,
        ) );
    }

    /**
     * Handle the AJAX courier quote request.
     */
    public function handle_quote_request() {
        // Verify nonce.
        if ( ! check_ajax_referer( 'dtsc_quote_nonce', 'nonce', false ) ) {
            wp_send_json_error( array( 'message' => 'Security check failed.' ), 403 );
        }

        // Sanitize inputs.
        $payload = array(
            'first_name' => sanitize_text_field( wp_unslash( $_POST['first_name'] ?? '' ) ),
            'last_name'  => sanitize_text_field( wp_unslash( $_POST['last_name'] ?? '' ) ),
            'email'      => sanitize_email( wp_unslash( $_POST['email'] ?? '' ) ),
            'phone'      => sanitize_text_field( wp_unslash( $_POST['phone'] ?? '' ) ),
            'address_1'  => sanitize_text_field( wp_unslash( $_POST['address_1'] ?? '' ) ),
            'address_2'  => sanitize_text_field( wp_unslash( $_POST['address_2'] ?? '' ) ),
            'city'       => sanitize_text_field( wp_unslash( $_POST['city'] ?? '' ) ),
            'state'      => sanitize_text_field( wp_unslash( $_POST['state'] ?? '' ) ),
            'postcode'   => sanitize_text_field( wp_unslash( $_POST['postcode'] ?? '' ) ),
            'country'    => sanitize_text_field( wp_unslash( $_POST['country'] ?? 'ZA' ) ),
            'place_id'   => sanitize_text_field( wp_unslash( $_POST['place_id'] ?? '' ) ),
            'latitude'   => floatval( $_POST['latitude'] ?? 0 ),
            'longitude'  => floatval( $_POST['longitude'] ?? 0 ),
        );

        // Default response (stubbed — always serviceable).
        $default_response = array(
            'serviceable'  => true,
            'price'        => 0,
            'eta_minutes'  => 0,
            'status'       => 'ok',
            'message'      => __( 'Delivery available for your area.', 'delicate-two-step-checkout' ),
        );

        // If address was entered manually (no place_id), flag it.
        if ( empty( $payload['place_id'] ) ) {
            $default_response['status']  = 'needs_confirmation';
            $default_response['message'] = __( 'Address entered manually. Delivery availability may be limited.', 'delicate-two-step-checkout' );
        }

        // ---------------------------------------------------------------
        // HARD-CODED INTEGRATION: fetch a live rate from Shiplogic via the
        // Delicate Courier Platform (DCP) plugin's public helper functions.
        // No endpoint URL setting is exposed — the platform plugin owns the
        // URL, credentials, account/provider IDs, service level, and
        // collection address. We just call into it.
        //
        // Logging policy: every meaningful step is emitted through BOTH
        //   - dcp_log() (DCP's structured logger; visible under DCP's
        //     "Debug logging" toggle, written to the WP debug log)
        //   - error_log() (always visible in PHP / web-server logs)
        // so operations have at least one place to see what happened
        // regardless of whether DCP debug logging is enabled.
        // ---------------------------------------------------------------
        $live = $this->fetch_live_rate_from_platform( $payload );

        if ( is_array( $live ) ) {
            // Live rate succeeded — replace the stub.
            $default_response = array_merge( $default_response, $live );
            $this->log_event( 'dtsc.quote.live_ok',
                sprintf( 'Live rate R%.2f returned for %s, %s', $live['price'], $payload['city'], $payload['postcode'] )
            );
        } else {
            // $live is a string explaining why we fell through. Log it so
            // ops can see exactly why the checkout shows no rate. We do NOT
            // hard-fail here — we leave $default_response in place and let
            // the filter chain decide. If nothing fills it in, the customer
            // sees the stub message and the checkout can still proceed via
            // collection / special-trip paths if those are enabled.
            $this->log_event( 'dtsc.quote.live_fail', is_string( $live ) ? $live : 'unknown', 'warning' );

            // Mark the response so the frontend can show a useful message
            // instead of a misleading "R0 — Delivery available".
            $default_response['serviceable'] = false;
            $default_response['status']      = 'no_rate';
            $default_response['price']       = 0;
            $default_response['message']     = __( 'We could not get a live delivery rate for your address. Please check your address details, or contact us if the problem persists.', 'delicate-two-step-checkout' );
        }

        /**
         * Filter: delicate_courier_quote
         *
         * Final extension point. Receives the response after the live-rate
         * lookup has run. Hook here to override or add carriers.
         *
         * @param array $default_response Quote response after live lookup.
         * @param array $payload          Sanitized address and customer data.
         * @return array Modified response with keys: serviceable, price, eta_minutes, status, message.
         */
        $response = apply_filters( 'delicate_courier_quote', $default_response, $payload );

        // Ensure required keys exist.
        $response = wp_parse_args( $response, $default_response );

        // Store in WC session.
        if ( function_exists( 'WC' ) && WC()->session ) {
            WC()->session->set( 'dtsc_courier_quote', array(
                'serviceable'  => (bool) $response['serviceable'],
                'price'        => floatval( $response['price'] ),
                'eta_minutes'  => intval( $response['eta_minutes'] ),
                'status'       => sanitize_text_field( $response['status'] ),
                'message'      => sanitize_text_field( $response['message'] ),
                'address'      => $payload,
                'timestamp'    => current_time( 'timestamp' ),
            ) );
        }

        if ( $response['serviceable'] ) {
            $original_price = floatval( $response['price'] );
            $display_price = $original_price;

            // Apply markup from the Delicate Courier Platform shipping method settings.
            // DCP stores markup in WC shipping method instance options.
            $display_price = $this->apply_dcp_markup( $original_price );

            // Update the response with the marked-up price for display
            $response['price'] = $display_price;
            $response['message'] = sprintf( __( 'Delivery available — R%.2f', 'delicate-two-step-checkout' ), $display_price );

            // Store the DISPLAY price (incl. markup) as the shipping cost the customer pays.
            if ( function_exists( 'WC' ) && WC()->session ) {
                WC()->session->set( 'dcp_checkout_shipping_cost', $display_price );
                // Store the ORIGINAL rate (excl. markup) for shipment booking.
                WC()->session->set( 'dcp_original_shipping_rate', $original_price );
            }
            wp_send_json_success( $response );
        } else {
            // Not serviceable — clear any previous shipping cost.
            if ( function_exists( 'WC' ) && WC()->session ) {
                WC()->session->set( 'dcp_checkout_shipping_cost', 0 );
            }
            wp_send_json_error( $response );
        }
    }

    /**
     * Server-side checkout validation.
     * Block checkout if courier quoting is enabled but no valid quote exists.
     * Only applies to DELIVERY orders — collection orders skip quote validation.
     */
    public function validate_checkout( $data, $errors ) {
        $courier_enabled = get_option( 'dtsc_courier_enabled', 'no' );
        $courier_plugin_active = class_exists( 'WC_Delicate_Courier_Platform' ) || has_filter( 'delicate_courier_quote' );
        if ( $courier_enabled !== 'yes' && ! $courier_plugin_active ) {
            return;
        }

        // Skip quote validation for collection orders.
        // phpcs:ignore WordPress.Security.NonceVerification.Missing
        $delivery_method = isset( $_POST['dtsc_delivery_method'] ) ? sanitize_text_field( wp_unslash( $_POST['dtsc_delivery_method'] ) ) : 'delivery';
        if ( $delivery_method === 'collection' || $delivery_method === 'collect' ) {
            return;
        }

        // Only validate if cart needs shipping.
        if ( ! WC()->cart->needs_shipping() ) {
            return;
        }

        // Check for special trip request — allow checkout without a standard quote.
        // phpcs:ignore WordPress.Security.NonceVerification.Missing
        $special_trip = isset( $_POST['dtsc_special_trip'] ) && $_POST['dtsc_special_trip'] === 'yes';
        if ( $special_trip ) {
            return;
        }

        $quote = WC()->session ? WC()->session->get( 'dtsc_courier_quote' ) : null;

        if ( empty( $quote ) || ! $quote['serviceable'] ) {
            $errors->add(
                'dtsc_no_quote',
                __( 'A valid delivery quote is required to complete your order. Please go back and verify your delivery address.', 'delicate-two-step-checkout' )
            );
        }

        // Check quote is not stale (older than 30 minutes).
        if ( $quote && isset( $quote['timestamp'] ) ) {
            $age_minutes = ( current_time( 'timestamp' ) - $quote['timestamp'] ) / 60;
            if ( $age_minutes > 30 ) {
                $errors->add(
                    'dtsc_quote_expired',
                    __( 'Your delivery quote has expired. Please go back and get a fresh quote.', 'delicate-two-step-checkout' )
                );
            }
        }
    }

    /**
     * Read markup settings from the Delicate Courier Platform shipping method
     * and apply them to the original courier rate.
     *
     * DCP stores markup in WC shipping method instance options under:
     * woocommerce_delicate_courier_platform_{instance_id}_settings
     *
     * @param float $original_price The original Shiplogic rate.
     * @return float The price with markup applied.
     */
    private function apply_dcp_markup( $original_price ) {
        $markup_type = 'none';
        $markup_value = 0;

        // Method 1: Try to read from the DCP shipping method instance.
        // WC stores instance settings in options table as:
        // woocommerce_delicate_courier_platform_<instance_id>_settings
        if ( function_exists( 'WC' ) ) {
            $shipping_zones = \WC_Shipping_Zones::get_zones();
            foreach ( $shipping_zones as $zone_data ) {
                $zone = new \WC_Shipping_Zone( $zone_data['id'] );
                foreach ( $zone->get_shipping_methods( true ) as $method ) {
                    if ( $method->id === 'delicate_courier_platform' ) {
                        $mt = $method->get_option( 'markup_type', 'none' );
                        $mv = floatval( $method->get_option( 'markup_value', 0 ) );
                        if ( $mt !== 'none' && $mv > 0 ) {
                            $markup_type = $mt;
                            $markup_value = $mv;
                        }
                        break 2;
                    }
                }
            }

            // Also check Zone 0 (locations not covered by other zones)
            if ( $markup_type === 'none' ) {
                $zone_zero = new \WC_Shipping_Zone( 0 );
                foreach ( $zone_zero->get_shipping_methods( true ) as $method ) {
                    if ( $method->id === 'delicate_courier_platform' ) {
                        $mt = $method->get_option( 'markup_type', 'none' );
                        $mv = floatval( $method->get_option( 'markup_value', 0 ) );
                        if ( $mt !== 'none' && $mv > 0 ) {
                            $markup_type = $mt;
                            $markup_value = $mv;
                        }
                        break;
                    }
                }
            }
        }

        // Apply markup
        $marked_up_price = $original_price;
        if ( $markup_type === 'fixed' && $markup_value > 0 ) {
            $marked_up_price = $original_price + $markup_value;
        } elseif ( $markup_type === 'percentage' && $markup_value > 0 ) {
            $marked_up_price = $original_price + ( $original_price * $markup_value / 100 );
        }

        return round( $marked_up_price, 2 );
    }

    /**
     * Fetch a live rate via the Delicate Courier Platform's rates endpoint.
     * As of DCP v2.2.0, the merchant only needs a Store ID on the WordPress
     * side; the Shiplogic bearer token, account ID, provider ID, and
     * collection address all live on the platform side, keyed by Store ID.
     *
     * Returns an associative array { serviceable, price, eta_minutes,
     * status, message } on success, or a string describing the failure
     * reason on any failure path. We return a string (not WP_Error) so the
     * caller can log it directly and so the existing $default_response
     * stays untouched when we fall through.
     *
     * @param array $payload Sanitized address payload from handle_quote_request().
     * @return array|string  Rate array on success, error reason on failure.
     */
    private function fetch_live_rate_from_platform( $payload ) {
        // The DCP plugin v2.2.0+ must be active. Fail loudly if not.
        if ( ! function_exists( 'dcp_platform_fetch_rates' ) ) {
            return 'Delicate Courier Platform plugin v2.2.0+ is not active. Install/activate it to enable live rates.';
        }

        if ( ! function_exists( 'dcp_store_id' ) || dcp_store_id() === '' ) {
            return 'DCP: Store ID is not configured on the Delicate Courier admin page.';
        }

        $street = trim( $payload['address_1'] . ' ' . $payload['address_2'] );
        if ( $street === '' || $payload['city'] === '' || $payload['postcode'] === '' ) {
            return 'DCP: Delivery address is incomplete (need street, city, postcode).';
        }

        // Build the delivery address in the platform's camelCase DTO shape.
        // The platform translates this into Shiplogic's expected format
        // server-side, so we never have to deal with Shiplogic field names.
        $delivery_address = array(
            'company'       => null,
            'streetAddress' => $street,
            'localArea'     => '',
            'city'          => $payload['city'],
            'zone'          => function_exists( 'dcp_normalize_province' )
                                ? dcp_normalize_province( $payload['state'] )
                                : $payload['state'],
            'country'       => $payload['country'] ?: 'ZA',
            'code'          => $payload['postcode'],
            'contactName'   => trim( $payload['first_name'] . ' ' . $payload['last_name'] ),
            'contactPhone'  => $payload['phone'] ?: null,
            'contactEmail'  => $payload['email'] ?: null,
        );

        // Total weight from the live WC cart. Fallback to 1kg if cart is
        // unavailable in this AJAX context.
        $weight = 1.0;
        if ( function_exists( 'WC' ) && WC()->cart ) {
            $w = 0.0;
            foreach ( WC()->cart->get_cart() as $item ) {
                $product = $item['data'];
                $pw      = floatval( $product->get_weight() );
                if ( $pw <= 0 ) { $pw = 1; }
                $w += $pw * $item['quantity'];
            }
            if ( $w > 0 ) { $weight = $w; }
        }

        $parcels = array(
            array(
                'description' => 'Package',
                'lengthCm'    => 20,
                'widthCm'     => 15,
                'heightCm'    => 10,
                'weightKg'    => $weight,
            ),
        );

        $this->log_event( 'dtsc.quote.request',
            sprintf( 'POST platform /api/public/shipping/rates  city=%s  postcode=%s  weight=%.2fkg  storeId=%s',
                $payload['city'], $payload['postcode'], $weight, dcp_store_id() )
        );

        $rates = dcp_platform_fetch_rates( $delivery_address, $parcels );

        if ( is_wp_error( $rates ) ) {
            return 'Platform rates error: ' . $rates->get_error_message();
        }
        if ( ! is_array( $rates ) || empty( $rates ) ) {
            return 'Platform returned no rates (address may be outside coverage area, or the store record on the platform is missing Shiplogic credentials).';
        }

        // The platform endpoint returns rates already filtered to what's
        // available for this store. Pick the first one for the simple
        // "delivery price" display the two-step checkout expects.
        $picked = null;
        foreach ( $rates as $r ) {
            if ( isset( $r['rate'] ) ) {
                $picked = $r;
                break;
            }
        }
        if ( ! $picked ) {
            return 'Platform returned rates, but none had a usable rate field.';
        }

        $price = floatval( $picked['rate'] );
        $name  = $picked['service_level']['name'] ?? ( $picked['service_level']['code'] ?? 'Courier' );

        return array(
            'serviceable' => true,
            'price'       => $price,
            'eta_minutes' => 0,
            'status'      => 'ok',
            'message'     => sprintf( __( '%s — R%.2f', 'delicate-two-step-checkout' ), $name, $price ),
        );
    }

    /**
     * Unified logging. Writes to:
     *   1. dcp_log() if available — visible under the DCP plugin's
     *      "Debug logging" toggle (Delicate Courier admin → debug section).
     *   2. error_log() — always visible in the PHP / WordPress debug log.
     *
     * This way, anyone monitoring either log source sees checkout activity.
     *
     * @param string $context  Short event key, e.g. 'dtsc.quote.live_ok'.
     * @param string $detail   Human-readable detail.
     * @param string $level    'info' | 'warning' | 'error'.
     */
    private function log_event( $context, $detail = '', $level = 'info' ) {
        if ( function_exists( 'dcp_log' ) ) {
            dcp_log( $context, $detail, $level );
        }
        // Always also emit to error_log so checkout activity is visible
        // even when DCP debug logging is off.
        error_log( sprintf( '[DTSC][%s] %s: %s', strtoupper( $level ), $context, $detail ) );
    }
}
