<?php
/**
 * Frontend Checkout rendering for Delicate Two-Step Checkout.
 *
 * Single-page checkout with delivery/collection toggle, date picker,
 * payment, T&C, and order placement — all on one page.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class DTSC_Frontend_Checkout {

    public function __construct() {
        add_shortcode( 'delicate_two_step_checkout', array( $this, 'render_shortcode' ) );
        add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_assets' ) );
        // Run late to dequeue WC's checkout JS and any conflicting Google Maps scripts
        add_action( 'wp_enqueue_scripts', array( $this, 'dequeue_wc_checkout_scripts' ), 999 );
        add_action( 'wp_enqueue_scripts', array( $this, 'dequeue_duplicate_google_maps' ), 999 );
        // Ensure COD / Pay in Store is always available
        add_filter( 'woocommerce_available_payment_gateways', array( $this, 'ensure_pay_in_store_gateway' ), 999 );
        // AJAX order summary refresh
        add_action( 'wp_ajax_dtsc_get_order_summary', array( $this, 'ajax_get_order_summary' ) );
        add_action( 'wp_ajax_nopriv_dtsc_get_order_summary', array( $this, 'ajax_get_order_summary' ) );
        // Suppress third-party delivery/collection fields on our checkout page
        add_action( 'wp', array( $this, 'suppress_third_party_checkout_fields' ), 999 );
        // Disable iOS automatic address/phone detection on checkout (prevents Maps links)
        add_action( 'wp_head', array( $this, 'disable_ios_format_detection' ) );
        // Make billing address fields optional for collection orders (JS handles validation)
        add_filter( 'woocommerce_checkout_fields', array( $this, 'relax_billing_fields_for_collection' ), 20 );
        // Tell WC that a collect cart doesn't need a shipping address at all —
        // catch-all that suppresses every other shipping-related validation
        // path including the one the user hit ("Shipping Street address is
        // a required field...").
        add_filter( 'woocommerce_cart_needs_shipping_address', array( $this, 'cart_needs_shipping_address_for_collection' ), 20 );
        // Ensure order-received page always works — clear cart after our AJAX checkout
        add_action( 'woocommerce_thankyou', array( $this, 'ensure_thankyou_page_loads' ), 1 );
        // Allow COD payment for admins even if WC has it disabled
        add_action( 'woocommerce_after_checkout_validation', array( $this, 'allow_cod_for_admins' ), 1, 2 );
        // AJAX: Set fulfillment type in session (delivery vs collection)
        add_action( 'wp_ajax_dtsc_set_fulfillment', array( $this, 'ajax_set_fulfillment' ) );
        add_action( 'wp_ajax_nopriv_dtsc_set_fulfillment', array( $this, 'ajax_set_fulfillment' ) );
    }

    /**
     * Returns true only on the actual checkout form page — NOT on order-received.
     * WooCommerce's is_checkout() returns true on both; we need to exclude order-received.
     */
    private function is_checkout_form_page() {
        if ( ! function_exists( 'is_checkout' ) || ! is_checkout() ) {
            return false;
        }
        // Exclude the order-received endpoint
        if ( is_wc_endpoint_url( 'order-received' ) || is_wc_endpoint_url( 'order-pay' ) ) {
            return false;
        }
        return true;
    }

    /**
     * Returns true if the current page has our shortcode OR is the WC checkout form page.
     */
    private function is_our_checkout_page() {
        global $post;
        if ( $post && has_shortcode( $post->post_content, 'delicate_two_step_checkout' ) ) {
            return true;
        }
        return $this->is_checkout_form_page();
    }
    /**
     * Disable iOS Safari automatic format detection on checkout pages.
     *
     * iOS detects text that looks like addresses/phone numbers and converts them
     * into tappable links (Apple Maps / Phone). This breaks Google Places
     * autocomplete suggestions because tapping a .pac-item opens Maps instead
     * of selecting the address.
     */
    public function disable_ios_format_detection() {
        if ( ! $this->is_our_checkout_page() ) {
            return;
        }
        echo '<meta name="format-detection" content="telephone=no, date=no, email=no, address=no">' . "\n";
    }

    /**
     * Remove ALL third-party hooks that inject content into checkout form actions.
     *
     * Our plugin provides its own delivery toggle, date scheduler, recipient fields,
     * and subscribe options — so we completely clear these WooCommerce hooks to prevent
     * any theme or plugin from injecting duplicate sections.
     */
    public function suppress_third_party_checkout_fields() {
        if ( ! $this->is_our_checkout_page() ) {
            return;
        }

        // Completely remove all callbacks from these actions.
        // Our template calls do_action() for these, but we don't want ANY output.
        remove_all_actions( 'woocommerce_after_checkout_billing_form' );
        remove_all_actions( 'woocommerce_checkout_after_customer_details' );
        remove_all_actions( 'woocommerce_after_checkout_shipping_form' );
        remove_all_actions( 'woocommerce_before_order_notes' );
        remove_all_actions( 'woocommerce_after_order_notes' );
    }

    /**
     * Remove WooCommerce's default wc-checkout script on our checkout page.
     * We handle form submission, validation, and AJAX ourselves.
     * WC's script would double-bind form.checkout and conflict.
     */
    public function dequeue_wc_checkout_scripts() {
        if ( ! $this->is_our_checkout_page() ) {
            return;
        }

        // Only dequeue on the actual checkout form — NOT on order-pay or order-received.
        // PayFast needs its scripts on order-pay to show the payment button.
        if ( is_wc_endpoint_url( 'order-pay' ) || is_wc_endpoint_url( 'order-received' ) ) {
            return;
        }
        if ( isset( $_GET['order-pay'] ) || isset( $_GET['pay_for_order'] ) ||
             isset( $_GET['order-received'] ) ) {
            return;
        }
        if ( get_query_var( 'order-pay' ) || get_query_var( 'order-received' ) ) {
            return;
        }

        // Dequeue WC's own checkout script (we handle checkout via AJAX)
        wp_dequeue_script( 'wc-checkout' );

        // Dequeue PayFast scripts — they call form.submit() directly and bypass our AJAX.
        // On the actual checkout form we handle submission; PayFast gets its redirect URL
        // from our AJAX response and the order-pay page handles the actual payment.
        $payfast_handles = array( 'wc-payfast', 'payfast-checkout', 'payfast', 'woocommerce-payfast', 'payfast-woocommerce' );
        foreach ( $payfast_handles as $handle ) {
            wp_dequeue_script( $handle );
            wp_deregister_script( $handle );
        }

        global $wp_scripts;
        if ( ! empty( $wp_scripts->registered ) ) {
            foreach ( $wp_scripts->registered as $handle => $script ) {
                if ( ! empty( $script->src ) && stripos( $script->src, 'payfast' ) !== false ) {
                    wp_dequeue_script( $handle );
                    wp_deregister_script( $handle );
                }
            }
        }
    }

    /**
     * Ensure "Pay in Store" (COD) gateway is always available and rename it.
     */
    /**
     * Remove 'Pay in Store' / COD payment methods from our checkout page for regular customers.
     * Admins and shop managers can still use them when placing orders through the site.
     */
    public function ensure_pay_in_store_gateway( $gateways ) {
        if ( ! $this->is_our_checkout_page() ) return $gateways;
        if ( is_wc_endpoint_url( 'order-pay' ) || isset( $_GET['order-pay'] ) ||
             isset( $_GET['pay_for_order'] ) || get_query_var( 'order-pay' ) ) {
            return $gateways;
        }

        // Admins keep all gateways — force-add COD if needed
        if ( current_user_can( 'manage_woocommerce' ) ) {
            if ( ! isset( $gateways['cod'] ) ) {
                $all = WC()->payment_gateways()->payment_gateways();
                if ( isset( $all['cod'] ) ) {
                    $gateways['cod'] = $all['cod'];
                    $gateways['cod']->enabled = 'yes';
                }
            }
            if ( isset( $gateways['cod'] ) ) {
                $gateways['cod']->enabled = 'yes';
                $gateways['cod']->title = __( 'Paid in Store', 'delicate-two-step-checkout' );
                $gateways['cod']->description = __( 'Record payment taken in store or upon delivery.', 'delicate-two-step-checkout' );
            }
            return $gateways;
        }

        // Remove ALL 'pay in store' / COD type gateways for regular customers
        unset( $gateways['cod'] );

        // Also remove bacs and cheque — admin-only methods
        unset( $gateways['bacs'] );
        unset( $gateways['cheque'] );

        // Also remove any gateway whose ID or title contains 'pay_in_store', 'paid_in_store', etc.
        foreach ( $gateways as $id => $gateway ) {
            $gw_id = strtolower( $id );
            $gw_title = strtolower( $gateway->title ?? '' );

            if (
                strpos( $gw_id, 'pay_in_store' ) !== false ||
                strpos( $gw_id, 'paid_in_store' ) !== false ||
                strpos( $gw_id, 'pay-in-store' ) !== false ||
                strpos( $gw_title, 'pay in store' ) !== false ||
                strpos( $gw_title, 'paid in store' ) !== false
            ) {
                unset( $gateways[ $id ] );
            }
        }

        return $gateways;
    }

    /**
     * Allow COD/Pay in Store for admins during checkout validation.
     * WC may reject 'cod' as invalid if it's disabled in settings.
     * This strips that specific error for admin users.
     */
    public function allow_cod_for_admins( $data, $errors ) {
        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            return;
        }
        // phpcs:ignore WordPress.Security.NonceVerification.Missing
        $payment_method = isset( $_POST['payment_method'] ) ? sanitize_text_field( wp_unslash( $_POST['payment_method'] ) ) : '';
        if ( $payment_method !== 'cod' ) {
            return;
        }
        // Remove any "Invalid payment method" errors
        $wc_errors = $errors->get_error_codes();
        foreach ( $wc_errors as $code ) {
            if ( strpos( $code, 'payment' ) !== false ) {
                $errors->remove( $code );
            }
        }
    }

    /**
     * AJAX handler — return updated order totals HTML.
     *
     * The delivery cost is added as a WC cart fee (in the main plugin file),
     * so WC's get_total() now includes products + delivery + VAT on both.
     * This total is what gets sent to payment gateways (Yoco, PayFast).
     */
    public function ajax_get_order_summary() {
        check_ajax_referer( 'dtsc_order_summary', 'security' );

        if ( ! function_exists( 'WC' ) || ! WC()->cart ) {
            wp_send_json_error();
        }

        // Recalculate — this triggers the woocommerce_cart_calculate_fees hook
        // which adds our delivery cost as a fee.
        WC()->cart->calculate_totals();

        // Product subtotal (incl. VAT)
        $subtotal_excl = floatval( WC()->cart->get_subtotal() );
        $subtotal_tax  = floatval( WC()->cart->get_subtotal_tax() );
        $subtotal_incl = $subtotal_excl + $subtotal_tax;

        // Shipping cost from session (for display only — the actual charge is via the fee)
        $shipping_cost = 0;
        $shipping_label = __( 'Shipping', 'delicate-two-step-checkout' );
        $shipping_display = '—';

        if ( WC()->session ) {
            $fulfillment = WC()->session->get( 'dtsc_fulfillment_type', 'delivery' );
            $special = WC()->session->get( 'dtsc_special_trip', 'no' );
            $cost = WC()->session->get( 'dcp_checkout_shipping_cost', 0 );

            if ( ( $fulfillment === 'collect' || $fulfillment === 'collection' ) && $special !== 'yes' ) {
                $shipping_label = __( 'Collection', 'delicate-two-step-checkout' );
                $shipping_display = '<strong style="color:#2e7d32;">Free!</strong>';
            } elseif ( $cost && floatval( $cost ) > 0 ) {
                $shipping_cost = floatval( $cost );
                // Calculate shipping VAT
                $shipping_vat = round( $shipping_cost * 0.15, 2 );
                $shipping_incl_vat = $shipping_cost + $shipping_vat;
                $shipping_display = wp_kses_post( wc_price( $shipping_incl_vat ) ) . ' <small>(incl. ' . wp_kses_post( wc_price( $shipping_vat ) ) . ' VAT)</small>';
            }
        }

        // WC's total now includes products + delivery fee + all VAT.
        $grand_total = floatval( WC()->cart->get_total( 'edit' ) );
        $total_tax = floatval( WC()->cart->get_total_tax() );

        // Calculate product VAT and shipping VAT separately for display
        $product_vat = floatval( WC()->cart->get_subtotal_tax() );
        $shipping_vat_amount = ( $shipping_cost > 0 ) ? round( $shipping_cost * 0.15, 2 ) : 0;

        ob_start();
        ?>
        <div class="dtsc-order-totals">
            <div class="dtsc-total-row dtsc-subtotal-row">
                <span><?php esc_html_e( 'Subtotal', 'delicate-two-step-checkout' ); ?></span>
                <span><?php echo wp_kses_post( wc_price( $subtotal_incl ) ); ?> <small>(incl. VAT)</small></span>
            </div>
            <?php foreach ( WC()->cart->get_coupons() as $code => $coupon ) : ?>
                <div class="dtsc-total-row dtsc-coupon-row">
                    <span><?php echo esc_html( sprintf( __( 'Discount: %s', 'delicate-two-step-checkout' ), $code ) ); ?></span>
                    <span class="dtsc-discount-amount">-<?php wc_cart_totals_coupon_html( $coupon ); ?></span>
                </div>
            <?php endforeach; ?>
            <div class="dtsc-total-row dtsc-shipping-row">
                <span id="dtsc-shipping-label"><?php echo esc_html( $shipping_label ); ?></span>
                <span id="dtsc-shipping-total"><?php echo $shipping_display; ?></span>
            </div>
            <div class="dtsc-total-row dtsc-grand-total-row">
                <span><?php esc_html_e( 'Total', 'delicate-two-step-checkout' ); ?></span>
                <span class="dtsc-grand-total-amount"><?php echo wp_kses_post( wc_price( $grand_total ) ); ?>
                    <?php if ( $total_tax > 0 ) : ?>
                        <small>(includes <?php echo wp_kses_post( wc_price( $total_tax ) ); ?> VAT)</small>
                    <?php endif; ?>
                </span>
            </div>
            <?php if ( $total_tax > 0 ) : ?>
                <div class="dtsc-vat-note">
                    <?php
                    if ( $shipping_vat_amount > 0 && $product_vat > 0 ) {
                        echo wp_kses_post( sprintf(
                            __( 'Including %s product VAT + %s shipping VAT', 'delicate-two-step-checkout' ),
                            wc_price( $product_vat ),
                            wc_price( $shipping_vat_amount )
                        ) );
                    } else {
                        echo wp_kses_post( sprintf( __( 'Including %s VAT', 'delicate-two-step-checkout' ), wc_price( $total_tax ) ) );
                    }
                    ?>
                </div>
            <?php endif; ?>
        </div>
        <?php
        $html = ob_get_clean();

        wp_send_json_success( array( 'html' => $html ) );
    }

    /**
     * AJAX handler — set the fulfillment type in WC session.
     * Clears shipping cost for collection, preserves it for delivery.
     */
    public function ajax_set_fulfillment() {
        check_ajax_referer( 'dtsc_order_summary', 'security' );

        if ( ! function_exists( 'WC' ) || ! WC()->session || ! WC()->cart ) {
            wp_send_json_error();
        }

        $type = isset( $_POST['fulfillment_type'] ) ? sanitize_text_field( wp_unslash( $_POST['fulfillment_type'] ) ) : 'delivery';

        WC()->session->set( 'dtsc_fulfillment_type', $type );

        // Handle special trip flag
        $special_trip = isset( $_POST['special_trip'] ) && $_POST['special_trip'] === 'yes' ? 'yes' : 'no';
        WC()->session->set( 'dtsc_special_trip', $special_trip );

        if ( $type === 'collect' || $type === 'collection' ) {
            // Check if this is a special trip with a shipping cost estimate
            $shipping_cost = isset( $_POST['shipping_cost'] ) ? floatval( $_POST['shipping_cost'] ) : 0;
            if ( $special_trip === 'yes' && $shipping_cost > 0 ) {
                // Special trip — store the estimated cost so the total reflects it.
                WC()->session->set( 'dcp_checkout_shipping_cost', $shipping_cost );
            } else {
                // Regular collection — zero shipping.
                WC()->session->set( 'dcp_checkout_shipping_cost', 0 );
            }
            WC()->session->set( 'chosen_shipping_methods', array() );

            // Invalidate WC shipping cache.
            $packages = WC()->cart->get_shipping_packages();
            foreach ( $packages as $key => $pkg ) {
                WC()->session->__unset( 'shipping_for_package_' . $key );
            }
        } else {
            // Delivery — store shipping cost if provided
            $shipping_cost = isset( $_POST['shipping_cost'] ) ? floatval( $_POST['shipping_cost'] ) : 0;
            if ( $shipping_cost > 0 ) {
                WC()->session->set( 'dcp_checkout_shipping_cost', $shipping_cost );
            }
        }

        WC()->cart->calculate_totals();

        wp_send_json_success( array(
            'type'  => $type,
            'total' => WC()->cart->get_total( 'edit' ),
        ) );
    }

    public function enqueue_assets() {
        if ( ! $this->is_our_checkout_page() ) {
            return;
        }

        // Don't enqueue our checkout assets on order-pay — that page uses WC's own scripts
        if ( is_wc_endpoint_url( 'order-pay' ) || isset( $_GET['order-pay'] ) ||
             isset( $_GET['pay_for_order'] ) || absint( get_query_var( 'order-pay', 0 ) ) ) {
            return;
        }

        wp_enqueue_style( 'dtsc-checkout-css', DTSC_PLUGIN_URL . 'assets/css/checkout.css', array(), DTSC_VERSION );

        // 1. Enqueue OUR autocomplete script FIRST — it defines window.dtscGoogleReady
        wp_enqueue_script( 'dtsc-address-autocomplete', DTSC_PLUGIN_URL . 'assets/js/address-autocomplete.js', array( 'jquery' ), DTSC_VERSION, true );

        $api_key = get_option( 'dtsc_google_api_key', '' );

        wp_localize_script( 'dtsc-address-autocomplete', 'dtscAutocomplete', array(
            'countryRestriction'   => strtolower( get_option( 'dtsc_country_restriction', 'za' ) ),
            'autocompleteBilling'  => get_option( 'dtsc_autocomplete_billing', 'yes' ),
            'autocompleteShipping' => get_option( 'dtsc_autocomplete_shipping', 'yes' ),
            'requireStreetNumber'  => get_option( 'dtsc_require_street_number', 'yes' ),
            'requireAddress2'      => get_option( 'dtsc_require_address_2', 'no' ),
            'apiKeyPresent'        => ! empty( $api_key ) ? 'yes' : 'no',
        ) );

        // 2. Enqueue Google Maps AFTER our script, with our script as dependency.
        if ( $api_key ) {
            wp_enqueue_script( 'google-maps-places',
                'https://maps.googleapis.com/maps/api/js?key=' . esc_attr( $api_key ) . '&libraries=places&callback=dtscGoogleReady',
                array( 'dtsc-address-autocomplete' ), null, true
            );
        }

        wp_enqueue_script( 'dtsc-two-step-checkout', DTSC_PLUGIN_URL . 'assets/js/two-step-checkout.js', array( 'jquery', 'dtsc-address-autocomplete' ), DTSC_VERSION, true );

        $terms_page_id = wc_terms_and_conditions_page_id();

        wp_localize_script( 'dtsc-two-step-checkout', 'dtscCheckout', array(
            'ajaxUrl'           => admin_url( 'admin-ajax.php' ),
            'wcAjaxUrl'         => WC_AJAX::get_endpoint( '%%endpoint%%' ),
            'pluginUrl'         => DTSC_PLUGIN_URL,
            'checkoutUrl'       => dtsc_get_checkout_page_url(),
            'wcCheckoutUrl'     => wc_get_checkout_url(), // WC's registered checkout page for endpoint URLs
            'quoteNonce'        => wp_create_nonce( 'dtsc_quote_nonce' ),
            'applyCouponNonce'  => wp_create_nonce( 'apply-coupon' ),
            'removeCouponNonce' => wp_create_nonce( 'remove-coupon' ),
            'updateOrderReviewNonce' => wp_create_nonce( 'update-order-review' ),
            'orderSummaryNonce' => wp_create_nonce( 'dtsc_order_summary' ),
            'courierEnabled'    => ( class_exists( 'WC_Delicate_Courier_Platform' ) || has_filter( 'delicate_courier_quote' ) ) ? 'yes' : get_option( 'dtsc_courier_enabled', 'no' ),
            'requireAddress2'   => get_option( 'dtsc_require_address_2', 'no' ),
            'schedulerEnabled'  => get_option( 'dtsc_scheduler_enabled', 'no' ),
            'schedulerRequired' => get_option( 'dtsc_scheduler_required', 'no' ),
            'termsRequired'     => ( $terms_page_id > 0 ) ? 'yes' : 'no',
            'specialTrip' => array(
                'bakeryAddress' => get_option( 'dtsc_bakery_address', '5 Graham Road, Shere, Pretoria, South Africa' ),
                'rateMin'       => floatval( get_option( 'dtsc_special_trip_rate_min', 9 ) ),
                'rateMax'       => floatval( get_option( 'dtsc_special_trip_rate_max', 12 ) ),
                'minCharge'     => floatval( get_option( 'dtsc_special_trip_min_charge', 150 ) ),
            ),
            'i18n' => array(
                'fieldRequired'        => __( 'This field is required.', 'delicate-two-step-checkout' ),
                'invalidEmail'         => __( 'Please enter a valid email address.', 'delicate-two-step-checkout' ),
                'invalidPhone'         => __( 'Please enter a valid phone number.', 'delicate-two-step-checkout' ),
                'notServiceable'       => __( 'Sorry, we cannot deliver to this address.', 'delicate-two-step-checkout' ),
                'quoteError'           => __( 'Unable to get a delivery quote. Please try again.', 'delicate-two-step-checkout' ),
                'gettingQuote'         => __( 'Getting delivery quote…', 'delicate-two-step-checkout' ),
                'noStreetNumber'       => __( 'Please include a street number in your address.', 'delicate-two-step-checkout' ),
                'address2Required'     => __( 'Please enter your unit, apartment, or complex number.', 'delicate-two-step-checkout' ),
                'deliveryDateRequired' => __( 'Please select a delivery date.', 'delicate-two-step-checkout' ),
                'deliveryTimeRequired' => __( 'Please select a delivery time slot.', 'delicate-two-step-checkout' ),
                'termsRequired'        => __( 'Please accept the terms and conditions.', 'delicate-two-step-checkout' ),
                'couponApplied'        => __( 'Coupon applied successfully!', 'delicate-two-step-checkout' ),
                'couponRemoved'        => __( 'Coupon removed.', 'delicate-two-step-checkout' ),
                'couponError'          => __( 'Coupon could not be applied. Please check the code and try again.', 'delicate-two-step-checkout' ),
                'couponEmpty'          => __( 'Please enter a coupon code.', 'delicate-two-step-checkout' ),
            ),
        ) );

        // Provide wc_checkout_params for any payment gateway JS that depends on it
        // (since we dequeue wc-checkout which normally provides this)
        wp_add_inline_script( 'dtsc-two-step-checkout', sprintf(
            'var wc_checkout_params = %s;',
            wp_json_encode( array(
                'ajax_url'                  => WC()->ajax_url(),
                'wc_ajax_url'               => WC_AJAX::get_endpoint( '%%endpoint%%' ),
                'update_order_review_nonce' => wp_create_nonce( 'update-order-review' ),
                'apply_coupon_nonce'        => wp_create_nonce( 'apply-coupon' ),
                'remove_coupon_nonce'       => wp_create_nonce( 'remove-coupon' ),
                'option_guest_checkout'     => get_option( 'woocommerce_enable_guest_checkout' ),
                'checkout_url'              => WC_AJAX::get_endpoint( 'checkout' ),
                'is_checkout'               => is_checkout() ? 1 : 0,
                'debug_mode'                => defined( 'WP_DEBUG' ) && WP_DEBUG,
            ) )
        ), 'before' );

        if ( get_option( 'dtsc_scheduler_enabled', 'no' ) === 'yes' ) {
            wp_enqueue_script( 'dtsc-delivery-scheduler', DTSC_PLUGIN_URL . 'assets/js/delivery-scheduler.js', array( 'jquery', 'dtsc-two-step-checkout' ), DTSC_VERSION, true );
            wp_localize_script( 'dtsc-delivery-scheduler', 'dtscScheduler', $this->get_scheduler_config() );
        }
    }

    /**
     * Dequeue any duplicate Google Maps scripts registered by other plugins.
     * Loading the API twice corrupts the Places service.
     * Runs at priority 999 to catch all scripts.
     */
    public function dequeue_duplicate_google_maps() {
        if ( ! $this->is_our_checkout_page() ) {
            return;
        }

        global $wp_scripts;
        if ( empty( $wp_scripts->registered ) ) {
            return;
        }

        foreach ( $wp_scripts->registered as $handle => $script ) {
            if ( $handle === 'google-maps-places' ) {
                continue;
            }
            if ( ! empty( $script->src ) && strpos( $script->src, 'maps.googleapis.com/maps/api/js' ) !== false ) {
                wp_deregister_script( $handle );
                wp_dequeue_script( $handle );
            }
        }
    }

    public function render_shortcode( $atts ) {
        if ( is_admin() ) return '';

        // Detect order-pay in all possible URL formats:
        // Pretty permalink: /order-pay/123/ → get_query_var('order-pay')
        // Query string: ?order-pay=123
        // Customer payment link: ?pay_for_order=true&key=xxx
        $order_pay_id = absint( get_query_var( 'order-pay', 0 ) );
        if ( ! $order_pay_id && isset( $_GET['order-pay'] ) ) {
            $order_pay_id = absint( $_GET['order-pay'] );
        }

        // Also detect via pay_for_order + key (customer payment page link)
        $order_key = isset( $_GET['key'] ) ? sanitize_text_field( wp_unslash( $_GET['key'] ) ) : '';
        if ( ! $order_pay_id && $order_key && isset( $_GET['pay_for_order'] ) ) {
            $order_pay_id = wc_get_order_id_by_order_key( $order_key );
        }

        if ( $order_pay_id && $order_key ) {
            $order = wc_get_order( $order_pay_id );
            if ( $order && hash_equals( $order->get_order_key(), $order_key ) ) {
                // Set up WC globals that form-pay.php and gateway scripts expect.
                // When order-pay is loaded via our shortcode (query-string format)
                // rather than WC's endpoint, these aren't set automatically.
                global $wp;
                $wp->query_vars['order-pay'] = $order_pay_id;
                if ( ! defined( 'WOOCOMMERCE_CHECKOUT' ) ) {
                    define( 'WOOCOMMERCE_CHECKOUT', true );
                }

                // Tell WC this is a pay-for-order page so gateways load correctly
                add_filter( 'woocommerce_is_checkout', '__return_true' );

                ob_start();
                wp_enqueue_script( 'wc-checkout' );
                echo '<div class="woocommerce dtsc-order-pay-wrapper">';
                wc_print_notices();
                wc_get_template( 'checkout/form-pay.php', array( 'order' => $order ) );
                echo '</div>';
                return ob_get_clean();
            }
        }

        // If this is an order-received request, render the thank-you content instead.
        if ( isset( $_GET['order-received'] ) && isset( $_GET['key'] ) ) {
            $order_id  = absint( $_GET['order-received'] );
            $order_key = sanitize_text_field( wp_unslash( $_GET['key'] ) );
            $order     = wc_get_order( $order_id );
            if ( $order && hash_equals( $order->get_order_key(), $order_key ) ) {
                ob_start();
                wc_get_template( 'checkout/thankyou.php', array( 'order' => $order ) );
                return ob_get_clean();
            }
        }

        if ( function_exists( 'WC' ) && WC()->cart && WC()->cart->is_empty() ) {
            return '<div class="dtsc-empty-cart"><p>' . esc_html__( 'Your cart is empty.', 'delicate-two-step-checkout' ) . '</p><a href="' . esc_url( wc_get_page_permalink( 'shop' ) ) . '" class="button">' . esc_html__( 'Return to shop', 'delicate-two-step-checkout' ) . '</a></div>';
        }
        if ( ! function_exists( 'WC' ) ) return '<p>WooCommerce is required.</p>';

        $checkout = WC()->checkout();
        ob_start();
        ?>
        <div id="dtsc-checkout-wrapper" class="dtsc-checkout-wrapper">

            <div class="dtsc-notices"><?php
                // Filter out shipping-related notices before printing.
                // Other plugins queue these before our filters run.
                $all_notices = wc_get_notices();
                foreach ( array( 'error', 'notice', 'success' ) as $ntype ) {
                    if ( empty( $all_notices[ $ntype ] ) ) continue;
                    foreach ( $all_notices[ $ntype ] as $nkey => $nval ) {
                        $nmsg = is_array( $nval ) ? ( isset( $nval['notice'] ) ? $nval['notice'] : '' ) : $nval;
                        if ( stripos( $nmsg, 'shipping' ) !== false ) {
                            unset( $all_notices[ $ntype ][ $nkey ] );
                        }
                    }
                }
                wc_set_notices( $all_notices );
                wc_print_notices();
            ?></div>

            <form name="checkout" method="post" class="checkout woocommerce-checkout dtsc-checkout-form" action="<?php echo esc_url( wc_get_checkout_url() ); ?>" enctype="multipart/form-data">

                <?php /* Hidden fields that WooCommerce requires — always present */ ?>
                <input type="hidden" id="billing_country" name="billing_country" value="ZA" />
                <input type="hidden" id="shipping_country" name="shipping_country" value="ZA" />

                <div class="dtsc-layout">
                    <div class="dtsc-main-column">

                        <?php /* ── Contact Information ── */ ?>
                        <div class="dtsc-section dtsc-contact-section">
                            <h3 class="dtsc-section-title"><?php esc_html_e( 'Contact Information', 'delicate-two-step-checkout' ); ?></h3>

                            <?php if ( ! is_user_logged_in() && $checkout->is_registration_enabled() ) : ?>
                                <p class="dtsc-guest-notice">
                                    <?php esc_html_e( 'Checking out as a guest.', 'delicate-two-step-checkout' ); ?>
                                    <a href="#" class="dtsc-login-toggle"><?php esc_html_e( 'Log in', 'delicate-two-step-checkout' ); ?></a>
                                </p>
                            <?php endif; ?>
                            <div class="dtsc-login-form" style="display:none;">
                                <?php woocommerce_login_form( array( 'redirect' => dtsc_get_checkout_page_url(), 'hidden' => false ) ); ?>
                            </div>

                            <div class="dtsc-field-row dtsc-field-row-half">
                                <?php $this->render_wc_field( 'billing_first_name', $checkout, array( 'class' => array( 'dtsc-field-half' ), 'required' => true ) ); ?>
                                <?php $this->render_wc_field( 'billing_last_name', $checkout, array( 'class' => array( 'dtsc-field-half' ), 'required' => true ) ); ?>
                            </div>
                            <div class="dtsc-field-row">
                                <?php $this->render_wc_field( 'billing_email', $checkout, array( 'class' => array( 'dtsc-field-full' ) ) ); ?>
                            </div>
                            <div class="dtsc-field-row">
                                <?php $this->render_wc_field( 'billing_phone', $checkout, array( 'class' => array( 'dtsc-field-full' ), 'required' => true ) ); ?>
                            </div>
                            <div class="dtsc-field-row">
                                <?php $this->render_wc_field( 'billing_company', $checkout, array( 'class' => array( 'dtsc-field-full' ), 'required' => false, 'label' => __( 'Company name', 'delicate-two-step-checkout' ), 'placeholder' => __( 'Optional', 'delicate-two-step-checkout' ) ) ); ?>
                            </div>

                            <?php /* ── Create Account (guests only) ── */ ?>
                            <?php if ( ! is_user_logged_in() && $checkout->is_registration_enabled() && ! $checkout->is_registration_required() ) : ?>
                                <div class="dtsc-field-row dtsc-account-options">
                                    <label class="dtsc-checkbox-label dtsc-create-account-label">
                                        <input type="checkbox" class="input-checkbox" id="createaccount" name="createaccount" value="1" <?php checked( $checkout->get_value( 'createaccount' ), true ); ?> />
                                        <?php echo wp_kses_post( sprintf( __( 'Create an account with %s', 'delicate-two-step-checkout' ), get_bloginfo( 'name' ) ) ); ?>
                                    </label>
                                    <div id="dtsc-account-password" class="dtsc-account-password" style="display:none;">
                                        <?php $this->render_wc_field( 'account_password', $checkout, array(
                                            'type'  => 'password',
                                            'label' => __( 'Create account password', 'delicate-two-step-checkout' ),
                                            'class' => array( 'dtsc-field-full' ),
                                            'required' => true,
                                        ) ); ?>
                                    </div>
                                </div>
                            <?php endif; ?>

                            <?php /* ── Newsletter / Marketing Subscribe — always shown ── */ ?>
                            <div class="dtsc-field-row dtsc-subscribe-options">
                                <?php
                                /**
                                 * Third-party checkout field hooks removed to prevent duplicate
                                 * delivery/collection/scheduling sections from other plugins/themes.
                                 * Our plugin provides its own complete checkout UI.
                                 *
                                 * If you need newsletter/subscribe opt-ins, hook into
                                 * 'dtsc_after_contact_fields' instead.
                                 */
                                do_action( 'dtsc_after_contact_fields', $checkout );
                                ?>
                            </div>

                        </div>

                        <?php /* ── Delivery / Collection Toggle ── */ ?>
                        <div class="dtsc-section dtsc-delivery-section">
                            <h3 class="dtsc-section-title"><?php esc_html_e( 'How would you like to receive your order?', 'delicate-two-step-checkout' ); ?></h3>
                            <div class="dtsc-delivery-toggle">
                                <button type="button" class="dtsc-delivery-btn dtsc-delivery-btn-active" data-method="delivery">
                                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 3h15v13H1z"/><path d="M16 8h4l3 3v5h-7V8z"/><circle cx="5.5" cy="18.5" r="2.5"/><circle cx="18.5" cy="18.5" r="2.5"/></svg>
                                    <?php esc_html_e( 'Delivery', 'delicate-two-step-checkout' ); ?>
                                </button>
                                <button type="button" class="dtsc-delivery-btn" data-method="collect">
                                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>
                                    <?php esc_html_e( 'Collection in PTA', 'delicate-two-step-checkout' ); ?>
                                </button>
                            </div>
                            <input type="hidden" id="dtsc_delivery_method" name="dtsc_delivery_method" value="delivery" />
                            <input type="hidden" id="dtsc_special_trip" name="dtsc_special_trip" value="no" />
                        </div>

                        <?php /* ── Collection Info (shown when collection selected) ── */ ?>
                        <div id="dtsc-collection-fields" class="dtsc-section dtsc-collection-section" style="display:none;">
                            <h3 class="dtsc-section-title"><?php esc_html_e( 'Collection Details', 'delicate-two-step-checkout' ); ?></h3>
                            <div class="dtsc-collection-card">
                                <div class="dtsc-collection-icon">
                                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z"/><circle cx="12" cy="10" r="3"/></svg>
                                </div>
                                <div class="dtsc-collection-info">
                                    <strong class="dtsc-collection-name"><?php esc_html_e( 'Honey Bee Baker', 'delicate-two-step-checkout' ); ?></strong>
                                    <span class="dtsc-collection-address"><?php esc_html_e( 'Stocks Centre, 5 Graham Road, Shere (Silverlakes), Pretoria', 'delicate-two-step-checkout' ); ?></span>
                                    <a href="https://www.google.com/maps/dir/?api=1&destination=Stocks+Centre+5+Graham+Road+Shere+Pretoria+South+Africa" target="_blank" rel="noopener" class="dtsc-collection-map-link">
                                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="3 11 22 2 13 21 11 13 3 11"/></svg>
                                        <?php esc_html_e( 'Get directions', 'delicate-two-step-checkout' ); ?>
                                    </a>
                                </div>
                            </div>
                        </div>

                        <?php /* ── Delivery Address (shown for delivery) ── */ ?>
                        <div id="dtsc-shipping-fields" class="dtsc-section dtsc-address-section">
                            <h3 class="dtsc-section-title"><?php esc_html_e( 'Delivery Address', 'delicate-two-step-checkout' ); ?></h3>

                            <div class="dtsc-field-row">
                                <?php $this->render_wc_field( 'shipping_address_1', $checkout, array( 'class' => array( 'dtsc-field-full' ) ) ); ?>
                            </div>
                            <div class="dtsc-field-row dtsc-address2-row">
                                <a href="#" class="dtsc-toggle-address2" id="dtsc-toggle-address2">+ <?php esc_html_e( 'Add apartment, suite, unit, etc.', 'delicate-two-step-checkout' ); ?></a>
                                <div class="dtsc-address2-wrapper" style="display:none;">
                                    <?php $this->render_wc_field( 'shipping_address_2', $checkout, array( 'class' => array( 'dtsc-field-full' ) ) ); ?>
                                </div>
                            </div>
                            <div class="dtsc-field-row dtsc-field-row-half">
                                <?php $this->render_wc_field( 'shipping_city', $checkout, array( 'class' => array( 'dtsc-field-half' ) ) ); ?>
                                <?php $this->render_wc_field( 'shipping_state', $checkout, array( 'class' => array( 'dtsc-field-half' ) ) ); ?>
                            </div>
                            <div class="dtsc-field-row">
                                <?php $this->render_wc_field( 'shipping_postcode', $checkout, array( 'class' => array( 'dtsc-field-half' ) ) ); ?>
                            </div>

                            <?php /* Hidden fields to copy contact info to shipping */ ?>
                            <input type="hidden" id="shipping_first_name" name="shipping_first_name" value="" />
                            <input type="hidden" id="shipping_last_name" name="shipping_last_name" value="" />
                            <input type="hidden" id="shipping_place_id" name="shipping_place_id" value="" />
                            <input type="hidden" id="shipping_latitude" name="shipping_latitude" value="" />
                            <input type="hidden" id="shipping_longitude" name="shipping_longitude" value="" />

                            <?php /*
                             * CRITICAL: Force WooCommerce to treat shipping and billing as
                             * independent address records. Without this flag set to 1,
                             * WC_Checkout::process_checkout() silently copies billing_* into
                             * shipping_* at order-create time, which means the shipment ends
                             * up booked to the billing address. This hidden input is the
                             * front-line guard; server-side enforcement also exists in
                             * delicate-two-step-checkout.php and class-order-meta.php so
                             * the addresses NEVER overlap. */ ?>
                            <input type="hidden" id="ship_to_different_address" name="ship_to_different_address" value="1" />

                            <div class="dtsc-field-row dtsc-same-billing-row">
                                <label class="dtsc-checkbox-label">
                                    <input type="checkbox" id="dtsc_same_as_billing" name="dtsc_same_as_billing" value="1" checked="checked" />
                                    <?php esc_html_e( 'My billing address is the same as my delivery address', 'delicate-two-step-checkout' ); ?>
                                </label>
                            </div>

                            <?php /* ── Receiving the order? ── */ ?>
                            <div class="dtsc-field-row dtsc-receiver-check">
                                <label class="dtsc-checkbox-label">
                                    <input type="checkbox" id="dtsc_self_receiving" name="dtsc_self_receiving" value="1" checked="checked" />
                                    <?php esc_html_e( 'I will be receiving this order myself', 'delicate-two-step-checkout' ); ?>
                                </label>
                            </div>

                            <?php /* ── Recipient details (shown when someone else receives) ── */ ?>
                            <div id="dtsc-recipient-fields" class="dtsc-recipient-fields" style="display:none;">
                                <p class="dtsc-recipient-notice">
                                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
                                    <?php esc_html_e( 'Please provide the contact details of the person who will be receiving the delivery.', 'delicate-two-step-checkout' ); ?>
                                </p>
                                <div class="dtsc-field-row dtsc-field-row-half">
                                    <p class="form-row dtsc-field-half" id="dtsc_recipient_name_field">
                                        <label for="dtsc_recipient_name"><?php esc_html_e( 'Recipient name', 'delicate-two-step-checkout' ); ?>&nbsp;<abbr class="required" title="required">*</abbr></label>
                                        <span class="woocommerce-input-wrapper">
                                            <input type="text" class="input-text" name="dtsc_recipient_name" id="dtsc_recipient_name" placeholder="" value="" />
                                        </span>
                                    </p>
                                    <p class="form-row dtsc-field-half" id="dtsc_recipient_phone_field">
                                        <label for="dtsc_recipient_phone"><?php esc_html_e( 'Recipient phone number', 'delicate-two-step-checkout' ); ?>&nbsp;<abbr class="required" title="required">*</abbr></label>
                                        <span class="woocommerce-input-wrapper">
                                            <input type="tel" class="input-text" name="dtsc_recipient_phone" id="dtsc_recipient_phone" placeholder="" value="" />
                                        </span>
                                    </p>
                                </div>
                            </div>

                            <?php /* ── Alternative delivery phone (only when self-receiving) ── */ ?>
                            <div class="dtsc-field-row dtsc-delivery-phone-row" id="dtsc-alt-phone-row">
                                <p class="form-row dtsc-field-full" id="dtsc_delivery_phone_field">
                                    <label for="dtsc_delivery_phone"><?php esc_html_e( 'Alternative phone number for delivery', 'delicate-two-step-checkout' ); ?>&nbsp;<abbr class="required" title="required">*</abbr></label>
                                    <span class="woocommerce-input-wrapper">
                                        <input type="tel" class="input-text" name="dtsc_delivery_phone" id="dtsc_delivery_phone" placeholder="<?php esc_attr_e( 'In case we cannot reach you', 'delicate-two-step-checkout' ); ?>" value="" />
                                    </span>
                                </p>
                            </div>
                        </div>

                        <?php /* ── Billing Address ── */ ?>
                        <div id="dtsc-billing-fields" class="dtsc-section dtsc-address-section" style="display:none;">
                            <h3 class="dtsc-section-title"><?php esc_html_e( 'Billing Address', 'delicate-two-step-checkout' ); ?></h3>
                            <div class="dtsc-field-row">
                                <?php $this->render_wc_field( 'billing_address_1', $checkout, array( 'class' => array( 'dtsc-field-full' ) ) ); ?>
                            </div>
                            <div class="dtsc-field-row">
                                <?php $this->render_wc_field( 'billing_address_2', $checkout, array( 'class' => array( 'dtsc-field-full' ), 'required' => false ) ); ?>
                            </div>
                            <div class="dtsc-field-row dtsc-field-row-half">
                                <?php $this->render_wc_field( 'billing_city', $checkout, array( 'class' => array( 'dtsc-field-half' ) ) ); ?>
                                <?php $this->render_wc_field( 'billing_state', $checkout, array( 'class' => array( 'dtsc-field-half' ) ) ); ?>
                            </div>
                            <div class="dtsc-field-row">
                                <?php $this->render_wc_field( 'billing_postcode', $checkout, array( 'class' => array( 'dtsc-field-half' ) ) ); ?>
                            </div>
                            <input type="hidden" id="billing_place_id" name="billing_place_id" value="" />
                            <input type="hidden" id="billing_latitude" name="billing_latitude" value="" />
                            <input type="hidden" id="billing_longitude" name="billing_longitude" value="" />
                        </div>

                        <?php /* ── Delivery Quote Panel ── */ ?>
                        <div id="dtsc-quote-panel" class="dtsc-section dtsc-quote-panel">
                            <h3 class="dtsc-section-title"><?php esc_html_e( 'Delivery Quote', 'delicate-two-step-checkout' ); ?></h3>
                            <div id="dtsc-quote-result" class="dtsc-quote-result">
                                <div class="dtsc-quote-card dtsc-quote-card-placeholder">
                                    <div class="dtsc-quote-card-body">
                                        <p class="dtsc-quote-placeholder-text"><?php esc_html_e( 'Enter your delivery address above to get a shipping quote.', 'delicate-two-step-checkout' ); ?></p>
                                    </div>
                                    <div class="dtsc-quote-card-footer">
                                        <span class="dtsc-quote-poweredby-label"><?php esc_html_e( 'Powered by', 'delicate-two-step-checkout' ); ?></span>
                                        <span class="dtsc-quote-poweredby-name"><?php esc_html_e( 'Delicate Courier', 'delicate-two-step-checkout' ); ?></span>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <?php /* ── Delivery Date Picker (hidden for collection) ── */ ?>
                        <?php if ( get_option( 'dtsc_scheduler_enabled', 'no' ) === 'yes' ) : ?>
                        <div id="dtsc-delivery-schedule-section" class="dtsc-section dtsc-delivery-schedule-section">
                            <h3 class="dtsc-section-title"><?php esc_html_e( 'Delivery Date & Time', 'delicate-two-step-checkout' ); ?></h3>
                            <div class="dtsc-scheduler-content"></div>
                        </div>
                        <?php endif; ?>

                        <?php /* ── Payment ── */ ?>
                        <div class="dtsc-section dtsc-payment-section">
                            <h3 class="dtsc-section-title"><?php esc_html_e( 'Payment', 'delicate-two-step-checkout' ); ?></h3>
                            <div id="payment" class="woocommerce-checkout-payment">
                                <?php
                                if ( WC()->cart->needs_payment() ) {
                                    $available_gateways = WC()->payment_gateways()->get_available_payment_gateways();
                                    WC()->payment_gateways()->set_current_gateway( $available_gateways );
                                } else {
                                    $available_gateways = array();
                                }

                                // Only add Pay in Store (COD) for admins
                                if ( current_user_can( 'manage_woocommerce' ) ) {
                                    if ( ! isset( $available_gateways['cod'] ) ) {
                                        $all_gateways = WC()->payment_gateways()->payment_gateways();
                                        if ( isset( $all_gateways['cod'] ) ) {
                                            $cod = $all_gateways['cod'];
                                            $cod->chosen = false;
                                            $cod->enabled = 'yes';
                                            $cod->title = __( 'Paid in Store', 'delicate-two-step-checkout' );
                                            $cod->description = __( 'Record payment taken in store or upon delivery.', 'delicate-two-step-checkout' );
                                            $available_gateways['cod'] = $cod;
                                        }
                                    }
                                } else {
                                    // Remove COD and any pay-in-store gateways for regular customers
                                    unset( $available_gateways['cod'] );
                                    foreach ( $available_gateways as $gw_id => $gw ) {
                                        $id_lower = strtolower( $gw_id );
                                        $title_lower = strtolower( $gw->title ?? '' );
                                        if (
                                            strpos( $id_lower, 'pay_in_store' ) !== false ||
                                            strpos( $id_lower, 'paid_in_store' ) !== false ||
                                            strpos( $title_lower, 'pay in store' ) !== false ||
                                            strpos( $title_lower, 'paid in store' ) !== false
                                        ) {
                                            unset( $available_gateways[ $gw_id ] );
                                        }
                                    }
                                }

                                // Always ensure Yoco gateway is available
                                $yoco_ids = array( 'yoco_wc_payment_gateway', 'class_yoco_wc_payment_gateway', 'yoco' );
                                $yoco_found = false;
                                foreach ( $yoco_ids as $yid ) {
                                    if ( isset( $available_gateways[ $yid ] ) ) {
                                        $yoco_found = true;
                                        break;
                                    }
                                }
                                if ( ! $yoco_found ) {
                                    $all_gateways = $all_gateways ?? WC()->payment_gateways()->payment_gateways();
                                    foreach ( $yoco_ids as $yid ) {
                                        if ( isset( $all_gateways[ $yid ] ) ) {
                                            $yoco = $all_gateways[ $yid ];
                                            $yoco->chosen = false;
                                            $available_gateways[ $yid ] = $yoco;
                                            $yoco_found = true;
                                            break;
                                        }
                                    }
                                }

                                if ( $available_gateways ) {
                                    echo '<ul class="wc_payment_methods payment_methods methods dtsc-payment-methods">';
                                    $first = true;
                                    foreach ( $available_gateways as $gateway ) {
                                        $is_active = $first;
                                        ?>
                                        <li class="wc_payment_method payment_method_<?php echo esc_attr( $gateway->id ); ?> <?php if ( $is_active ) echo 'dtsc-payment-active'; ?>">
                                            <label for="payment_method_<?php echo esc_attr( $gateway->id ); ?>" class="dtsc-payment-label">
                                                <input id="payment_method_<?php echo esc_attr( $gateway->id ); ?>"
                                                       type="radio" class="input-radio" name="payment_method"
                                                       value="<?php echo esc_attr( $gateway->id ); ?>"
                                                       <?php checked( $first, true ); ?>
                                                       data-order_button_text="<?php echo esc_attr( $gateway->order_button_text ); ?>" />
                                                <span class="dtsc-payment-gateway-title">
                                                    <?php echo wp_kses_post( $gateway->get_title() ); ?>
                                                </span>
                                                <span class="dtsc-payment-gateway-icons">
                                                    <?php echo wp_kses_post( $gateway->get_icon() ); ?>
                                                </span>
                                            </label>
                                            <?php if ( $gateway->has_fields() || $gateway->get_description() ) : ?>
                                                <div class="payment_box payment_method_<?php echo esc_attr( $gateway->id ); ?>" <?php if ( ! $first ) : ?>style="display:none;"<?php endif; ?>>
                                                    <?php $gateway->payment_fields(); ?>
                                                </div>
                                            <?php endif; ?>
                                        </li>
                                        <?php
                                        $first = false;
                                    }
                                    echo '</ul>';
                                }
                                ?>
                                <div class="dtsc-yoco-international-notice">
                                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg>
                                    <span><?php esc_html_e( 'International payments supported via Yoco (Visa, Mastercard, Amex)', 'delicate-two-step-checkout' ); ?></span>
                                </div>
                            </div>
                        </div>

                        <?php /* ── Order Notes ── */ ?>
                        <div class="dtsc-section dtsc-notes-section">
                            <label class="dtsc-checkbox-label">
                                <input type="checkbox" id="dtsc-toggle-notes" />
                                <?php esc_html_e( 'Add a note to your order', 'delicate-two-step-checkout' ); ?>
                            </label>
                            <div class="dtsc-notes-field" style="display:none;">
                                <textarea name="order_comments" id="order_comments" placeholder="<?php esc_attr_e( 'Special notes for delivery or cake inscriptions.', 'delicate-two-step-checkout' ); ?>" rows="3"></textarea>
                            </div>
                        </div>

                        <?php /* ── Terms & Place Order ── */ ?>
                        <div class="dtsc-section dtsc-place-order-section">
                            <?php do_action( 'woocommerce_checkout_before_terms_and_conditions' ); ?>

                            <?php
                            $terms_page_id = wc_terms_and_conditions_page_id();
                            $order_change_page = get_option( 'dtsc_order_change_policy_page', 0 );
                            if ( $terms_page_id > 0 && apply_filters( 'woocommerce_checkout_show_terms', true ) ) :
                            ?>
                            <div class="dtsc-terms-wrap" id="dtsc-terms-wrap">
                                <label class="dtsc-checkbox-label dtsc-terms-label">
                                    <input type="checkbox" id="dtsc-terms-checkbox" name="terms" value="1" />
                                    <span class="dtsc-terms-text">
                                        <?php
                                        $order_change_url = $order_change_page ? get_permalink( $order_change_page ) : '';
                                        $terms_url = get_permalink( $terms_page_id );

                                        if ( $order_change_url ) {
                                            printf(
                                                wp_kses(
                                                    __( 'Please note that changes requested after placing your order fall under our <a href="%1$s" target="_blank" rel="noopener">Order Change Policy</a> and may incur an admin fee. By proceeding, you confirm that your order details are correct and you agree to our <a href="%2$s" target="_blank" rel="noopener">Terms and Conditions</a>.', 'delicate-two-step-checkout' ),
                                                    array( 'a' => array( 'href' => array(), 'target' => array(), 'rel' => array() ) )
                                                ),
                                                esc_url( $order_change_url ),
                                                esc_url( $terms_url )
                                            );
                                        } else {
                                            printf(
                                                wp_kses(
                                                    __( 'Please note that changes requested after placing your order may incur an admin fee. By proceeding, you confirm that your order details are correct and you agree to our <a href="%s" target="_blank" rel="noopener">Terms and Conditions</a>.', 'delicate-two-step-checkout' ),
                                                    array( 'a' => array( 'href' => array(), 'target' => array(), 'rel' => array() ) )
                                                ),
                                                esc_url( $terms_url )
                                            );
                                        }
                                        ?>
                                    </span>
                                </label>
                                <div class="dtsc-terms-error" id="dtsc-terms-error" style="display:none;"></div>
                            </div>
                            <?php endif; ?>

                            <?php do_action( 'woocommerce_checkout_after_terms_and_conditions' ); ?>
                            <?php echo wp_nonce_field( 'woocommerce-process_checkout', 'woocommerce-process-checkout-nonce', true, false ); ?>

                            <div class="dtsc-place-order-row">
                                <a href="<?php echo esc_url( wc_get_cart_url() ); ?>" class="dtsc-return-to-cart">
                                    &larr; <?php esc_html_e( 'Return to Cart', 'delicate-two-step-checkout' ); ?>
                                </a>
                                <button type="submit" class="button alt dtsc-place-order-btn" name="woocommerce_checkout_place_order" id="place_order" value="<?php esc_attr_e( 'Place Order', 'delicate-two-step-checkout' ); ?>">
                                    <?php esc_html_e( 'Place Order', 'delicate-two-step-checkout' ); ?>
                                </button>
                            </div>

                            <?php do_action( 'woocommerce_checkout_after_order_review' ); ?>
                        </div>

                    </div>

                    <?php /* ── Order Summary Sidebar ── */ ?>
                    <div class="dtsc-sidebar-column">
                        <div class="dtsc-order-summary dtsc-sticky-sidebar">
                            <h3 class="dtsc-section-title"><?php esc_html_e( 'Order summary', 'delicate-two-step-checkout' ); ?></h3>
                            <?php $this->render_order_summary(); ?>
                        </div>
                    </div>
                </div>

            </form>
        </div>
        <?php
        return ob_get_clean();
    }

    private function render_wc_field( $key, $checkout, $overrides = array() ) {
        $fields = $checkout->get_checkout_fields();
        $type   = strpos( $key, 'billing_' ) === 0 ? 'billing' : 'shipping';
        $field  = $fields[ $type ][ $key ] ?? array();
        if ( empty( $field ) ) {
            $field = array( 'type' => 'text', 'label' => ucwords( str_replace( '_', ' ', str_replace( $type . '_', '', $key ) ) ) );
        }
        $field = array_merge( $field, $overrides );
        woocommerce_form_field( $key, $field, $checkout->get_value( $key ) );
    }

    private function render_order_summary() {
        ?>
        <div class="dtsc-cart-items">
            <?php foreach ( WC()->cart->get_cart() as $cart_item_key => $cart_item ) :
                $_product = apply_filters( 'woocommerce_cart_item_product', $cart_item['data'], $cart_item, $cart_item_key );
                if ( ! $_product || ! $_product->exists() || $cart_item['quantity'] <= 0 ) continue;
                $product_name = apply_filters( 'woocommerce_cart_item_name', $_product->get_name(), $cart_item, $cart_item_key );
                $quantity     = $cart_item['quantity'];
                $subtotal     = apply_filters( 'woocommerce_cart_item_subtotal', WC()->cart->get_product_subtotal( $_product, $quantity ), $cart_item, $cart_item_key );
                $thumbnail    = $_product->get_image( array( 80, 80 ) );
                $item_data    = wc_get_formatted_cart_item_data( $cart_item );
            ?>
                <div class="dtsc-cart-item">
                    <div class="dtsc-cart-item-image">
                        <?php echo wp_kses_post( $thumbnail ); ?>
                        <span class="dtsc-cart-item-qty"><?php echo esc_html( $quantity ); ?></span>
                    </div>
                    <div class="dtsc-cart-item-details">
                        <span class="dtsc-cart-item-name"><?php echo wp_kses_post( $product_name ); ?></span>
                        <?php if ( $item_data ) : ?>
                            <div class="dtsc-cart-item-meta"><?php echo wp_kses_post( $item_data ); ?></div>
                        <?php endif; ?>
                    </div>
                    <div class="dtsc-cart-item-price"><?php echo wp_kses_post( $subtotal ); ?></div>
                </div>
            <?php endforeach; ?>
        </div>

        <div class="dtsc-coupon-section">
            <details class="dtsc-coupon-toggle">
                <summary><?php esc_html_e( 'Have a promo code?', 'delicate-two-step-checkout' ); ?></summary>
                <div class="dtsc-coupon-form">
                    <input type="text" name="coupon_code" class="dtsc-coupon-input" id="dtsc-coupon-code" placeholder="<?php esc_attr_e( 'Enter code', 'delicate-two-step-checkout' ); ?>" />
                    <button type="button" class="dtsc-coupon-apply-btn" id="dtsc-apply-coupon"><?php esc_html_e( 'Apply', 'delicate-two-step-checkout' ); ?></button>
                </div>
                <div id="dtsc-coupon-message" class="dtsc-coupon-message" style="display:none;"></div>
            </details>
        </div>

        <?php foreach ( WC()->cart->get_coupons() as $code => $coupon ) : ?>
            <div class="dtsc-applied-coupon" data-coupon="<?php echo esc_attr( $code ); ?>">
                <span class="dtsc-coupon-tag">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20.59 13.41l-7.17 7.17a2 2 0 01-2.83 0L2 12V2h10l8.59 8.59a2 2 0 010 2.82z"/><line x1="7" y1="7" x2="7.01" y2="7"/></svg>
                    <?php echo esc_html( $code ); ?>
                </span>
                <button type="button" class="dtsc-remove-coupon" data-coupon="<?php echo esc_attr( $code ); ?>">&times;</button>
            </div>
        <?php endforeach; ?>

        <div class="dtsc-order-totals">
            <?php
            // Calculate the same way as the AJAX handler
            $init_subtotal_excl = floatval( WC()->cart->get_subtotal() );
            $init_product_tax = floatval( WC()->cart->get_subtotal_tax() );
            $init_subtotal_incl = $init_subtotal_excl + $init_product_tax;
            $init_discount = floatval( WC()->cart->get_discount_total() );
            $init_discount_tax = floatval( WC()->cart->get_discount_tax() );

            // On initial page load, shipping cost is unknown — no method selected yet
            $init_shipping = 0;
            $init_shipping_label = __( 'Shipping', 'delicate-two-step-checkout' );
            $init_shipping_display = '—';

            // Check if session already has a rate (e.g. page refresh after quote)
            if ( WC()->session ) {
                $s_fulfillment = WC()->session->get( 'dtsc_fulfillment_type', '' );
                $s_cost = WC()->session->get( 'dcp_checkout_shipping_cost', 0 );
                if ( $s_fulfillment === 'collect' || $s_fulfillment === 'collection' ) {
                    $init_shipping = 0;
                    $init_shipping_label = __( 'Collection', 'delicate-two-step-checkout' );
                    $init_shipping_display = '<strong style="color:#2e7d32;">Free!</strong>';
                } elseif ( $s_cost && floatval( $s_cost ) > 0 ) {
                    $init_shipping = floatval( $s_cost );
                    $init_shipping_tax = round( $init_shipping * 0.15, 2 );
                    $init_shipping_display = wp_kses_post( wc_price( $init_shipping + $init_shipping_tax ) ) . ' <small>(incl. VAT)</small>';
                }
            }

            $init_shipping_tax = ( $init_shipping > 0 ) ? round( $init_shipping * 0.15, 2 ) : 0;
            $init_total_tax = $init_product_tax + $init_shipping_tax - $init_discount_tax;
            $init_grand_total = $init_subtotal_incl - ( $init_discount + $init_discount_tax ) + $init_shipping + $init_shipping_tax;
            ?>
            <div class="dtsc-total-row dtsc-subtotal-row">
                <span><?php esc_html_e( 'Subtotal', 'delicate-two-step-checkout' ); ?></span>
                <span><?php echo wp_kses_post( wc_price( $init_subtotal_incl ) ); ?> <small>(incl. VAT)</small></span>
            </div>
            <?php foreach ( WC()->cart->get_coupons() as $code => $coupon ) : ?>
                <div class="dtsc-total-row dtsc-coupon-row">
                    <span><?php echo esc_html( sprintf( __( 'Discount: %s', 'delicate-two-step-checkout' ), $code ) ); ?></span>
                    <span class="dtsc-discount-amount">-<?php wc_cart_totals_coupon_html( $coupon ); ?></span>
                </div>
            <?php endforeach; ?>
            <div class="dtsc-total-row dtsc-shipping-row">
                <span id="dtsc-shipping-label"><?php echo esc_html( $init_shipping_label ); ?></span>
                <span id="dtsc-shipping-total"><?php echo $init_shipping_display; ?></span>
            </div>
            <div class="dtsc-total-row dtsc-grand-total-row">
                <span><?php esc_html_e( 'Total', 'delicate-two-step-checkout' ); ?></span>
                <span class="dtsc-grand-total-amount"><?php echo wp_kses_post( wc_price( $init_grand_total ) ); ?>
                    <?php if ( $init_total_tax > 0 ) : ?>
                        <small>(includes <?php echo wp_kses_post( wc_price( $init_total_tax ) ); ?> VAT)</small>
                    <?php endif; ?>
                </span>
            </div>
            <?php if ( $init_total_tax > 0 ) : ?>
                <div class="dtsc-vat-note">
                    <?php echo wp_kses_post( sprintf( __( 'Including %s VAT', 'delicate-two-step-checkout' ), wc_price( $init_total_tax ) ) ); ?>
                </div>
            <?php endif; ?>
        </div>

        <div class="dtsc-edit-cart">
            <a href="<?php echo esc_url( wc_get_cart_url() ); ?>" class="dtsc-edit-cart-btn">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.68 13.39a2 2 0 002 1.61h9.72a2 2 0 002-1.61L23 6H6"/></svg>
                <?php esc_html_e( 'Edit cart', 'delicate-two-step-checkout' ); ?>
            </a>
        </div>
        <?php
    }

    private function get_scheduler_config() {
        $slot_start    = 830;  // 08:30 — stored as HHMM integer
        $slot_end      = 1630; // 16:30
        $slot_interval = 120;  // 2 hour intervals in minutes
        $blocked_days  = sanitize_text_field( get_option( 'dtsc_blocked_days', '0' ) );
        $blocked_dates = sanitize_text_field( get_option( 'dtsc_blocked_dates', '' ) );
        $max_advance   = max( 1, intval( get_option( 'dtsc_max_advance_days', 90 ) ) );

        $cart_item_count = 0;
        $appointment_dates = array();
        $debug_info = array();

        if ( function_exists( 'WC' ) && WC()->cart ) {
            foreach ( WC()->cart->get_cart() as $cart_item ) {
                $cart_item_count++;

                // Try to extract appointment/booking date from cart item meta
                $appt_timestamp = null;

                // WooCommerce Appointments plugin
                if ( ! empty( $cart_item['appointment'] ) ) {
                    if ( ! empty( $cart_item['appointment']['_start_date'] ) ) {
                        $appt_timestamp = $this->parse_date_string( $cart_item['appointment']['_start_date'] );
                    } elseif ( ! empty( $cart_item['appointment']['start_date'] ) ) {
                        $appt_timestamp = $this->parse_date_string( $cart_item['appointment']['start_date'] );
                    }
                }

                // WooCommerce Bookings plugin
                if ( ! $appt_timestamp && ! empty( $cart_item['booking'] ) ) {
                    if ( ! empty( $cart_item['booking']['_start_date'] ) ) {
                        $appt_timestamp = $this->parse_date_string( $cart_item['booking']['_start_date'] );
                    } elseif ( ! empty( $cart_item['booking']['date'] ) ) {
                        $appt_timestamp = $this->parse_date_string( $cart_item['booking']['date'] );
                    }
                }

                // Scan known appointment keys. WC Appointments stores the start
                // time as a Unix timestamp (numeric string) in
                // wc_appointments_field_start_date_time — handle that first.
                // NOTE: 'function_date' is intentionally excluded — it is an APF
                // addon field storing the customer's event date with lead time
                // already applied, which causes false positives.
                if ( ! $appt_timestamp ) {
                    $search_keys = array(
                        'wc_appointments_field_start_date_time',
                        'wc_appointments_field_start_date',
                        '_appointment_start',
                        '_start_date',
                        'start_date',
                        'booking_start',
                        'appointment_date',
                    );
                    $matched_key = '';
                    foreach ( $search_keys as $key ) {
                        if ( empty( $cart_item[ $key ] ) ) continue;
                        $val = $cart_item[ $key ];
                        // Unix timestamp stored as a numeric string (WC Appointments)
                        if ( is_numeric( $val ) && strlen( (string) $val ) >= 9 ) {
                            $ts = intval( $val );
                            if ( $ts > time() ) {
                                $appt_timestamp = $ts;
                                $matched_key = $key . ' (unix)';
                                break;
                            }
                        }
                        // Otherwise try as a formatted date string
                        $ts = $this->parse_date_string( $val );
                        if ( $ts && $ts > time() ) {
                            $appt_timestamp = $ts;
                            $matched_key = $key . ' (string: ' . $val . ')';
                            break;
                        }
                    }
                }

                // Fallback: scan the rendered cart item display data.
                // The display string "Appointments: - 07/05/2026 15:30 (1)" is the
                // most accurate fallback. Raw addon/cart-item deep scanning is
                // avoided because APF date-type addon fields cause false positives
                // and return the wrong delivery date.
                if ( ! $appt_timestamp && ! empty( $cart_item['data'] ) ) {
                    $item_data = apply_filters( 'woocommerce_get_item_data', array(), $cart_item );
                    if ( ! empty( $item_data ) ) {
                        $appt_timestamp = $this->find_appointment_date_in_array( $item_data );
                    }
                }

                if ( $appt_timestamp && $appt_timestamp > time() ) {
                    $appointment_dates[] = $appt_timestamp;
                    $debug_info[] = array(
                        'product'     => $cart_item['data']->get_name(),
                        'found'       => date( 'Y-m-d H:i', $appt_timestamp ),
                        'matched_key' => isset( $matched_key ) ? $matched_key : 'item_data_scan',
                    );
                } else {
                    // Log what keys exist for debugging
                    $item_keys = array_keys( $cart_item );
                    $string_vals = array();
                    foreach ( $cart_item as $k => $v ) {
                        if ( is_string( $v ) && strlen( $v ) >= 8 && strlen( $v ) <= 30 ) {
                            $string_vals[ $k ] = $v;
                        }
                    }
                    $debug_info[] = array(
                        'product'     => $cart_item['data']->get_name(),
                        'found'       => false,
                        'keys'        => $item_keys,
                        'string_vals' => $string_vals,
                    );
                }
            }
        }

        // Find earliest appointment date — this IS the delivery date.
        // When there are multiple products with different appointment dates,
        // the earliest one is pre-selected. Customer can opt for split delivery.
        $earliest_appt_date = '';
        $earliest_appt_time = '';
        $earliest_appt_timestamp = 0;
        $has_multiple_dates = false;
        if ( ! empty( $appointment_dates ) ) {
            sort( $appointment_dates );
            $earliest_raw = $appointment_dates[0];
            $earliest_appt_date = date( 'Y-m-d', $earliest_raw );
            $earliest_appt_time = date( 'H:i', $earliest_raw );
            $earliest_appt_timestamp = $earliest_raw;

            // Check if there are multiple different appointment dates
            $unique_dates = array_unique( array_map( function( $ts ) {
                return date( 'Y-m-d', $ts );
            }, $appointment_dates ) );
            $has_multiple_dates = count( $unique_dates ) > 1;
        }

        // The appointment date IS the first available delivery date.
        // No buffer — customers cannot select dates before the appointment.
        // For multiple products, the earliest appointment date is used.
        $now = current_time( 'timestamp' );
        $today_str = date( 'Y-m-d', $now );
        $tomorrow = date( 'Y-m-d', strtotime( '+1 day', strtotime( $today_str ) ) );

        if ( $earliest_appt_date && $earliest_appt_date >= $today_str ) {
            // Appointment date is the first selectable date — no earlier delivery allowed.
            $earliest_selectable = $earliest_appt_date;
        } else {
            // No appointment or appointment is in the past — use tomorrow.
            $earliest_selectable = $tomorrow;
        }

        // Build info string for display
        $lead_notice = '';
        if ( $earliest_appt_date ) {
            $display_date = date( 'd/m/Y', strtotime( $earliest_appt_date ) );
            if ( $has_multiple_dates ) {
                $lead_notice = sprintf(
                    __( 'Your earliest appointment is on %s. You have items with different appointment dates — you can select split delivery below if needed.', 'delicate-two-step-checkout' ),
                    $display_date
                );
            } else {
                $lead_notice = sprintf(
                    __( 'Your delivery date is %s. Please select your preferred time slot.', 'delicate-two-step-checkout' ),
                    $display_date
                );
            }
        }

        return array(
            'enabled'        => get_option( 'dtsc_scheduler_enabled', 'no' ),
            'required'       => get_option( 'dtsc_scheduler_required', 'no' ),
            'timeSlotStart'  => '08:30',
            'timeSlotEnd'    => '16:30',
            'saturdayEndTime' => '12:00',
            'timeSlotInterval' => $slot_interval,
            'blockedDays'    => $blocked_days,
            'blockedDates'   => $blocked_dates,
            'maxAdvanceDays' => $max_advance,
            'cartItemCount'  => $cart_item_count,
            'debug'          => $debug_info,
            // Earliest selectable date (based on appointment)
            'earliestDate'   => $earliest_selectable,
            'earliestTime'   => $earliest_appt_time ? $earliest_appt_time : '06:00',
            'earliestTimestamp' => strtotime( $earliest_selectable ),
            // Pre-selected date = earliest appointment date (if available and after lead time)
            'preselectedDate' => ( $earliest_appt_date >= $earliest_selectable ) ? $earliest_appt_date : '',
            // Whether multiple appointment dates exist (show split delivery option)
            'hasMultipleDates' => $has_multiple_dates,
            // All appointment dates — highlighted on calendar
            'appointmentDates' => array_map( function ( $ts ) {
                return array( 'date' => date( 'Y-m-d', $ts ), 'time' => date( 'H:i', $ts ) );
            }, $appointment_dates ),
            'i18n' => array(
                'leadTimeNotice'     => $lead_notice,
                'selectTime'         => __( 'Select a time slot', 'delicate-two-step-checkout' ),
                'scheduledFor'       => __( 'Delivery scheduled for', 'delicate-two-step-checkout' ),
                'at'                 => __( 'at', 'delicate-two-step-checkout' ),
                'dateRequired'       => __( 'Please select a delivery date.', 'delicate-two-step-checkout' ),
                'timeRequired'       => __( 'Please select a delivery time slot.', 'delicate-two-step-checkout' ),
                'splitDeliveryLabel' => __( 'I need items delivered on different dates', 'delicate-two-step-checkout' ),
                'splitDeliveryNotice' => __( 'Split deliveries incur a separate delivery fee per shipment. We\'ll contact you to arrange dates.', 'delicate-two-step-checkout' ),
            ),
        );
    }

    /**
     * Determine the customer's current fulfillment choice at server-side
     * field-validation time. Reads from $_POST first (authoritative at form
     * submit), then falls back to the WC session (set by the AJAX toggle),
     * then to 'delivery' as the safe default. This is intentionally lax
     * about request type so it works both at GET-render of the checkout
     * page and at POST-validation time.
     *
     * Returns one of: 'delivery' | 'collect'.
     */
    private function current_fulfillment_choice() {
        // 1. POST value wins — this is what the user actually submitted.
        if ( isset( $_POST['dtsc_delivery_method'] ) ) {
            $v = sanitize_text_field( wp_unslash( $_POST['dtsc_delivery_method'] ) );
            if ( $v === 'collect' || $v === 'collection' ) return 'collect';
            if ( $v === 'delivery' )                       return 'delivery';
        }
        // 2. Session — set by the AJAX `dtsc_set_fulfillment` toggle.
        if ( function_exists( 'WC' ) && WC()->session ) {
            $s = WC()->session->get( 'dtsc_fulfillment_type', '' );
            if ( $s === 'collect' || $s === 'collection' ) return 'collect';
            if ( $s === 'delivery' )                       return 'delivery';
        }
        return 'delivery';
    }

    /**
     * Make checkout address sub-fields optional at the WooCommerce checkout
     * level, conditionally.
     *
     * Billing address sub-fields are always relaxed on our checkout page —
     * for delivery orders, our JS copies the shipping address into billing
     * before submit; for collection orders, our JS injects the store
     * address. In both cases the values are set by JS, but because WC
     * re-validates server-side AND the JS write happens late in the form-
     * submission lifecycle, marking them required would risk false
     * rejections.
     *
     * Shipping address sub-fields are relaxed ONLY when the customer chose
     * collection. Collection orders submit an empty shipping address by
     * design — there's no delivery to a customer address. Marking those
     * fields required would cause the exact error we are fixing:
     *
     *     "Shipping Street address is a required field.
     *      Shipping Town / City is a required field.
     *      Shipping State / County is a required field.
     *      Shipping Postcode / ZIP is a required field."
     *
     * Contact fields (first_name, last_name, email, phone) remain required —
     * those apply equally to delivery and collection.
     */
    public function relax_billing_fields_for_collection( $fields ) {
        if ( ! $this->is_our_checkout_page() ) return $fields;

        // Billing sub-fields: always relax on our checkout page (see above).
        $billing_relax = array( 'billing_address_1', 'billing_address_2', 'billing_city', 'billing_state', 'billing_postcode' );
        foreach ( $billing_relax as $key ) {
            if ( isset( $fields['billing'][ $key ] ) ) {
                $fields['billing'][ $key ]['required'] = false;
            }
        }

        // Shipping sub-fields: relax ONLY when the customer chose collection.
        // For delivery orders we want WC's native validation to fire so a
        // customer who somehow submits without a shipping address gets a
        // clear error rather than an order with no destination.
        if ( $this->current_fulfillment_choice() === 'collect' ) {
            $shipping_relax = array(
                'shipping_first_name', 'shipping_last_name', 'shipping_company',
                'shipping_address_1',  'shipping_address_2', 'shipping_city',
                'shipping_state',      'shipping_postcode',  'shipping_country',
                'shipping_phone',
            );
            foreach ( $shipping_relax as $key ) {
                if ( isset( $fields['shipping'][ $key ] ) ) {
                    $fields['shipping'][ $key ]['required'] = false;
                }
            }
        }
        return $fields;
    }

    /**
     * Tell WooCommerce whether the current cart needs a shipping address.
     *
     * For collect orders, the answer is "no" — there's no parcel going to a
     * customer address. Returning false here is the most thorough way to
     * suppress server-side shipping-field validation, because WC consults
     * this flag at multiple points in the checkout lifecycle (validation,
     * order creation, email rendering, etc.).
     *
     * For delivery orders, leave WC's default behaviour alone.
     */
    public function cart_needs_shipping_address_for_collection( $needs ) {
        if ( ! $this->is_our_checkout_page() ) return $needs;
        if ( $this->current_fulfillment_choice() === 'collect' ) {
            return false;
        }
        return $needs;
    }

    /**
     * Ensure the order-received (thank-you) page always loads correctly.
     *
     * When our AJAX checkout redirects to /order-received/ORDER_ID/?key=…,
     * WooCommerce renders the thank-you template. This hook fires there and
     * ensures the session is clean so the cart-empty state doesn't cause issues.
     */
    public function ensure_thankyou_page_loads( $order_id ) {
        if ( ! $order_id ) return;

        // Clear the cart in case WC hasn't done so yet (e.g. after a gateway redirect)
        if ( function_exists( 'WC' ) && WC()->cart && ! WC()->cart->is_empty() ) {
            WC()->cart->empty_cart();
        }
    }

    /**
     * Parse a date string that may contain DD/MM/YYYY HH:MM anywhere.
     * Returns a Unix timestamp (int) or false.
     */
    private function parse_date_string( $str ) {
        if ( ! is_string( $str ) || strlen( $str ) < 8 ) return false;

        $str = trim( $str );

        // YYYY-MM-DD HH:MM — unambiguous, always parse this first
        if ( preg_match( '/(\d{4})-(\d{2})-(\d{2})\s+(\d{1,2}):(\d{2})/', $str, $m ) ) {
            $ts = mktime( (int) $m[4], (int) $m[5], 0, (int) $m[2], (int) $m[3], (int) $m[1] );
            if ( $ts && $ts > 0 ) return $ts;
        }

        // YYYY-MM-DD only (no time) — unambiguous
        if ( preg_match( '/(\d{4})-(\d{2})-(\d{2})/', $str, $m ) ) {
            $ts = mktime( 12, 0, 0, (int) $m[2], (int) $m[3], (int) $m[1] );
            if ( $ts && $ts > 0 ) return $ts;
        }

        // DD/MM/YYYY HH:MM or MM/DD/YYYY HH:MM — ambiguous!
        // Try DD/MM first (South African), verify the month is valid (1-12).
        // If DD > 12, it can only be DD/MM. If both <= 12, prefer DD/MM (SA locale).
        if ( preg_match( '/(\d{1,2})\/(\d{1,2})\/(\d{4})\s+(\d{1,2}):(\d{2})/', $str, $m ) ) {
            $a = (int) $m[1]; // first number
            $b = (int) $m[2]; // second number

            if ( $a > 12 && $b <= 12 ) {
                // First number > 12, must be the day → DD/MM
                $ts = mktime( (int) $m[4], (int) $m[5], 0, $b, $a, (int) $m[3] );
            } elseif ( $b > 12 && $a <= 12 ) {
                // Second number > 12, must be the day → MM/DD
                $ts = mktime( (int) $m[4], (int) $m[5], 0, $a, $b, (int) $m[3] );
            } else {
                // Both <= 12, ambiguous — try DD/MM first (SA format)
                $ts = mktime( (int) $m[4], (int) $m[5], 0, $b, $a, (int) $m[3] );
            }
            if ( $ts && $ts > 0 ) return $ts;
        }

        // DD-MM-YYYY HH:MM — same ambiguity handling
        if ( preg_match( '/(\d{1,2})-(\d{1,2})-(\d{4})\s+(\d{1,2}):(\d{2})/', $str, $m ) ) {
            $a = (int) $m[1];
            $b = (int) $m[2];
            if ( $a > 12 && $b <= 12 ) {
                $ts = mktime( (int) $m[4], (int) $m[5], 0, $b, $a, (int) $m[3] );
            } elseif ( $b > 12 && $a <= 12 ) {
                $ts = mktime( (int) $m[4], (int) $m[5], 0, $a, $b, (int) $m[3] );
            } else {
                $ts = mktime( (int) $m[4], (int) $m[5], 0, $b, $a, (int) $m[3] );
            }
            if ( $ts && $ts > 0 ) return $ts;
        }

        // DD/MM/YYYY only (no time)
        if ( preg_match( '/(\d{1,2})\/(\d{1,2})\/(\d{4})/', $str, $m ) ) {
            $a = (int) $m[1];
            $b = (int) $m[2];
            if ( $a > 12 && $b <= 12 ) {
                $ts = mktime( 12, 0, 0, $b, $a, (int) $m[3] );
            } elseif ( $b > 12 && $a <= 12 ) {
                $ts = mktime( 12, 0, 0, $a, $b, (int) $m[3] );
            } else {
                $ts = mktime( 12, 0, 0, $b, $a, (int) $m[3] );
            }
            if ( $ts && $ts > 0 ) return $ts;
        }

        return false;
    }

    /**
     * Recursively search an array for appointment date strings.
     * Looks for patterns like "20/02/2026 14:30" or "2026-02-20 14:30"
     */
    private function find_appointment_date_in_array( $data, $depth = 0 ) {
        if ( $depth > 5 || ! is_array( $data ) ) return null;

        foreach ( $data as $key => $value ) {
            // Skip known non-date keys
            if ( in_array( $key, array( 'data', 'key', 'product_id', 'variation_id', 'quantity', 'line_total', 'line_tax', 'line_subtotal' ), true ) ) {
                continue;
            }

            if ( is_string( $value ) && strlen( $value ) >= 8 ) {
                // Skip strings with no digits — they cannot contain a date.
                if ( ! preg_match( '/\d/', $value ) ) continue;
                // Skip strings that look like day-name-only values (e.g. "Saturday", "Monday")
                // which strtotime() would resolve to the next occurrence of that day.
                if ( preg_match( '/^(monday|tuesday|wednesday|thursday|friday|saturday|sunday)\s*$/i', $value ) ) continue;
                // Try to find any date pattern in this string
                $ts = $this->parse_date_string( $value );
                if ( $ts && $ts > time() ) return $ts;
            } elseif ( is_array( $value ) ) {
                $result = $this->find_appointment_date_in_array( $value, $depth + 1 );
                if ( $result ) return $result;
            }
        }
        return null;
    }
}
