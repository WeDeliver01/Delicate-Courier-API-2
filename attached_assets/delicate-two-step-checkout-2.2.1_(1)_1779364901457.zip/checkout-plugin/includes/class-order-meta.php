<?php
/**
 * Order Meta Handler for Delicate Two-Step Checkout.
 *
 * Saves checkout data to order meta and displays it on:
 *   - WooCommerce admin order screen
 *   - Customer order confirmation (thank-you) page
 *   - Order confirmation emails (HTML + plain text)
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class DTSC_Order_Meta {

    /** Collection store address (hardcoded to match the checkout template). */
    const STORE_NAME    = 'Honey Bee Baker';
    const STORE_ADDRESS = 'Stocks Centre, 5 Graham Road, Shere (Silverlakes), Pretoria';
    const STORE_MAP_URL = 'https://www.google.com/maps/dir/?api=1&destination=Stocks+Centre+5+Graham+Road+Shere+Pretoria+South+Africa';

    public function __construct() {
        add_action( 'woocommerce_checkout_create_order', array( $this, 'save_order_meta' ), 10, 2 );
        // Run LATE to strip ALL third-party shipping from every order.
        // Our delivery cost is added as a WC cart fee, not a shipping line item.
        add_action( 'woocommerce_checkout_create_order', array( $this, 'strip_all_third_party_shipping' ), 9999, 2 );
        add_action( 'woocommerce_admin_order_data_after_shipping_address', array( $this, 'display_admin_meta' ) );

        // Thank-you page and order-details page.
        add_action( 'woocommerce_order_details_after_order_table', array( $this, 'display_customer_details' ) );

        // Order emails.
        add_action( 'woocommerce_email_after_order_table', array( $this, 'display_email_details' ), 10, 4 );

        // Store order number as custom reference for DCP shipment booking.
        add_action( 'woocommerce_checkout_order_created', array( $this, 'store_custom_reference' ), 10, 1 );

        // Packing slips — add delivery details.
        // WooCommerce PDF Invoices & Packing Slips (by Ewout / WP Overnight)
        add_action( 'wpo_wcpdf_after_order_data', array( $this, 'display_packing_slip_details' ), 10, 2 );
        add_action( 'wpo_wcpdf_after_order_details', array( $this, 'display_packing_slip_details' ), 10, 2 );
        // WooCommerce Print Invoice & Delivery Notes
        add_action( 'wcdn_order_info_fields', array( $this, 'add_wcdn_delivery_fields' ), 10, 2 );
        // Generic — also display on the order meta box print view
        add_action( 'woocommerce_admin_order_data_after_order_details', array( $this, 'display_print_delivery_details' ) );
    }

    /**
     * After order is created, store the order number as a custom reference.
     * DCP reads this when building the shipment payload.
     */
    public function store_custom_reference( $order ) {
        $order_number = $order->get_order_number();
        $order->update_meta_data( '_dcp_custom_reference', $order_number );
        $order->save();
    }

    /**
     * Late-priority hook: strip ALL third-party shipping line items from every order.
     *
     * Our delivery cost is added as a WC cart fee ("Delivery"), so it's already
     * included in the order total. Any shipping line items added by other plugins
     * would double-charge the customer.
     *
     * We keep our own 'dtsc_special_trip' shipping items if present.
     */
    public function strip_all_third_party_shipping( $order, $data ) {
        // Remove ALL shipping line items — delivery cost is handled via the "Delivery" cart fee.
        foreach ( $order->get_items( 'shipping' ) as $item_id => $item ) {
            $order->remove_item( $item_id );
        }
        $order->set_shipping_total( 0 );
        $order->set_shipping_tax( 0 );
    }

    /* ═══════════════════════════════════════════════════════
     * SAVE ORDER META
     * ═══════════════════════════════════════════════════════ */
    public function save_order_meta( $order, $data ) {
        // Google Places data.
        $fields = array(
            'shipping_place_id'  => 'sanitize_text_field',
            'shipping_latitude'  => 'floatval',
            'shipping_longitude' => 'floatval',
            'billing_place_id'   => 'sanitize_text_field',
            'billing_latitude'   => 'floatval',
            'billing_longitude'  => 'floatval',
        );

        foreach ( $fields as $key => $sanitizer ) {
            // phpcs:ignore WordPress.Security.NonceVerification.Missing
            $value = isset( $_POST[ $key ] ) ? $sanitizer( wp_unslash( $_POST[ $key ] ) ) : '';
            if ( ! empty( $value ) ) {
                $order->update_meta_data( '_dtsc_' . $key, $value );
            }
        }

        // Courier quote from session — save as order meta for reference.
        if ( WC()->session ) {
            $quote = WC()->session->get( 'dtsc_courier_quote' );
            if ( $quote ) {
                $order->update_meta_data( '_dtsc_courier_quote', $quote );
                WC()->session->set( 'dtsc_courier_quote', null );
            }

            // Save the shipping cost for reference (the actual charge is via the "Delivery" cart fee).
            // This is the MARKED-UP price the customer paid.
            $shipping_cost = WC()->session->get( 'dcp_checkout_shipping_cost' );
            if ( $shipping_cost && floatval( $shipping_cost ) > 0 ) {
                $order->update_meta_data( '_dtsc_shipping_cost', floatval( $shipping_cost ) );
            }

            // Save the ORIGINAL courier rate (before markup) for shipment booking.
            // The DCP platform uses this to book at the actual Shiplogic rate.
            $original_rate = WC()->session->get( 'dcp_original_shipping_rate' );
            if ( $original_rate && floatval( $original_rate ) > 0 ) {
                $order->update_meta_data( '_dcp_original_shipping_rate', floatval( $original_rate ) );
            }

            // Clear session values
            WC()->session->set( 'dcp_checkout_shipping_cost', null );
            WC()->session->set( 'dcp_original_shipping_rate', null );
        }

        // Delivery method: 'delivery' or 'collection'.
        // Check for special trip FIRST — special trip orders submit as 'collect' but
        // should be stored as 'special_trip' so the admin sees the correct method.
        // phpcs:ignore WordPress.Security.NonceVerification.Missing
        $special_trip = isset( $_POST['dtsc_special_trip'] ) && $_POST['dtsc_special_trip'] === 'yes' ? 'yes' : 'no';
        // phpcs:ignore WordPress.Security.NonceVerification.Missing
        $delivery_method = isset( $_POST['dtsc_delivery_method'] ) ? sanitize_text_field( wp_unslash( $_POST['dtsc_delivery_method'] ) ) : 'delivery';

        if ( $special_trip === 'yes' ) {
            // Override: this is a special trip, NOT a regular collection.
            $order->update_meta_data( '_dtsc_delivery_method', 'special_trip' );
        } else {
            $order->update_meta_data( '_dtsc_delivery_method', $delivery_method );
        }

        // Delivery date & time from scheduler.
        // phpcs:ignore WordPress.Security.NonceVerification.Missing
        $delivery_date = isset( $_POST['dtsc_delivery_date'] ) ? sanitize_text_field( wp_unslash( $_POST['dtsc_delivery_date'] ) ) : '';
        // phpcs:ignore WordPress.Security.NonceVerification.Missing
        $delivery_time = isset( $_POST['dtsc_delivery_time'] ) ? sanitize_text_field( wp_unslash( $_POST['dtsc_delivery_time'] ) ) : '';
        // phpcs:ignore WordPress.Security.NonceVerification.Missing
        $split_delivery = isset( $_POST['dtsc_split_delivery'] ) ? 'yes' : 'no';

        if ( $delivery_date ) {
            $order->update_meta_data( '_dtsc_delivery_date', $delivery_date );
            $order->update_meta_data( '_dcp_delivery_date', $delivery_date );
        }
        if ( $delivery_time ) {
            $order->update_meta_data( '_dtsc_delivery_time', $delivery_time );
            $order->update_meta_data( '_dcp_delivery_time', $delivery_time );

            // Calculate collection time: subtract 90 minutes from delivery time range.
            // Same-day delivery — collection date always equals delivery date.
            // e.g. delivery "14:30 - 16:30" → collection "13:00 - 15:00"
            $collection_time = self::calculate_collection_time( $delivery_time );
            if ( $collection_time ) {
                $order->update_meta_data( '_dtsc_collection_time', $collection_time );
                $order->update_meta_data( '_dcp_collection_time', $collection_time );
            }
            // Collection date = delivery date (same-day)
            if ( $delivery_date ) {
                $order->update_meta_data( '_dtsc_collection_date', $delivery_date );
                $order->update_meta_data( '_dcp_collection_date', $delivery_date );
            }
        }
        if ( $split_delivery === 'yes' ) {
            $order->update_meta_data( '_dtsc_split_delivery', 'yes' );
        }

        // Recipient & delivery phone.
        // phpcs:ignore WordPress.Security.NonceVerification.Missing
        $self_receiving = isset( $_POST['dtsc_self_receiving'] ) ? 'yes' : 'no';
        $order->update_meta_data( '_dtsc_self_receiving', $self_receiving );

        if ( $self_receiving === 'no' ) {
            // phpcs:ignore WordPress.Security.NonceVerification.Missing
            $recipient_name = isset( $_POST['dtsc_recipient_name'] ) ? sanitize_text_field( wp_unslash( $_POST['dtsc_recipient_name'] ) ) : '';
            // phpcs:ignore WordPress.Security.NonceVerification.Missing
            $recipient_phone = isset( $_POST['dtsc_recipient_phone'] ) ? sanitize_text_field( wp_unslash( $_POST['dtsc_recipient_phone'] ) ) : '';
            if ( $recipient_name ) {
                $order->update_meta_data( '_dtsc_recipient_name', $recipient_name );

                // Split "First Last" into shipping_first_name / shipping_last_name
                // so the courier waybill (built from the shipping address) shows
                // the actual recipient, not the buyer. The buyer's name stays on
                // billing_first_name / billing_last_name — the two never mix.
                $parts = preg_split( '/\s+/', trim( $recipient_name ), 2 );
                if ( ! empty( $parts[0] ) ) {
                    $order->set_shipping_first_name( $parts[0] );
                }
                $order->set_shipping_last_name( isset( $parts[1] ) ? $parts[1] : '' );
            }
            if ( $recipient_phone ) {
                $order->update_meta_data( '_dtsc_recipient_phone', $recipient_phone );
                // Newer WC versions support shipping_phone; if available, set it.
                if ( method_exists( $order, 'set_shipping_phone' ) ) {
                    $order->set_shipping_phone( $recipient_phone );
                }
            }
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Missing
        $delivery_phone = isset( $_POST['dtsc_delivery_phone'] ) ? sanitize_text_field( wp_unslash( $_POST['dtsc_delivery_phone'] ) ) : '';
        if ( $delivery_phone ) {
            $order->update_meta_data( '_dtsc_delivery_phone', $delivery_phone );
        }

        // Special trip request — save additional data and order note.
        if ( $special_trip === 'yes' ) {
            $order->update_meta_data( '_dtsc_special_trip', 'yes' );
            // phpcs:ignore WordPress.Security.NonceVerification.Missing
            $special_trip_note = isset( $_POST['dtsc_special_trip_note'] ) ? sanitize_textarea_field( wp_unslash( $_POST['dtsc_special_trip_note'] ) ) : '';
            if ( $special_trip_note ) {
                $order->update_meta_data( '_dtsc_special_trip_note', $special_trip_note );
            }

            // Save the requested delivery address
            // phpcs:ignore WordPress.Security.NonceVerification.Missing
            $ship_addr = isset( $_POST['shipping_address_1'] ) ? sanitize_text_field( wp_unslash( $_POST['shipping_address_1'] ) ) : '';
            // phpcs:ignore WordPress.Security.NonceVerification.Missing
            $ship_city = isset( $_POST['shipping_city'] ) ? sanitize_text_field( wp_unslash( $_POST['shipping_city'] ) ) : '';
            // phpcs:ignore WordPress.Security.NonceVerification.Missing
            $ship_state = isset( $_POST['shipping_state'] ) ? sanitize_text_field( wp_unslash( $_POST['shipping_state'] ) ) : '';
            // phpcs:ignore WordPress.Security.NonceVerification.Missing
            $ship_post = isset( $_POST['shipping_postcode'] ) ? sanitize_text_field( wp_unslash( $_POST['shipping_postcode'] ) ) : '';
            $full_addr = trim( $ship_addr . ', ' . $ship_city . ', ' . $ship_state . ' ' . $ship_post, ', ' );
            if ( $full_addr ) {
                $order->update_meta_data( '_dtsc_special_trip_address', $full_addr );
            }

            // Save distance estimate data
            // phpcs:ignore WordPress.Security.NonceVerification.Missing
            $trip_distance = isset( $_POST['dtsc_special_trip_distance'] ) ? floatval( $_POST['dtsc_special_trip_distance'] ) : 0;
            // phpcs:ignore WordPress.Security.NonceVerification.Missing
            $trip_est_low = isset( $_POST['dtsc_special_trip_estimate_low'] ) ? floatval( $_POST['dtsc_special_trip_estimate_low'] ) : 0;
            // phpcs:ignore WordPress.Security.NonceVerification.Missing
            $trip_est_high = isset( $_POST['dtsc_special_trip_estimate_high'] ) ? floatval( $_POST['dtsc_special_trip_estimate_high'] ) : 0;

            if ( $trip_distance > 0 ) {
                $order->update_meta_data( '_dtsc_special_trip_distance_km', $trip_distance );
                $order->update_meta_data( '_dtsc_special_trip_estimate_low', $trip_est_low );
                $order->update_meta_data( '_dtsc_special_trip_estimate_high', $trip_est_high );
            }

            // Urgent order note for bakery
            $note = "🚨🚨 URGENT: SPECIAL TRIP DELIVERY QUOTE REQUIRED 🚨🚨\n\n";
            $note .= "This order was placed as Collection to secure the booking, but the customer needs DELIVERY to an area outside standard coverage.\n\n";
            $note .= "⚡ ACTION: Contact customer with delivery quote ASAP.\n";
            if ( $full_addr ) {
                $note .= "📍 Delivery Address: " . $full_addr . "\n";
            }
            if ( $trip_distance > 0 ) {
                $note .= "📏 Distance: " . number_format( $trip_distance, 1 ) . " km from bakery\n";
                $note .= "💰 Estimated Cost Shown to Customer: R" . number_format( $trip_est_low, 0 ) . " – R" . number_format( $trip_est_high, 0 ) . "\n";
            }
            // phpcs:ignore WordPress.Security.NonceVerification.Missing
            $phone = isset( $_POST['billing_phone'] ) ? sanitize_text_field( wp_unslash( $_POST['billing_phone'] ) ) : '';
            if ( $phone ) {
                $note .= "📞 Phone: " . $phone . "\n";
            }
            if ( $special_trip_note ) {
                $note .= "📝 Customer Note: " . $special_trip_note . "\n";
            }
            $order->add_order_note( $note, 0, true );

            // The delivery cost for special trips is handled by the "Delivery" cart fee.
            // No shipping line items needed — just save the estimate as meta for reference.
        }
    }

    /* ═══════════════════════════════════════════════════════
     * HELPER: Format the delivery time range for display.
     *
     * Input can be:
     *   "08:30 - 10:30"   (range from scheduler)
     *   "08:30"           (single time)
     *   ""                (empty)
     *
     * Returns a human-readable time string like "8:30 AM – 10:30 AM".
     * ═══════════════════════════════════════════════════════ */
    private function format_time_range( $time_str ) {
        if ( empty( $time_str ) ) {
            return '';
        }

        // Check if it's a range like "08:30 - 10:30"
        if ( strpos( $time_str, '-' ) !== false ) {
            $parts = array_map( 'trim', explode( '-', $time_str ) );
            $formatted = array();
            foreach ( $parts as $part ) {
                $ts = strtotime( '2000-01-01 ' . $part );
                if ( $ts !== false ) {
                    $formatted[] = date_i18n( get_option( 'time_format' ), $ts );
                } else {
                    $formatted[] = $part;
                }
            }
            return implode( ' – ', $formatted );
        }

        // Single time
        $ts = strtotime( '2000-01-01 ' . $time_str );
        if ( $ts !== false ) {
            return date_i18n( get_option( 'time_format' ), $ts );
        }

        return $time_str;
    }

    /**
     * Format delivery date for display.
     */
    private function format_date( $date_str ) {
        if ( empty( $date_str ) ) {
            return '';
        }
        $ts = strtotime( $date_str );
        if ( $ts === false ) {
            return $date_str;
        }
        return date_i18n( get_option( 'date_format' ), $ts );
    }

    /**
     * Calculate collection time by subtracting 90 minutes from the delivery time range.
     *
     * Same-day delivery: collection date always equals delivery date.
     * e.g. delivery "14:30 - 16:30" → collection "13:00 - 15:00"
     * e.g. delivery "08:30 - 10:30" → collection "07:00 - 09:00"
     *
     * @param string $delivery_time Time range like "14:30 - 16:30" or single time "14:30".
     * @return string|null Collection time range, or null if cannot be calculated.
     */
    public static function calculate_collection_time( $delivery_time ) {
        if ( empty( $delivery_time ) ) {
            return null;
        }

        // Handle range format "HH:MM - HH:MM"
        if ( strpos( $delivery_time, '-' ) !== false ) {
            $parts = array_map( 'trim', explode( '-', $delivery_time ) );
            if ( count( $parts ) !== 2 ) {
                return null;
            }

            $start = self::subtract_minutes_from_time( $parts[0], 90 );
            $end   = self::subtract_minutes_from_time( $parts[1], 90 );

            if ( $start === null || $end === null ) {
                return null;
            }

            return $start . ' - ' . $end;
        }

        // Single time "HH:MM"
        $result = self::subtract_minutes_from_time( $delivery_time, 90 );
        return $result;
    }

    /**
     * Subtract minutes from a HH:MM time string.
     *
     * @param string $time    Time in "HH:MM" format.
     * @param int    $minutes Minutes to subtract.
     * @return string|null    New time in "HH:MM" format, or null on failure.
     */
    private static function subtract_minutes_from_time( $time, $minutes ) {
        $ts = strtotime( '2000-01-01 ' . trim( $time ) );
        if ( $ts === false ) {
            return null;
        }
        $new_ts = $ts - ( $minutes * 60 );
        return date( 'H:i', $new_ts );
    }

    /* ═══════════════════════════════════════════════════════
     * ADMIN ORDER SCREEN
     * ═══════════════════════════════════════════════════════ */
    public function display_admin_meta( $order ) {
        $place_id     = $order->get_meta( '_dtsc_shipping_place_id' );
        $latitude     = $order->get_meta( '_dtsc_shipping_latitude' );
        $longitude    = $order->get_meta( '_dtsc_shipping_longitude' );
        $quote        = $order->get_meta( '_dtsc_courier_quote' );
        $del_date     = $order->get_meta( '_dtsc_delivery_date' );
        $del_time     = $order->get_meta( '_dtsc_delivery_time' );
        $del_method   = $order->get_meta( '_dtsc_delivery_method' );
        $split        = $order->get_meta( '_dtsc_split_delivery' );
        $special_trip = $order->get_meta( '_dtsc_special_trip' );
        $special_note = $order->get_meta( '_dtsc_special_trip_note' );

        // Special Trip — show first and prominently
        if ( $special_trip === 'yes' ) {
            $trip_addr     = $order->get_meta( '_dtsc_special_trip_address' );
            $trip_distance = $order->get_meta( '_dtsc_special_trip_distance_km' );
            $trip_est_low  = $order->get_meta( '_dtsc_special_trip_estimate_low' );
            $trip_est_high = $order->get_meta( '_dtsc_special_trip_estimate_high' );

            echo '<div style="margin-top: 12px; padding: 12px 14px; background: #FFF3CD; border: 2px solid #FFC107; border-radius: 6px;">';
            echo '<p style="margin: 0 0 4px; font-size: 13px; font-weight: bold; color: #856404;">🚨 Special Trip Request</p>';
            echo '<p style="margin: 4px 0; font-size: 12px; color: #856404;">Customer is <strong>outside standard delivery area</strong>.</p>';
            echo '<p style="margin: 8px 0 4px; font-size: 12px; color: #856404;"><strong>⚡ ACTION:</strong> Contact customer with delivery price.</p>';
            if ( $trip_addr ) {
                echo '<p style="margin: 4px 0; font-size: 12px;"><strong>📍 Delivery Address:</strong> ' . esc_html( $trip_addr ) . '</p>';
            }
            if ( $trip_distance ) {
                echo '<p style="margin: 4px 0; font-size: 12px;"><strong>📏 Distance:</strong> ' . esc_html( $trip_distance ) . ' km from bakery</p>';
            }
            if ( $trip_est_low && $trip_est_high ) {
                echo '<p style="margin: 4px 0; font-size: 12px;"><strong>💰 Estimate Shown to Customer:</strong> R' . esc_html( number_format( $trip_est_low, 0 ) ) . ' – R' . esc_html( number_format( $trip_est_high, 0 ) ) . '</p>';
            }
            if ( $special_note ) {
                echo '<p style="margin: 8px 0 4px; font-size: 12px;"><strong>📝 Note:</strong> ' . esc_html( $special_note ) . '</p>';
            }
            echo '</div>';
        }

        if ( ! $place_id && ! $latitude && ! $quote && ! $del_date && ! $del_method ) {
            return;
        }

        echo '<div class="dtsc-admin-meta" style="margin-top: 12px; padding: 10px; background: #f8f9fa; border: 1px solid #e2e4e7; border-radius: 4px;">';
        echo '<h4 style="margin: 0 0 8px; font-size: 13px; color: #1d2327;">Delicate Checkout Data</h4>';

        // Delivery method
        $is_collection = ( $del_method === 'collection' || $del_method === 'collect' );
        $is_special_trip = ( $del_method === 'special_trip' );
        if ( $del_method ) {
            if ( $is_special_trip ) {
                $method_label = '🚨 Special Trip Request';
            } elseif ( $is_collection ) {
                $method_label = '🏬 Collection from Store';
            } else {
                $method_label = '🚚 Delivery';
            }
            echo '<p style="margin: 4px 0; font-size: 12px;"><strong>Method:</strong> ' . esc_html( $method_label ) . '</p>';
        }

        if ( $is_collection ) {
            echo '<p style="margin: 4px 0; font-size: 12px;"><strong>Store:</strong> ' . esc_html( self::STORE_NAME ) . '</p>';
            echo '<p style="margin: 4px 0; font-size: 12px;">' . esc_html( self::STORE_ADDRESS ) . '</p>';
        }

        // Date & time
        if ( $del_date ) {
            echo '<p style="margin: 4px 0; font-size: 12px;"><strong>📅 ' . ( $is_collection ? 'Collection' : 'Delivery' ) . ' Date:</strong> ' . esc_html( $this->format_date( $del_date ) ) . '</p>';
        }
        if ( $del_time ) {
            echo '<p style="margin: 4px 0; font-size: 12px;"><strong>🕐 ' . ( $is_collection ? 'Collection' : 'Delivery' ) . ' Time:</strong> ' . esc_html( $this->format_time_range( $del_time ) ) . '</p>';
        }
        // Show calculated courier collection time for delivery orders
        if ( ! $is_collection ) {
            $coll_time = $order->get_meta( '_dtsc_collection_time' );
            if ( $coll_time ) {
                echo '<p style="margin: 4px 0; font-size: 12px;"><strong>📦 Courier Collection Time:</strong> ' . esc_html( $this->format_time_range( $coll_time ) ) . '</p>';
            }
        }
        if ( $split === 'yes' ) {
            echo '<p style="margin: 4px 0; font-size: 12px; color: #d63638;"><strong>📦 Split Delivery Requested</strong></p>';
        }

        echo '<hr style="margin: 8px 0; border: none; border-top: 1px solid #e2e4e7;" />';

        // Recipient info
        $self_receiving  = $order->get_meta( '_dtsc_self_receiving' );
        $recipient_name  = $order->get_meta( '_dtsc_recipient_name' );
        $recipient_phone = $order->get_meta( '_dtsc_recipient_phone' );
        $delivery_phone  = $order->get_meta( '_dtsc_delivery_phone' );

        if ( $self_receiving === 'no' && ( $recipient_name || $recipient_phone ) ) {
            echo '<p style="margin: 4px 0; font-size: 12px; color: #d63638;"><strong>⚠️ Someone else is receiving:</strong></p>';
            if ( $recipient_name ) {
                echo '<p style="margin: 4px 0; font-size: 12px;"><strong>👤 Recipient:</strong> ' . esc_html( $recipient_name ) . '</p>';
            }
            if ( $recipient_phone ) {
                echo '<p style="margin: 4px 0; font-size: 12px;"><strong>📱 Recipient Phone:</strong> ' . esc_html( $recipient_phone ) . '</p>';
            }
            echo '<hr style="margin: 8px 0; border: none; border-top: 1px solid #e2e4e7;" />';
        }
        if ( $delivery_phone ) {
            echo '<p style="margin: 4px 0; font-size: 12px;"><strong>📞 Alt. Phone:</strong> ' . esc_html( $delivery_phone ) . '</p>';
        }

        // Place data
        if ( $place_id ) {
            echo '<p style="margin: 4px 0; font-size: 12px;"><strong>Place ID:</strong> ' . esc_html( $place_id ) . '</p>';
        }
        if ( $latitude && $longitude ) {
            echo '<p style="margin: 4px 0; font-size: 12px;"><strong>Coordinates:</strong> ' . esc_html( $latitude ) . ', ' . esc_html( $longitude ) . '</p>';
            echo '<p style="margin: 4px 0; font-size: 12px;"><a href="https://www.google.com/maps?q=' . esc_attr( $latitude ) . ',' . esc_attr( $longitude ) . '" target="_blank" rel="noopener">View on Google Maps &rarr;</a></p>';
        }

        // Quote
        if ( $quote && is_array( $quote ) ) {
            echo '<hr style="margin: 8px 0; border: none; border-top: 1px solid #e2e4e7;" />';
            echo '<p style="margin: 4px 0; font-size: 12px;"><strong>Quote Status:</strong> ' . esc_html( $quote['status'] ?? 'N/A' ) . '</p>';
            if ( isset( $quote['price'] ) && $quote['price'] > 0 ) {
                echo '<p style="margin: 4px 0; font-size: 12px;"><strong>Quoted Price:</strong> ' . wp_kses_post( wc_price( $quote['price'] ) ) . '</p>';
            }
            if ( isset( $quote['message'] ) ) {
                echo '<p style="margin: 4px 0; font-size: 12px;"><strong>Message:</strong> ' . esc_html( $quote['message'] ) . '</p>';
            }
        }

        // Shipping & Tracking — pull from DCP plugin meta if available
        $tracking_ref    = $order->get_meta( '_dcp_tracking_reference' );
        $shipment_status = $order->get_meta( '_dcp_shipment_status' );
        $platform_id     = $order->get_meta( '_dcp_platform_order_id' );
        $original_rate   = $order->get_meta( '_dcp_original_shipping_rate' );
        $customer_paid   = $order->get_meta( '_dtsc_shipping_cost' );

        if ( $tracking_ref || $platform_id || ! $is_collection ) {
            echo '<hr style="margin: 8px 0; border: none; border-top: 1px solid #e2e4e7;" />';
            echo '<p style="margin: 0 0 4px; font-size: 12px; font-weight: bold; color: #1d2327;">📦 Shipment & Tracking</p>';

            if ( $tracking_ref ) {
                echo '<p style="margin: 4px 0; font-size: 12px;"><strong>Waybill / Tracking:</strong> ' . esc_html( $tracking_ref ) . '</p>';
                echo '<p style="margin: 4px 0; font-size: 12px;"><a href="https://shiplogic.com/track/' . esc_attr( $tracking_ref ) . '" target="_blank" rel="noopener" style="color: #2271b1;">🔗 Track Shipment →</a></p>';
            } else {
                echo '<p style="margin: 4px 0; font-size: 12px; color: #888;"><em>Awaiting waybill — shipment not yet created</em></p>';
            }

            if ( $shipment_status ) {
                $status_colors = array(
                    'created'    => '#2196F3',
                    'collected'  => '#FF9800',
                    'in_transit' => '#FF9800',
                    'delivered'  => '#4CAF50',
                    'failed'     => '#f44336',
                );
                $color = isset( $status_colors[ $shipment_status ] ) ? $status_colors[ $shipment_status ] : '#666';
                echo '<p style="margin: 4px 0; font-size: 12px;"><strong>Shipment Status:</strong> <span style="color: ' . esc_attr( $color ) . '; font-weight: 600;">' . esc_html( ucfirst( str_replace( '_', ' ', $shipment_status ) ) ) . '</span></p>';
            }

            echo '<p style="margin: 4px 0; font-size: 12px;"><strong>Customer Ref:</strong> #' . esc_html( $order->get_order_number() ) . '</p>';

            if ( $customer_paid && $customer_paid > 0 ) {
                echo '<p style="margin: 4px 0; font-size: 12px;"><strong>Customer Paid (Shipping):</strong> ' . wp_kses_post( wc_price( $customer_paid ) ) . '</p>';
            }
            if ( $original_rate && $original_rate > 0 && $customer_paid && floatval( $customer_paid ) !== floatval( $original_rate ) ) {
                echo '<p style="margin: 4px 0; font-size: 12px;"><strong>Courier Rate (Shiplogic):</strong> ' . wp_kses_post( wc_price( $original_rate ) ) . '</p>';
                $margin = floatval( $customer_paid ) - floatval( $original_rate );
                echo '<p style="margin: 4px 0; font-size: 12px;"><strong>Markup Margin:</strong> ' . wp_kses_post( wc_price( $margin ) ) . '</p>';
            }
        }

        echo '</div>';
    }

    /* ═══════════════════════════════════════════════════════
     * CUSTOMER THANK-YOU / ORDER DETAILS PAGE
     * ═══════════════════════════════════════════════════════ */
    public function display_customer_details( $order ) {
        $del_method = $order->get_meta( '_dtsc_delivery_method' );
        $del_date   = $order->get_meta( '_dtsc_delivery_date' );
        $del_time   = $order->get_meta( '_dtsc_delivery_time' );
        $split      = $order->get_meta( '_dtsc_split_delivery' );
        $special    = $order->get_meta( '_dtsc_special_trip' );

        $is_collection = ( $del_method === 'collection' || $del_method === 'collect' );
        $is_special_trip = ( $del_method === 'special_trip' || $special === 'yes' );

        // Always show something for delivery or collection orders
        if ( ! $del_method && ! $del_date ) {
            return;
        }

        if ( $is_special_trip ) {
            $heading = 'Delivery Details';
        } elseif ( $is_collection ) {
            $heading = 'Collection Details';
        } else {
            $heading = 'Delivery Schedule';
        }
        echo '<h2>' . esc_html__( $heading, 'delicate-two-step-checkout' ) . '</h2>';
        echo '<table class="woocommerce-table shop_table"><tbody>';

        // Method
        echo '<tr><th>' . esc_html__( 'Method', 'delicate-two-step-checkout' ) . '</th><td>';
        if ( $is_special_trip ) {
            echo esc_html__( 'Special Trip Delivery — the bakery will confirm your delivery cost', 'delicate-two-step-checkout' );
        } elseif ( $is_collection ) {
            echo esc_html__( 'Collection from Store', 'delicate-two-step-checkout' );
        } else {
            echo esc_html__( 'Delivery', 'delicate-two-step-checkout' );
        }
        echo '</td></tr>';

        // Special trip address
        if ( $is_special_trip ) {
            $trip_addr = $order->get_meta( '_dtsc_special_trip_address' );
            $trip_est_low = $order->get_meta( '_dtsc_special_trip_estimate_low' );
            $trip_est_high = $order->get_meta( '_dtsc_special_trip_estimate_high' );
            if ( $trip_addr ) {
                echo '<tr><th>' . esc_html__( 'Delivery Address', 'delicate-two-step-checkout' ) . '</th><td>' . esc_html( $trip_addr ) . '</td></tr>';
            }
            if ( $trip_est_low && $trip_est_high ) {
                echo '<tr><th>' . esc_html__( 'Estimated Cost', 'delicate-two-step-checkout' ) . '</th><td>R' . esc_html( number_format( $trip_est_low, 0 ) ) . ' – R' . esc_html( number_format( $trip_est_high, 0 ) ) . ' <em>(to be confirmed)</em></td></tr>';
            }
        }

        // Delivery address for regular delivery orders
        if ( ! $is_collection && ! $is_special_trip ) {
            $shipping = $order->get_address( 'shipping' );
            $addr = trim( ( $shipping['address_1'] ?? '' ) . ' ' . ( $shipping['address_2'] ?? '' ) );
            if ( $addr ) {
                $full_addr = $addr;
                if ( ! empty( $shipping['city'] ) ) $full_addr .= ', ' . $shipping['city'];
                if ( ! empty( $shipping['state'] ) ) $full_addr .= ', ' . $shipping['state'];
                if ( ! empty( $shipping['postcode'] ) ) $full_addr .= ' ' . $shipping['postcode'];
                echo '<tr><th>' . esc_html__( 'Delivery Address', 'delicate-two-step-checkout' ) . '</th><td>' . esc_html( $full_addr ) . '</td></tr>';
            }
        }

        // Collection store address
        if ( $is_collection && ! $is_special_trip ) {
            echo '<tr><th>' . esc_html__( 'Collect From', 'delicate-two-step-checkout' ) . '</th><td>';
            echo '<strong>' . esc_html( self::STORE_NAME ) . '</strong><br>';
            echo esc_html( self::STORE_ADDRESS );
            echo '<br><a href="' . esc_url( self::STORE_MAP_URL ) . '" target="_blank" rel="noopener">' . esc_html__( 'Get Directions →', 'delicate-two-step-checkout' ) . '</a>';
            echo '</td></tr>';
        }

        // Date
        if ( $del_date ) {
            $date_label = $is_collection ? 'Collection Date' : 'Delivery Date';
            echo '<tr><th>' . esc_html__( $date_label, 'delicate-two-step-checkout' ) . '</th><td>' . esc_html( $this->format_date( $del_date ) ) . '</td></tr>';
        }

        // Time
        if ( $del_time ) {
            $time_label = $is_collection ? 'Collection Time' : 'Delivery Time';
            echo '<tr><th>' . esc_html__( $time_label, 'delicate-two-step-checkout' ) . '</th><td>' . esc_html( $this->format_time_range( $del_time ) ) . '</td></tr>';
        }

        // Split delivery
        if ( $split === 'yes' ) {
            echo '<tr><th>' . esc_html__( 'Split Delivery', 'delicate-two-step-checkout' ) . '</th><td>' . esc_html__( 'Requested — we will contact you to arrange dates for each item.', 'delicate-two-step-checkout' ) . '</td></tr>';
        }

        // Alt phone for delivery orders
        if ( ! $is_collection || $is_special_trip ) {
            $alt_phone = $order->get_meta( '_dtsc_delivery_phone' );
            if ( $alt_phone ) {
                echo '<tr><th>' . esc_html__( 'Alternative Phone', 'delicate-two-step-checkout' ) . '</th><td>' . esc_html( $alt_phone ) . '</td></tr>';
            }
        }

        echo '</tbody></table>';
    }

    /* ═══════════════════════════════════════════════════════
     * ORDER EMAILS (HTML & PLAIN TEXT)
     * ═══════════════════════════════════════════════════════ */
    public function display_email_details( $order, $sent_to_admin, $plain_text, $email ) {
        $del_method = $order->get_meta( '_dtsc_delivery_method' );
        $del_date   = $order->get_meta( '_dtsc_delivery_date' );
        $del_time   = $order->get_meta( '_dtsc_delivery_time' );
        $split      = $order->get_meta( '_dtsc_split_delivery' );
        $special    = $order->get_meta( '_dtsc_special_trip' );

        $is_collection = ( $del_method === 'collection' || $del_method === 'collect' );
        $is_special_trip = ( $del_method === 'special_trip' || $special === 'yes' );

        if ( ! $del_method && ! $del_date ) {
            return;
        }

        if ( $is_special_trip ) {
            $heading = 'Special Trip Delivery';
        } elseif ( $is_collection ) {
            $heading = 'Collection Details';
        } else {
            $heading = 'Delivery Schedule';
        }

        if ( $plain_text ) {
            // ── Plain text email ──
            echo "\n" . strtoupper( $heading ) . "\n";
            echo str_repeat( '-', strlen( $heading ) ) . "\n";

            if ( $is_special_trip ) {
                echo "Method: Special Trip Delivery — we will confirm your delivery cost\n";
                $trip_addr = $order->get_meta( '_dtsc_special_trip_address' );
                $trip_est_low = $order->get_meta( '_dtsc_special_trip_estimate_low' );
                $trip_est_high = $order->get_meta( '_dtsc_special_trip_estimate_high' );
                if ( $trip_addr ) echo "Delivery Address: " . $trip_addr . "\n";
                if ( $trip_est_low && $trip_est_high ) echo "Estimated Cost: R" . number_format( $trip_est_low, 0 ) . " – R" . number_format( $trip_est_high, 0 ) . " (to be confirmed)\n";
            } elseif ( $is_collection ) {
                echo 'Method: Collection from Store' . "\n";
                echo 'Collect From: ' . self::STORE_NAME . "\n";
                echo self::STORE_ADDRESS . "\n";
            } else {
                echo 'Method: Delivery' . "\n";
                // Show delivery address
                $shipping = $order->get_address( 'shipping' );
                $addr = trim( ( $shipping['address_1'] ?? '' ) . ' ' . ( $shipping['address_2'] ?? '' ) );
                if ( $addr ) {
                    echo 'Delivery Address: ' . $addr;
                    if ( ! empty( $shipping['city'] ) ) echo ', ' . $shipping['city'];
                    if ( ! empty( $shipping['state'] ) ) echo ', ' . $shipping['state'];
                    if ( ! empty( $shipping['postcode'] ) ) echo ' ' . $shipping['postcode'];
                    echo "\n";
                }
            }

            if ( $del_date ) {
                echo ( $is_collection ? 'Collection' : 'Delivery' ) . ' Date: ' . $this->format_date( $del_date ) . "\n";
            }
            if ( $del_time ) {
                echo ( $is_collection ? 'Collection' : 'Delivery' ) . ' Time: ' . $this->format_time_range( $del_time ) . "\n";
            }
            if ( $split === 'yes' ) {
                echo "Split delivery requested — we will contact you to arrange dates.\n";
            }
            // Alt phone for delivery orders
            if ( ! $is_collection || $is_special_trip ) {
                $alt_phone = $order->get_meta( '_dtsc_delivery_phone' );
                if ( $alt_phone ) {
                    echo 'Alternative Phone: ' . $alt_phone . "\n";
                }
            }
            echo "\n";
        } else {
            // ── HTML email ──
            echo '<h2 style="margin: 18px 0 10px; font-size: 18px; color: #1d2327;">' . esc_html( $heading ) . '</h2>';
            echo '<div style="margin-bottom: 18px; padding: 12px 16px; background: #f8f9fa; border: 1px solid #e2e4e7; border-radius: 4px; font-size: 14px;">';

            // Method
            echo '<p style="margin: 0 0 6px;"><strong>Method:</strong> ';
            if ( $is_special_trip ) {
                echo 'Special Trip Delivery — we will confirm your delivery cost';
            } elseif ( $is_collection ) {
                echo 'Collection from Store';
            } else {
                echo 'Delivery';
            }
            echo '</p>';

            // Delivery address for regular delivery orders
            if ( ! $is_collection && ! $is_special_trip ) {
                $shipping = $order->get_address( 'shipping' );
                $addr = trim( ( $shipping['address_1'] ?? '' ) . ' ' . ( $shipping['address_2'] ?? '' ) );
                if ( $addr ) {
                    $full_addr = $addr;
                    if ( ! empty( $shipping['city'] ) ) $full_addr .= ', ' . $shipping['city'];
                    if ( ! empty( $shipping['state'] ) ) $full_addr .= ', ' . $shipping['state'];
                    if ( ! empty( $shipping['postcode'] ) ) $full_addr .= ' ' . $shipping['postcode'];
                    echo '<p style="margin: 0 0 6px;"><strong>Delivery Address:</strong> ' . esc_html( $full_addr ) . '</p>';
                }
            }

            // Special trip details
            if ( $is_special_trip ) {
                $trip_addr = $order->get_meta( '_dtsc_special_trip_address' );
                $trip_est_low = $order->get_meta( '_dtsc_special_trip_estimate_low' );
                $trip_est_high = $order->get_meta( '_dtsc_special_trip_estimate_high' );
                $trip_note = $order->get_meta( '_dtsc_special_trip_note' );
                if ( $trip_addr ) {
                    echo '<p style="margin: 0 0 6px;"><strong>Delivery Address:</strong> ' . esc_html( $trip_addr ) . '</p>';
                }
                if ( $trip_est_low && $trip_est_high ) {
                    echo '<p style="margin: 0 0 6px;"><strong>Estimated Cost:</strong> R' . esc_html( number_format( $trip_est_low, 0 ) ) . ' – R' . esc_html( number_format( $trip_est_high, 0 ) ) . ' <em>(to be confirmed)</em></p>';
                }
                if ( $trip_note ) {
                    echo '<p style="margin: 0 0 6px;"><strong>Customer Note:</strong> ' . esc_html( $trip_note ) . '</p>';
                }
            }

            // Collection store info
            if ( $is_collection && ! $is_special_trip ) {
                echo '<p style="margin: 0 0 6px;"><strong>Collect From:</strong> ' . esc_html( self::STORE_NAME ) . '</p>';
                echo '<p style="margin: 0 0 6px; color: #555;">' . esc_html( self::STORE_ADDRESS ) . '</p>';
                echo '<p style="margin: 0 0 6px;"><a href="' . esc_url( self::STORE_MAP_URL ) . '" style="color: #C8962E;">Get Directions →</a></p>';
            }

            // Date
            if ( $del_date ) {
                $label = $is_collection ? 'Collection Date' : 'Delivery Date';
                echo '<p style="margin: 0 0 6px;"><strong>' . esc_html( $label ) . ':</strong> ' . esc_html( $this->format_date( $del_date ) ) . '</p>';
            }

            // Time
            if ( $del_time ) {
                $label = $is_collection ? 'Collection Time' : 'Delivery Time';
                echo '<p style="margin: 0 0 6px;"><strong>' . esc_html( $label ) . ':</strong> ' . esc_html( $this->format_time_range( $del_time ) ) . '</p>';
            }

            // Split
            if ( $split === 'yes' ) {
                echo '<p style="margin: 6px 0 0; font-size: 13px; color: #b54300;">Split delivery requested — we will contact you to arrange dates for each item.</p>';
            }

            // Alt phone for delivery orders
            if ( ! $is_collection || $is_special_trip ) {
                $alt_phone = $order->get_meta( '_dtsc_delivery_phone' );
                if ( $alt_phone ) {
                    echo '<p style="margin: 6px 0 0;"><strong>📞 Alternative Phone:</strong> ' . esc_html( $alt_phone ) . '</p>';
                }
            }

            echo '</div>';
        }
    }

    /* ═══════════════════════════════════════════════════════
     * PACKING SLIPS — Delivery details for shipping orders
     * ═══════════════════════════════════════════════════════ */

    /**
     * Display delivery details on packing slips.
     * Works with WooCommerce PDF Invoices & Packing Slips (wpo_wcpdf_after_order_data).
     *
     * @param string $document_type 'packing-slip', 'invoice', etc.
     * @param object $order WC_Order instance.
     */
    public function display_packing_slip_details( $document_type = '', $order = null ) {
        // Accept both (type, order) and (order) signatures
        if ( $document_type instanceof \WC_Order ) {
            $order = $document_type;
            $document_type = '';
        }
        if ( ! $order ) return;

        $del_method = $order->get_meta( '_dtsc_delivery_method' );
        $is_collection = ( $del_method === 'collection' || $del_method === 'collect' );
        $is_special_trip = ( $del_method === 'special_trip' );

        // Only show delivery details for shipping orders (not collection)
        if ( $is_collection && ! $is_special_trip ) {
            // Collection — just show store pickup info
            echo '<div style="margin-top: 10px; padding: 8px; border: 1px solid #ddd;">';
            echo '<strong>Collection Order</strong><br>';
            echo 'Collect From: ' . esc_html( self::STORE_NAME ) . '<br>';
            echo esc_html( self::STORE_ADDRESS );
            $del_date = $order->get_meta( '_dtsc_delivery_date' );
            $del_time = $order->get_meta( '_dtsc_delivery_time' );
            if ( $del_date ) echo '<br>Collection Date: ' . esc_html( $this->format_date( $del_date ) );
            if ( $del_time ) echo '<br>Collection Time: ' . esc_html( $this->format_time_range( $del_time ) );
            echo '</div>';
            return;
        }

        // Delivery order — show full delivery details
        $del_date   = $order->get_meta( '_dtsc_delivery_date' );
        $del_time   = $order->get_meta( '_dtsc_delivery_time' );
        $alt_phone  = $order->get_meta( '_dtsc_delivery_phone' );
        $tracking   = $order->get_meta( '_dcp_tracking_reference' );
        $split      = $order->get_meta( '_dtsc_split_delivery' );
        $special    = $order->get_meta( '_dtsc_special_trip' );
        $coll_time  = $order->get_meta( '_dtsc_collection_time' );

        // Recipient info
        $self_receiving = $order->get_meta( '_dtsc_self_receiving' );
        $recipient_name = $order->get_meta( '_dtsc_recipient_name' );
        $recipient_phone = $order->get_meta( '_dtsc_recipient_phone' );

        echo '<div style="margin-top: 10px; padding: 8px; border: 1px solid #333; font-size: 11px;">';
        echo '<strong style="font-size: 12px;">DELIVERY DETAILS</strong><br>';

        if ( $is_special_trip || $special === 'yes' ) {
            echo '<strong style="color: #c00;">⚠ SPECIAL TRIP DELIVERY</strong><br>';
            $trip_addr = $order->get_meta( '_dtsc_special_trip_address' );
            if ( $trip_addr ) {
                echo 'Delivery Address: ' . esc_html( $trip_addr ) . '<br>';
            }
        }

        // Shipping address
        $shipping = $order->get_address( 'shipping' );
        $addr = trim( $shipping['address_1'] . ' ' . ( $shipping['address_2'] ?? '' ) );
        if ( $addr ) {
            echo 'Address: ' . esc_html( $addr ) . '<br>';
            if ( $shipping['city'] ) echo esc_html( $shipping['city'] );
            if ( $shipping['state'] ) echo ', ' . esc_html( $shipping['state'] );
            if ( $shipping['postcode'] ) echo ' ' . esc_html( $shipping['postcode'] );
            echo '<br>';
        }

        if ( $del_date ) echo 'Delivery Date: <strong>' . esc_html( $this->format_date( $del_date ) ) . '</strong><br>';
        if ( $del_time ) echo 'Delivery Time: <strong>' . esc_html( $this->format_time_range( $del_time ) ) . '</strong><br>';
        if ( $coll_time ) echo 'Courier Collection: ' . esc_html( $this->format_time_range( $coll_time ) ) . '<br>';

        // Recipient
        if ( $self_receiving === 'no' && $recipient_name ) {
            echo 'Recipient: ' . esc_html( $recipient_name );
            if ( $recipient_phone ) echo ' (' . esc_html( $recipient_phone ) . ')';
            echo '<br>';
        }

        // Contact phones
        $billing_phone = $order->get_billing_phone();
        if ( $billing_phone ) echo 'Phone: ' . esc_html( $billing_phone ) . '<br>';
        if ( $alt_phone ) echo 'Alt Phone: ' . esc_html( $alt_phone ) . '<br>';

        // Tracking
        if ( $tracking ) echo 'Waybill: <strong>' . esc_html( $tracking ) . '</strong><br>';

        // Split delivery
        if ( $split === 'yes' ) echo '<strong style="color: #c00;">SPLIT DELIVERY REQUESTED</strong><br>';

        // Order note
        $customer_note = $order->get_customer_note();
        if ( $customer_note ) echo 'Note: ' . esc_html( $customer_note ) . '<br>';

        echo '</div>';
    }

    /**
     * Add delivery fields for WooCommerce Print Invoice & Delivery Notes plugin.
     */
    public function add_wcdn_delivery_fields( $fields, $order ) {
        $del_method = $order->get_meta( '_dtsc_delivery_method' );
        $is_collection = ( $del_method === 'collection' || $del_method === 'collect' );
        $is_special_trip = ( $del_method === 'special_trip' );

        if ( $is_collection && ! $is_special_trip ) {
            $fields['dtsc_method'] = array(
                'label' => 'Method',
                'value' => 'Collection from Store',
            );
            return $fields;
        }

        $fields['dtsc_method'] = array(
            'label' => 'Method',
            'value' => $is_special_trip ? 'Special Trip Delivery' : 'Delivery',
        );

        $del_date = $order->get_meta( '_dtsc_delivery_date' );
        if ( $del_date ) {
            $fields['dtsc_date'] = array(
                'label' => 'Delivery Date',
                'value' => $this->format_date( $del_date ),
            );
        }

        $del_time = $order->get_meta( '_dtsc_delivery_time' );
        if ( $del_time ) {
            $fields['dtsc_time'] = array(
                'label' => 'Delivery Time',
                'value' => $this->format_time_range( $del_time ),
            );
        }

        $alt_phone = $order->get_meta( '_dtsc_delivery_phone' );
        if ( $alt_phone ) {
            $fields['dtsc_alt_phone'] = array(
                'label' => 'Alt Phone',
                'value' => $alt_phone,
            );
        }

        $tracking = $order->get_meta( '_dcp_tracking_reference' );
        if ( $tracking ) {
            $fields['dtsc_waybill'] = array(
                'label' => 'Waybill',
                'value' => $tracking,
            );
        }

        return $fields;
    }

    /**
     * Display delivery details on the admin order print view.
     */
    public function display_print_delivery_details( $order ) {
        $del_method = $order->get_meta( '_dtsc_delivery_method' );
        if ( ! $del_method || $del_method === 'collect' || $del_method === 'collection' ) {
            return;
        }
        // Only output in print context — check if this is a print view
        // This method is hooked to woocommerce_admin_order_data_after_order_details
        // which fires on the normal admin page too, so we keep it minimal
        $del_date = $order->get_meta( '_dtsc_delivery_date' );
        $del_time = $order->get_meta( '_dtsc_delivery_time' );
        if ( $del_date || $del_time ) {
            echo '<p class="form-field form-field-wide">';
            echo '<strong>Delivery: </strong>';
            if ( $del_date ) echo esc_html( $this->format_date( $del_date ) );
            if ( $del_time ) echo ' at ' . esc_html( $this->format_time_range( $del_time ) );
            echo '</p>';
        }
    }
}
