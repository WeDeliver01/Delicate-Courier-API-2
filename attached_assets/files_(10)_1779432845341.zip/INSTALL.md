# Delicate API Adapter — Install Guide

This guide walks the bakery's administrator (or anyone with WP admin access) through installing the Delicate API Adapter (DAA) plugin and configuring it for the first time.

You do not need to be a developer to follow it. If you get stuck at any step, the kill-switch runbook describes how to revert.

---

## 1. Prerequisites — please check before installing

Open WordPress admin → **Plugins**. Confirm that:

- **WooCommerce** is installed and active. Required version: 6.0 or newer.
- **Delicate Courier Platform** is installed and active. Required version: **2.4.3 or newer**. Open it and confirm the version shown in the plugin row.

If either of those is missing or out of date, install/update those first. DAA does no harm if installed before they are, but its features stay dormant until both are present and compatible.

## 2. Install DAA

1. In WordPress admin go to **Plugins → Add New → Upload Plugin**.
2. Choose the file `delicate-api-adapter-0.1.0.zip`.
3. Click **Install Now**, then **Activate Plugin**.

At this point DAA is installed but completely dormant. The master switch is OFF by default — even if you uploaded a misconfigured copy, nothing on your store will change behaviour yet.

## 3. Verify the install was clean

Go to **WooCommerce → Delicate API Adapter** (it is a submenu under WooCommerce in the left sidebar).

You should see a "Dependency Status" panel with these three rows:

| Field | Expected value |
|---|---|
| Delicate Courier Platform | ✓ Active, version 2.4.3 — compatible |
| Adapter version | 0.1.0 |
| HPOS compatibility | Declared at boot. … |

If DCP shows a red ✗ or a yellow ⚠, **do not proceed** — first resolve the DCP issue (install / update / activate it).

## 4. First-time configuration

Still on **WooCommerce → Delicate API Adapter**, scroll down. You will see four sections of settings:

### Master Switch
Leave OFF for now. We will only flip this ON at the very last step, after you have configured everything and run a test order with the test-mode coupon.

### Feature Toggles
Leave ALL OFF for now. They will be enabled one at a time.

### Date Picker Settings
The pre-seeded defaults match the bakery's hours and lead-time policy: 48 hour minimum lead time, 60 day booking window, Sundays disabled, Mon-Sat open. **Review these and adjust if your hours have changed.** Leave them alone if they look right.

### Fulfillment Mapping
You will see a textarea pre-populated with four lines, one per shipping method. Each line is in the form

```
method_id = verdict|label_hint
```

The default values were captured from your live cart page on 2026-05-21. If your shipping zones have been edited since (the `:NN` instance numbers change when zones are deleted and recreated), the numbers may need updating. The label hints (after the pipe) are a safety net: even if the instance number changes, DAA will still match on a substring of the method's label.

**To check whether the IDs are still right**, open another tab and go to **WooCommerce → Settings → Shipping → Shipping zones**. For each shipping method in each zone, hover the row — the URL preview at the bottom of the browser will include `instance_id=NN`. Confirm the mapping numbers match. If they don't, edit the mapping textarea.

### Shipping Address Overrides
Pre-populated with two entries — `flat_rate:36` mapped to the Meyerspark satellite, and `flat_rate:37` mapped to the Irene satellite. **Verify the addresses are exactly correct.** If a satellite has moved, edit the corresponding JSON. The required fields are `address_1`, `city`, `state` (use `GP` for Gauteng), and `postcode`.

Click **Save Changes** at the bottom.

## 5. Create the test-mode coupon

Test mode lets you place a test order, see exactly what DAA would write to it, and inspect the result — without enabling DAA's behaviour for real customers.

1. Go to **WooCommerce → Coupons → Add coupon**.
2. Coupon code: pick something long and unguessable, e.g. `DAA_TRACE_a1b2c3d4`. Real customers must not be able to guess this string.
3. Description: "DAA test mode trigger — do not delete."
4. Coupon type: Fixed cart discount.
5. Coupon amount: 0.
6. Usage limit per coupon: leave blank.
7. Click **Publish**.

Now back to **WooCommerce → Delicate API Adapter**:

1. Tick **Test mode (coupon-triggered)**.
2. Paste your coupon code into the **Test-mode coupon code** field.
3. Click **Save Changes**.

Test mode is intentionally NOT gated by the master switch — it works even with master OFF. That is exactly the configuration we want for the next step.

## 6. Test order with the master OFF (the safety dress rehearsal)

While the master switch is still OFF:

1. In an incognito / private browser window, browse to the shop, add one product to the cart, go to checkout.
2. Apply your test-mode coupon (it discounts the cart by R0 — purely a flag).
3. Pick a shipping method — start with **Collect from 198 Watermeyer St, Meyerspark** (`flat_rate:36`).
4. Fill in the customer details with your own / a test email address.
5. Complete the order — pay via EFT or whatever payment method you usually use for test orders.

Then back in WP admin → **WooCommerce → Orders** → click into the test order:

1. The order's shipping address should still show the customer's address (master is OFF, so address rewrite did NOT happen).
2. Scroll to the Custom Fields area (you may need to enable it under "Screen Options" at the top right). Look for `_daa_decision_trace`.
3. The value is a JSON blob. Copy it into a text editor — it shows exactly what DAA *would have done* if master had been ON. You should see `verdict: delivery`, `would_write: true`, `would_rewrite: true`, and the satellite address that would have replaced the customer's address.

If that all looks right, you can proceed. If anything is wrong (wrong satellite address, wrong fulfillment verdict, mapping rule didn't match), fix the settings and place another test order before continuing.

## 7. Repeat for each shipping method

Place 3 more test orders, one with each remaining shipping method (`local_pickup:35`, `flat_rate:37`, `distance_rate:40`). For each, confirm in the trace that the verdict and rewrite-or-not behaviour is correct. Specifically:

| Method | Expected verdict | Should rewrite? |
|---|---|---|
| local_pickup:35 (main shop) | collect | no |
| flat_rate:36 (Meyerspark) | delivery | yes, to 198 Watermeyer St |
| flat_rate:37 (Irene) | delivery | yes, to 1 Clifford Rd |
| distance_rate:40 (customer delivery) | delivery | no (deliver to customer's address) |

If any of the four behaves unexpectedly, fix the mapping or the override and re-test before flipping the master switch.

## 8. Enable features one at a time

Once you are satisfied that test-mode predictions match what you want:

1. On the settings page, enable the **Date Picker** toggle. Save. Place one real test order (without the magic coupon). Confirm the checkout shows a delivery date picker above the billing details, with the right hours blackout.
2. Enable the **Fulfillment-type mapping** toggle. Save. Place one more test order. Confirm in the order's meta that `_dcp_fulfillment_type` is now populated (and that DCP picks the right value when it pushes the order to the platform).
3. Enable the **Shipping address rewrite** toggle. Save. Place one more test order using `flat_rate:36`. Confirm the order's shipping address has been rewritten to the satellite address.

You can — and should — keep test mode ENABLED throughout. The decision trace remains useful as a per-order audit trail.

## 9. Turn the master switch ON

After all individual features have been verified one at a time, return to **Master Switch** at the top of the settings page, tick the box, and click **Save Changes**.

The adapter is now live. New real-customer orders will be processed with the configured behaviour.

## 10. After go-live: monitoring

For the first week, check **WooCommerce → Delicate API Adapter → Recent Activity** at least once a day. The log shows the last 100 decisions made. You want to see:

- `info` rows from `date_picker`, `fulfillment`, and `address_rewrite` for normal orders
- Occasional `info` rows like "Passive: DCP shipping method chosen" or "No address override for chosen method; passthrough" — these are normal for orders using other shipping methods

If you see:

- `warning` rows from `fulfillment` (e.g. "No mapping rule matched") — something has been mis-configured, or your shipping zones have changed. Fix the mapping table.
- `error` rows from anywhere — please send a screenshot to your developer.

## 11. If anything goes wrong

See `RUNBOOK.md` (the kill-switch runbook) included in this kit. The fastest fix is: settings page → uncheck the **Master Switch** → Save Changes. The adapter becomes immediately dormant without uninstalling.
