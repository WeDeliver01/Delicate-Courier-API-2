# Delicate API Adapter — Ship Kit

Drop this folder (or just the zip) to the bakery's WP administrator.

## What's in here

| File | Audience | What it's for |
|---|---|---|
| `delicate-api-adapter-0.1.0.zip` | The administrator who will install the plugin | The plugin itself. Upload to **WP admin → Plugins → Add New → Upload**. |
| `INSTALL.md` | The same person | Step-by-step install + first-time configuration. Reads top to bottom; follow in order. Includes a test-order walkthrough that verifies behaviour before going live. |
| `RUNBOOK.md` | The same person + you (developer) | Kill-switch procedures, common incident triage, diagnostics. Keep this somewhere reachable from a phone — it's what gets read at 11pm when something is on fire. |
| `SIM-REPORT.md` | You (developer) — and future maintainers | Record of what was verified pre-ship and how. Not for the merchant. Pin to your project notes. |

## Versions in this kit

- DAA: 0.1.0
- Tested against DCP: 2.4.3 (the minimum required version)
- Tested against WP: 6.4.3 (sim env); bakery target is 6.9.4
- Tested against WC: 10.7-stubbed (sim env); bakery has 10.7.0

## Quick start for the developer

If you just want the short version:

1. The plugin is in the zip. Behaviour matches everything in the handoff doc.
2. Install on the bakery's site via the normal plugin upload route.
3. First time you load **WooCommerce → Delicate API Adapter**, the dependency panel should show DCP green; if it doesn't, address that first.
4. Master switch defaults OFF. Leave it OFF, create the test-mode coupon, place test orders, inspect the `_daa_decision_trace` meta on each. Once happy, enable features one at a time, then finally flip master ON.
5. If anything goes sideways: master switch OFF → save. Adapter becomes immediately dormant. See `RUNBOOK.md` for the full incident playbook.
