# Delicate API Adapter — Kill-Switch & Incident Runbook

When something goes wrong on the store and you suspect DAA is involved (or just want to rule it out), this document tells you how to disable it fast.

The kill methods are listed from least to most aggressive. Use the first one that fits your access.

---

## Method 1 (preferred): the master switch

**Time to effect:** immediate, < 1 second.
**Requires:** access to WP admin as a user with `manage_woocommerce` capability.

1. Log into WP admin.
2. Go to **WooCommerce → Delicate API Adapter**.
3. Untick **Adapter master switch**.
4. Click **Save Changes**.

The adapter immediately becomes dormant. It is still installed and active, the log table is still there, the settings are preserved — but no checkout hook will do anything. The next order placed will behave as if DAA was never installed (DCP will use its own heuristics).

Use this method first in 99% of cases. It's reversible — flipping it back ON resumes adapter behaviour for the next order.

## Method 2: deactivate the plugin

**Time to effect:** immediate, < 1 second.
**Requires:** access to WP admin → Plugins.

1. Go to **Plugins**.
2. Find **Delicate API Adapter** in the list.
3. Click **Deactivate**.

This unloads the entire plugin. Settings and log table stay in place — re-activating later restores everything. Use this if you suspect the issue is in DAA's code itself (e.g. PHP errors in error_log), not just in the configuration.

## Method 3: rename the plugin folder (admin inaccessible)

**Time to effect:** immediate.
**Requires:** FTP, SFTP, SSH, or your host's file manager.

1. Connect to the site's file system.
2. Navigate to `wp-content/plugins/`.
3. Rename the folder `delicate-api-adapter` to `delicate-api-adapter.disabled`.

WordPress will deactivate the plugin on the next request (because its main file is no longer at the expected path) and post a "plugin deactivated due to error" notice. The site continues to work normally. Reverse by renaming back.

Use this if the admin dashboard is broken and Method 1 / 2 are unreachable.

## Method 4: rollback to pre-install

**Time to effect:** depends on backup restore time.
**Requires:** access to a recent backup taken before DAA was installed.

This is only relevant if you have an active production issue that you believe DAA caused AND the simpler methods above haven't resolved it. Restore from backup as you would for any other plugin incident.

A safer-and-faster alternative is Method 3 + post-incident analysis. The plugin folder rename does not affect customer orders that have already been placed.

---

## Diagnosing without disabling

Before reaching for a kill switch, sometimes you just want to know what DAA *is* doing.

### Look at the log

1. **WooCommerce → Delicate API Adapter** → scroll to "Recent Activity".
2. The last 100 decisions are listed, newest first. Each row shows level, feature, order id (if any), and message. Click the "context" link on a row for the full JSON detail of what was inspected.

### Look at a specific order's meta

1. **WooCommerce → Orders** → click the order in question.
2. Top right "Screen Options" → tick **Custom Fields** if not already on.
3. Scroll to the Custom Fields area below the order detail.
4. Relevant keys to inspect:
   - `_dcp_fulfillment_type`: what verdict (collect/delivery/special_trip) DAA wrote to override DCP's heuristic. Empty means DAA stood down for this order.
   - `_daa_fulfillment_source`: `mapping` means DAA's mapping table chose the value.
   - `_daa_address_rewritten`: `1` if the shipping address was changed.
   - `_daa_address_rewrite_method`: which shipping-method id triggered the rewrite.
   - `_daa_original_shipping_address`: JSON snapshot of what the customer originally entered. Decode with any online JSON formatter.
   - `_daa_decision_trace`: only present when the test-mode coupon was applied. Full diagnostic trace.

### Force a fresh diagnostic on a new order

If you have a current customer complaint and want to know exactly what would happen:

1. Place a test order through an incognito browser window.
2. Apply your test-mode coupon.
3. Pick the same shipping method the customer used.
4. Complete the order.
5. Inspect `_daa_decision_trace` on that new order.

The trace shows all toggles, the dependency status, the chosen method, what each feature would have written, and what was actually written. It's the most efficient form of "what is the adapter actually doing right now."

---

## Common situations

### "All my orders suddenly have the wrong shipping address"

Most likely: the address override for a particular method id has the wrong address in it, OR the customer chose a shipping method that DAA wasn't supposed to act on but the override table says it should.

1. Kill via Method 1 (untick master switch). Now the new orders are safe.
2. Look at the most recent affected order's `_daa_original_shipping_address` meta — that's the customer's actual entered address. Manually correct the order's shipping in the admin if needed.
3. Go to **Shipping Address Overrides** in settings, find the offending rule, fix the address, save.
4. Place one test order through incognito + test-mode coupon to confirm the trace shows the correct rewrite.
5. Re-enable master switch.

### "DCP is sending orders to the wrong fulfillment type"

Most likely: the fulfillment mapping doesn't match the actual shipping-method instance IDs (e.g. after a shipping-zone rebuild changed `flat_rate:36` to `flat_rate:41`).

1. Kill via Method 1.
2. Go to **WooCommerce → Settings → Shipping → Shipping zones**, hover each method, note the real instance IDs from the URL preview.
3. Update the **Fulfillment Mapping** textarea to match.
4. Test with the magic coupon.
5. Re-enable master.

### "WordPress admin is broken / white-screen of death"

Method 3 (folder rename via FTP). DAA is wrapped in try/catch on every customer-facing hook, so a white-screen is unlikely to be DAA's fault — but ruling it out fast is cheap.

### "Customers can't complete checkout"

Method 1 is safest. If the issue persists with master OFF, it isn't DAA — DAA is fully dormant in that state and cannot affect checkout. Investigate other plugins.

If the issue resolves with master OFF, it WAS DAA. Most likely cause: the date-picker validation rejected something it shouldn't have. Disable the date-picker toggle individually, re-enable master, see if checkout recovers — that confirms it. Then check the **Recent Activity** log for the warning that was being raised.

---

## Permanent removal

If the bakery decides to stop using DAA entirely:

1. Method 1 (turn off master) — observe for one day. If everything works fine, customers are still happy. Proceed.
2. Plugins → **Delete** (not just deactivate). This runs `uninstall.php` which drops the `wp_daa_logs` table and deletes the settings option. Order meta written by DAA stays on the orders (it's part of the order record), but no new writes happen.

If you also want to scrub the meta from completed orders (rarely necessary), your developer can run a one-off SQL DELETE on `wp_postmeta` (or the HPOS orders-meta table) for the `_daa_*` keys.

---

## When to contact your developer

Anything in the **error** log level. Anything that this runbook doesn't cover. Anything where you've used Method 1 to stop the bleeding and need to understand *why* before turning it back on.

When you reach out, send:

1. A screenshot of the **Dependency Status** panel from the DAA settings page.
2. The **Recent Activity** log, copied or screenshotted. The last 30 entries are usually enough.
3. The `_daa_decision_trace` meta from one affected order if you have it. (Even if test mode wasn't on at the time, the other `_daa_*` meta fields are still very useful.)
