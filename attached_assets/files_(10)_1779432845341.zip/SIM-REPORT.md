# Delicate API Adapter — Pre-Ship Simulation Report

This is the record of the end-to-end simulation that was run against DAA before shipping. It is not a manual — it's a record. Keep it on file so anyone touching the plugin later can see what was verified and how.

## Environment

| Component | Version | Notes |
|---|---|---|
| WordPress | 6.4.3 | The bakery runs 6.9.4; 6.4.3 is API-compatible for the surface DAA touches (hooks, options API, custom tables, settings API, HPOS declaration shim) |
| WooCommerce | stub | Minimal WC stand-in providing `WC_Order`, `WC_Order_Item_Shipping`, the `WC()` helper, and the `WooCommerce` marker class. Full WC was not available in the sim environment due to outbound network restrictions; the stub covers exactly the surface DAA + DCP read. |
| Delicate Courier Platform | 2.4.3 | Loaded unmodified from the zip the user provided |
| Delicate API Adapter | 0.1.0 | Loaded from the build directory |
| Database | MariaDB 10.11 | Real DB, not SQLite — exercises the real wpdb / dbDelta paths |
| PHP | 8.3.6 | All DAA code is PHP 7.4-compatible by design |

## Activation cycle verified

The full uninstall → reinstall-from-zip cycle was run to confirm `uninstall.php` and the activation hook both work as designed.

| Step | Expected | Observed |
|---|---|---|
| Activate | `wp_daa_logs` table created; `daa_settings` option seeded with defaults; first log entry "Plugin activated" | ✓ |
| Inspect settings | All 5 toggles default OFF; 4-row mapping table seeded; 2-row address overrides seeded | ✓ |
| Inspect dependency status | DCP detected as 2.4.3, compatible | ✓ |
| Uninstall via WP-CLI | Table dropped, option deleted | ✓ |
| Re-install from zip | Plugin folder recreated; activation runs cleanly; new "Plugin activated" entry in fresh log table | ✓ |

## Scenario matrix

Six scenarios were executed by firing `do_action('woocommerce_checkout_create_order', $order, [])` against synthetic `WC_Order` objects, then calling DCP's actual `dcp_build_order_payload($order)` to inspect what the courier platform would have received.

All six PASSED. Detailed observations:

### Scenario A: `local_pickup:35` — Collect from main bakery
- `_dcp_fulfillment_type` = **collect** (from mapping table)
- `_daa_fulfillment_source` = mapping (audit shadow)
- Address rewrite: **none** (no override seeded; customer's home address preserved)
- DCP payload: `fulfillment_type: collect`, customer's home address as shipping_address
- Order notes: none (no rewrite to announce)
- Log entries: date_picker saved date, fulfillment wrote type, address_rewrite passthrough (debug)

### Scenario B: `flat_rate:36` — Meyerspark satellite
- `_dcp_fulfillment_type` = **delivery**
- Address rewrite: **yes** — customer's 10 Camellia Avenue → 198 Watermeyer Street, Meyerspark, GP, 0184
- `_daa_address_rewritten` = 1, `_daa_address_rewrite_method` = flat_rate:36
- `_daa_original_shipping_address`: full JSON snapshot of customer's original address (202 bytes)
- Order note added: *"Delicate API Adapter rewrote the shipping address for fulfillment routing: 10 Camellia Avenue, Lynwood Glen, Pretoria, GP, 0081, ZA → 198 Watermeyer Street, Meyerspark, Pretoria, GP, 0184, ZA"*
- DCP payload street: "198 Watermeyer Street Meyerspark" — exactly what the platform will book the courier to

### Scenario C: `flat_rate:37` — Irene satellite
- Same shape as B but with Irene's address (1 Clifford Road, Irene, Centurion, GP, 0157)
- DCP payload street: "1 Clifford Road Irene"

### Scenario D: `distance_rate:40` — distance-based customer delivery
- `_dcp_fulfillment_type` = **delivery**
- Address rewrite: **none** (no override seeded for this method — correct: the customer's address IS the destination)
- DCP payload: customer's home preserved

### Scenario E: `delicate_courier_platform:99` — DCP's own shipping method
- **No `_dcp_fulfillment_type` written** (DAA is passive on DCP's own method)
- **No `_daa_fulfillment_source` written**
- **No address rewrite**
- DCP's own heuristic fires (since DAA stood down): `fulfillment_type: delivery` (correct — DCP's own method IS a delivery)

### Scenario F: `flat_rate:36` + test-mode coupon applied
- Everything from Scenario B happens normally (rewrite, fulfillment type, etc.)
- **Plus** `_daa_decision_trace` meta written (2307 bytes JSON)
- Trace includes:
  - Plugin + DCP version, dependency status
  - All 5 toggle states
  - `predictions.fulfillment` — what fulfillment WOULD have done (verdict, mapping snapshot, whether it would have written)
  - `predictions.address_rewrite` — what address-rewrite WOULD have done (parsed rule, current `shipping_now`)
  - `predictions.original_shipping_address` — decoded copy of the customer's original entered address, inline for readability
  - `actual_writes` — every `_daa_*` meta key actually present on the order
  - `submitted` — `$_POST['daa_delivery_date']` and applied coupon codes
  - `order` — summary (currency, total, item_count, date_create)
- Coupon match was **case-insensitive**: settings stored `DAA_TRACE_test`, coupon applied as `daa_trace_test`, match succeeded
- Test-mode order note added: *"Delicate API Adapter test mode: decision trace written to _daa_decision_trace meta."*

## Key cross-component verifications

These properties were checked against DCP's actual source, not just DAA's expectations:

1. **Hook ordering**: DAA hooks `woocommerce_checkout_create_order` at priority 10. DCP hooks `woocommerce_checkout_order_processed` at priority 20 (line 431 of DCP main file). These are different hooks, with WC firing them in that order during `WC_Checkout::create_order()`. No race.

2. **Meta key compatibility**: DCP's `dcp_extract_fulfillment_type()` reads `_dcp_fulfillment_type`, normalises to lowercase, accepts `collect`/`delivery`/`special_trip` (DCP source line 1421). DAA writes exactly those lowercase strings.

3. **Date key compatibility**: DCP's `dcp_extract_delivery_meta()` reads `_dtsc_delivery_date` natively (DCP source line 1467). DAA writes that key with the YYYY-MM-DD string flatpickr produces, which is what DCP forwards unmodified to the platform.

4. **Shipping address mutation persistence**: DCP reads shipping data via `$order->get_address('shipping')` (DCP source line 1297), which routes to the same WC setters DAA writes via `set_shipping_*()`. The address rewrite at priority 10 is therefore visible to DCP at priority 20 on the subsequent hook.

5. **HPOS compatibility**: DAA declares HPOS compatibility via `before_woocommerce_init` (same form DCP uses). All meta reads/writes use `$order->update_meta_data()` and `$order->get_meta()`, never `update_post_meta()`.

6. **Passive on DCP's own method**: DCP's shipping method declares `$this->id = 'delicate_courier_platform'`. DAA matches the chosen-method composite by prefix, so any instance of DCP's own shipping (`delicate_courier_platform:N` for any N) bypasses both DAA's fulfillment mapping and address rewriting.

## Trace shape (mid-sim refinements)

Two readability fixes were applied during the simulation in response to a real concern raised by inspecting the output:

1. **`address_rewrite.current_snapshot` → `shipping_now`**: the trace was capturing the shipping address as-it-is-at-this-moment, not as-it-was-when-the-customer-entered-it. Because test mode fires at priority 50 *after* address-rewrite at priority 10, this snapshot was already showing the satellite address. The field was renamed to `shipping_now` with a docstring clarifying the timing.

2. **`predictions.original_shipping_address` added**: a decoded copy of the customer's original entered address is now surfaced inline in the trace. Previously it was only visible as an escaped JSON-in-JSON string under `actual_writes._daa_original_shipping_address`.

Both fixes verified by re-running the matrix.

## Log table audit

After the full matrix ran, the `wp_daa_logs` table contained an entry for every decision made — 7 entries per order on average. The log levels were appropriate:

- `info` for any action taken (date saved, fulfillment type written, address rewritten, decision trace written)
- `info` for explicit passive cases ("Passive: DCP shipping method chosen, no override")
- `debug` for "nothing to do" cases ("No address override for chosen method; passthrough")
- No `warning` or `error` rows during the sim — all scenarios processed cleanly

## What was NOT simulated

These items are outside the sim's scope and should be verified on the bakery's actual WP install during the rollout:

1. **The customer-facing date picker UI**: flatpickr binds in the browser; the sim has no browser. The PHP enqueue logic, config injection, validation, and meta write were verified, but the visual rendering and the disabled-weekday / blackout behaviour can only be confirmed by loading the actual checkout page. The recommended test orders in INSTALL.md step 6 cover this.

2. **WC's actual `WC_Order` save semantics with HPOS enabled vs disabled**: the sim used a stubbed WC_Order. The bakery's site (WP 6.9.4, WC 10.7) defaults to HPOS for new installs but may have legacy data. DAA declares HPOS compatibility correctly; verify in a real test order that meta persists across both reads and refreshes.

3. **Interaction with WooCommerce Product Add-ons** (currently used by the bakery): the bakery's products have an "Amount" attribute and a free-text "Please indicate date, day and TIME" field. DAA does not touch those — they remain on the order as-is. The date picker writes to a separate meta key (`_dtsc_delivery_date`) which DCP reads with priority over any add-on field. This is by design — the bakery can keep their existing add-on for backwards reference or delete it later.

4. **AJAX / classic checkout differences**: WC 10.7 ships block-checkout as the default for new installs. The bakery's HTML shows classic checkout (the `[woocommerce_checkout]` shortcode path). DAA's hooks (`woocommerce_before_checkout_billing_form`, `woocommerce_checkout_process`, `woocommerce_checkout_create_order`) are classic-checkout hooks. Block checkout would need a different integration. The bakery's current configuration is classic — confirmed from the HTML upload — so this is fine for them. Worth flagging for any future migration.

## Conclusion

The simulation environment ran the complete activation, configuration, six-scenario test matrix, and uninstall-and-reinstall cycle against a real WP + MariaDB stack with the unmodified DCP plugin loaded as a sibling. Every test passed. The plugin is ready to ship to the bakery with the install guide and runbook.
