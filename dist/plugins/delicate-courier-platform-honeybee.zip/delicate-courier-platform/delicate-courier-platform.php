<?php
/**
 * Plugin Name: Delicate Courier Platform — HoneyBee Bakery
 * Plugin URI:  https://delicatecourier.co.za
 * Description: WooCommerce integration for the Delicate Courier Platform. Provides live Shiplogic rates at checkout and signed order push to the platform for automated shipment creation.
 * Version:     2.0.2
 * Author:      Delicate Courier
 * Author URI:  https://delicatecourier.co.za
 * License:     Proprietary
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * WC requires at least: 6.0
 * WC tested up to:   9.4
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/* ============================================================================
 * CONTRACT FREEZE — v2.0.0
 * ============================================================================
 * Any change to anything in this block requires a coordinated change on the
 * platform side. DO NOT modify without bumping the plugin major version.
 *
 *   Platform base URL : https://api2.delicatecourier.co.za
 *   Order push path   : POST /api/webhooks/plugin/order
 *   Order push body   : JSON, snake_case, exactly matches the C#
 *                       PluginWebhookPayload DTO in
 *                       DelicateCouriers.ApiService/Features/WooCommerce/
 *                       DTOs/PluginWebhookPayload.cs
 *   Order push headers:
 *     Content-Type:        application/json
 *     X-Store-ID:          numeric store ID from the platform store record
 *     X-Plugin-Signature:  base64( HMAC_SHA256( raw_json_body, webhook_secret ) )
 *     User-Agent:          DelicateCourierPlatform/<version> WordPress/<wp ver>
 *   Order push auth   : NO Authorization header. Auth is the signature.
 *   Order push retry  : transport errors and HTTP 5xx only (never 4xx),
 *                       bounded attempts with exponential backoff.
 *
 *   Shiplogic base URL: https://api.shiplogic.com
 *   Rates path        : POST /v2/rates
 *   Rates auth        : Authorization: Bearer <merchant Shiplogic token>
 *   Rates body fields : account_id, provider_id, service_level_code,
 *                       collection_address, delivery_address, parcels[]
 *   Rates response    : { "rates": [ { "rate": <number>,
 *                                     "service_level": { "code": "STD",
 *                                                        "name": "..." } }, ... ] }
 *
 *   Merchant-editable settings:
 *     Always:
 *       dcp_store_id, dcp_webhook_secret, dcp_shiplogic_bearer  (autoload=no)
 *       dcp_enable_live_rates, dcp_auto_sync_orders, dcp_debug_logging
 *     Default build only (hidden in branded builds where the values are
 *     pre-baked as DCP_DEFAULT_* constants):
 *       dcp_shiplogic_account_id, dcp_shiplogic_provider_id
 *
 *   All other configuration (service level, collection address, offset
 *   minutes, cache TTL, retry count) is sourced from DCP_DEFAULT_*
 *   constants (pre-baked in branded builds) or from apply_filters() hooks
 *   documented in README.md.
 * ========================================================================== */

/* ============================================================================
 * CONSTANTS
 * ========================================================================== */

define( 'DCP_VERSION',         '2.0.2' );
define( 'DCP_PLUGIN_FILE',     __FILE__ );
define( 'DCP_PLUGIN_DIR',      plugin_dir_path( __FILE__ ) );
define( 'DCP_PLUGIN_BASENAME', plugin_basename( __FILE__ ) );

// Platform API — default URL is the production custom domain. Merchants
// can override per-site via the "Platform Endpoint URL" field on the
// Settings page (option: dcp_platform_base_url) — useful for pointing at
// staging, or as a fallback while DNS for the custom domain propagates.
// Always read the active value through dcp_platform_base_url() below,
// not through the constant directly.
define( 'DCP_PLATFORM_BASE_URL',    'https://api2.delicatecourier.co.za' );
define( 'DCP_PLATFORM_ORDER_PATH',  '/api/webhooks/plugin/order' );
define( 'DCP_PLATFORM_HEALTH_PATH', '/api/webhooks/plugin/health' );

// Shiplogic API — used directly from the merchant's site for live rates.
define( 'DCP_SHIPLOGIC_BASE_URL',   'https://api.shiplogic.com' );
define( 'DCP_SHIPLOGIC_RATES_PATH', '/v2/rates' );

/* --- Pre-baked merchant defaults (injected by branded build) ---
 * These run before the dcp_define_if_unset() calls in the shared source
 * below, so they take precedence and the corresponding settings fields are
 * hidden from the merchant UI. */
define( 'DCP_DEFAULT_SHIPLOGIC_ACCOUNT_ID', 449679 );
define( 'DCP_DEFAULT_SHIPLOGIC_PROVIDER_ID', 35 );
define( 'DCP_DEFAULT_SERVICE_LEVEL_CODE', 'STD' );
define( 'DCP_DEFAULT_COLLECTION_COMPANY', 'HoneyBee Bakery' );
define( 'DCP_DEFAULT_COLLECTION_STREET', '5 Graham Road' );
define( 'DCP_DEFAULT_COLLECTION_SUBURB', 'Shere' );
define( 'DCP_DEFAULT_COLLECTION_CITY', 'Pretoria' );
define( 'DCP_DEFAULT_COLLECTION_PROVINCE', 'Gauteng' );
define( 'DCP_DEFAULT_COLLECTION_POSTAL_CODE', '0084' );
define( 'DCP_DEFAULT_COLLECTION_COUNTRY', 'ZA' );
define( 'DCP_DEFAULT_COLLECTION_LATITUDE', -25.7929 );
define( 'DCP_DEFAULT_COLLECTION_LONGITUDE', 28.361 );


// Shiplogic account / provider / service level.
//   - Branded builds pre-bake these via define() before this file is loaded,
//     so the merchant doesn't have to enter them.
//   - The default plugin ships with NO tenant data. The merchant enters their
//     own Shiplogic Account ID and Provider ID on the settings page. Service
//     level defaults to 'STD' (Shiplogic's generic Standard code) and can be
//     overridden via the dcp_service_level_code filter.
dcp_define_if_unset( 'DCP_DEFAULT_SHIPLOGIC_ACCOUNT_ID',  '' );
dcp_define_if_unset( 'DCP_DEFAULT_SHIPLOGIC_PROVIDER_ID', '' );
dcp_define_if_unset( 'DCP_DEFAULT_SERVICE_LEVEL_CODE',    'STD' );

// Optional pre-baked collection address. Branded variants override these via
// define() before this file is loaded — see header of each merchant-branded
// variant. The default plugin leaves them empty and falls back to the
// WooCommerce store address at runtime.
dcp_define_if_unset( 'DCP_DEFAULT_COLLECTION_COMPANY',     '' );
dcp_define_if_unset( 'DCP_DEFAULT_COLLECTION_STREET',      '' );
dcp_define_if_unset( 'DCP_DEFAULT_COLLECTION_SUBURB',      '' );
dcp_define_if_unset( 'DCP_DEFAULT_COLLECTION_CITY',        '' );
dcp_define_if_unset( 'DCP_DEFAULT_COLLECTION_PROVINCE',    '' );
dcp_define_if_unset( 'DCP_DEFAULT_COLLECTION_POSTAL_CODE', '' );
dcp_define_if_unset( 'DCP_DEFAULT_COLLECTION_COUNTRY',     'ZA' );
dcp_define_if_unset( 'DCP_DEFAULT_COLLECTION_LATITUDE',    '' );
dcp_define_if_unset( 'DCP_DEFAULT_COLLECTION_LONGITUDE',   '' );
dcp_define_if_unset( 'DCP_DEFAULT_COLLECTION_CONTACT_NAME',  '' );
dcp_define_if_unset( 'DCP_DEFAULT_COLLECTION_CONTACT_PHONE', '' );
dcp_define_if_unset( 'DCP_DEFAULT_COLLECTION_CONTACT_EMAIL', '' );

function dcp_define_if_unset( $name, $value ) {
    if ( ! defined( $name ) ) {
        define( $name, $value );
    }
}

/* ============================================================================
 * SETTINGS HELPERS
 * ========================================================================== */

function dcp_opt( $key, $default = '' ) {
    $val = get_option( 'dcp_' . $key, null );
    if ( $val === null || $val === '' ) {
        return $default;
    }
    return $val;
}

function dcp_store_id()              { return trim( (string) dcp_opt( 'store_id' ) ); }
function dcp_webhook_secret()        { return (string) dcp_opt( 'webhook_secret' ); }
function dcp_shiplogic_bearer()      { return trim( (string) dcp_opt( 'shiplogic_bearer' ) ); }

// Resolution order for these three values:
//   1. DCP_DEFAULT_* constant (pre-baked in a branded build) if non-empty.
//   2. wp_options value the merchant entered on the settings page.
//   3. Filter override (for developers using a mu-plugin / functions.php).
// Branded builds therefore hide the Account/Provider fields from the UI;
// the default build shows them.
function dcp_shiplogic_account_id() {
    $v = DCP_DEFAULT_SHIPLOGIC_ACCOUNT_ID !== '' ? (string) DCP_DEFAULT_SHIPLOGIC_ACCOUNT_ID : trim( (string) dcp_opt( 'shiplogic_account_id' ) );
    return (string) apply_filters( 'dcp_shiplogic_account_id', $v );
}
function dcp_shiplogic_provider_id() {
    $v = DCP_DEFAULT_SHIPLOGIC_PROVIDER_ID !== '' ? (string) DCP_DEFAULT_SHIPLOGIC_PROVIDER_ID : trim( (string) dcp_opt( 'shiplogic_provider_id' ) );
    return (string) apply_filters( 'dcp_shiplogic_provider_id', $v );
}
function dcp_service_level_code() { return (string) apply_filters( 'dcp_service_level_code', DCP_DEFAULT_SERVICE_LEVEL_CODE ); }

/**
 * True when the build has NOT pre-baked the Shiplogic account/provider — i.e.
 * the default plugin. Used by the settings page to decide whether to render
 * those two input fields.
 */
function dcp_shiplogic_ids_are_editable() {
    return DCP_DEFAULT_SHIPLOGIC_ACCOUNT_ID === '' && DCP_DEFAULT_SHIPLOGIC_PROVIDER_ID === '';
}

function dcp_live_rates_enabled()    { return dcp_opt( 'enable_live_rates', 'yes' ) === 'yes'; }
function dcp_auto_sync_enabled()     { return dcp_opt( 'auto_sync_orders', 'yes' ) === 'yes'; }
function dcp_debug_enabled()         { return dcp_opt( 'debug_logging', 'no' ) === 'yes'; }

/**
 * Collection address. Pre-baked constants from a branded build win; if not
 * present, fall back to the WooCommerce store address; can be fully
 * overridden via the `dcp_collection_address` filter.
 */
function dcp_collection_address() {
    $wc_country_state = function_exists( 'wc_get_base_location' ) ? wc_get_base_location() : array( 'country' => 'ZA', 'state' => '' );

    $addr = array(
        'type'           => 'business',
        'company'        => DCP_DEFAULT_COLLECTION_COMPANY ?: get_bloginfo( 'name' ),
        'street_address' => DCP_DEFAULT_COLLECTION_STREET  ?: trim( (string) get_option( 'woocommerce_store_address', '' ) . ' ' . (string) get_option( 'woocommerce_store_address_2', '' ) ),
        'local_area'     => DCP_DEFAULT_COLLECTION_SUBURB,
        'city'           => DCP_DEFAULT_COLLECTION_CITY    ?: (string) get_option( 'woocommerce_store_city', '' ),
        'zone'           => DCP_DEFAULT_COLLECTION_PROVINCE ?: ( $wc_country_state['state'] ?? '' ),
        'code'           => DCP_DEFAULT_COLLECTION_POSTAL_CODE ?: (string) get_option( 'woocommerce_store_postcode', '' ),
        'country'        => DCP_DEFAULT_COLLECTION_COUNTRY ?: ( $wc_country_state['country'] ?? 'ZA' ),
        'lat'            => DCP_DEFAULT_COLLECTION_LATITUDE  !== '' ? floatval( DCP_DEFAULT_COLLECTION_LATITUDE )  : null,
        'lng'            => DCP_DEFAULT_COLLECTION_LONGITUDE !== '' ? floatval( DCP_DEFAULT_COLLECTION_LONGITUDE ) : null,
        'contact'        => array(
            'name'          => DCP_DEFAULT_COLLECTION_CONTACT_NAME  ?: get_bloginfo( 'name' ),
            'mobile_number' => DCP_DEFAULT_COLLECTION_CONTACT_PHONE,
            'email'         => DCP_DEFAULT_COLLECTION_CONTACT_EMAIL ?: get_bloginfo( 'admin_email' ),
        ),
    );
    return apply_filters( 'dcp_collection_address', $addr );
}

function dcp_collection_offset_minutes() {
    return intval( apply_filters( 'dcp_collection_offset_minutes', 90 ) );
}

function dcp_is_configured() {
    return dcp_store_id() !== '' && dcp_webhook_secret() !== '';
}

/**
 * Secret options must NOT be autoloaded — they're only read when a request
 * actually needs them (rate quote, order push, admin settings page). Saving
 * the same value back via update_option() preserves the existing autoload
 * flag, so we make sure the row exists with autoload=no before any save.
 */
function dcp_ensure_secret_autoload_off( $option_name ) {
    global $wpdb;
    $exists = $wpdb->get_var( $wpdb->prepare( "SELECT option_id FROM {$wpdb->options} WHERE option_name = %s", $option_name ) );
    if ( ! $exists ) {
        add_option( $option_name, '', '', 'no' );
        return;
    }
    // Force autoload=no in case a prior version created it with autoload=yes.
    $wpdb->update( $wpdb->options, array( 'autoload' => 'no' ), array( 'option_name' => $option_name ) );
    wp_cache_delete( 'alloptions', 'options' );
}

function dcp_save_secret_option( $option_name, $value ) {
    dcp_ensure_secret_autoload_off( $option_name );
    update_option( $option_name, $value );
}

/* ============================================================================
 * DEBUG LOG (in-DB ring buffer; capped at 200 entries)
 * ========================================================================== */

function dcp_log( $context, $detail = '', $level = 'info' ) {
    if ( ! dcp_debug_enabled() ) {
        return;
    }
    $logs = get_option( 'dcp_debug_logs', array() );
    if ( ! is_array( $logs ) ) {
        $logs = array();
    }
    $logs[] = array(
        'time'    => current_time( 'mysql' ),
        'level'   => $level,
        'context' => (string) $context,
        'detail'  => is_string( $detail ) ? $detail : wp_json_encode( $detail ),
    );
    if ( count( $logs ) > 200 ) {
        $logs = array_slice( $logs, -200 );
    }
    update_option( 'dcp_debug_logs', $logs, false );
}

/* ============================================================================
 * ACTIVATION / DEACTIVATION
 * ========================================================================== */

register_activation_hook( DCP_PLUGIN_FILE, 'dcp_on_activate' );
function dcp_on_activate() {
    // Drop legacy options from prior plugin generations so a stale API key
    // can't accidentally be sent against the new platform.
    $legacy = array(
        'dcp_api_key',                 // legacy bearer auth — replaced by HMAC
        'dcp_platform_api_key',        // older alias
        'dcp_shiplogic_api_key',       // legacy Shiplogic option name
        'dcp_api_base_url',            // URL is hard-coded now
        'dcp_shiplogic_account_id',    // moved to constant / filter
        'dcp_shiplogic_provider_id',   // moved to constant / filter
        'dcp_service_level_code',      // moved to constant / filter
        'dcp_collection_company', 'dcp_collection_street', 'dcp_collection_suburb',
        'dcp_collection_city', 'dcp_collection_province', 'dcp_collection_postal_code',
        'dcp_collection_country', 'dcp_collection_latitude', 'dcp_collection_longitude',
        'dcp_collection_contact_name', 'dcp_collection_contact_phone', 'dcp_collection_contact_email',
        'dcp_collection_offset_minutes',
    );
    foreach ( $legacy as $opt ) {
        delete_option( $opt );
    }

    // Toggle settings can autoload — they're read on every request.
    add_option( 'dcp_enable_live_rates', 'yes' );
    add_option( 'dcp_auto_sync_orders',  'yes' );
    add_option( 'dcp_debug_logging',     'no' );

    // Secrets must NOT autoload.
    foreach ( array( 'dcp_store_id', 'dcp_webhook_secret', 'dcp_shiplogic_bearer' ) as $secret ) {
        dcp_ensure_secret_autoload_off( $secret );
    }
}

/* ============================================================================
 * WOOCOMMERCE BOOTSTRAP
 * ========================================================================== */

// Declare HPOS (Custom Order Tables) compatibility.
add_action( 'before_woocommerce_init', function() {
    if ( class_exists( '\Automattic\WooCommerce\Utilities\FeaturesUtil' ) ) {
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility(
            'custom_order_tables', DCP_PLUGIN_FILE, true
        );
    }
} );

add_action( 'plugins_loaded', 'dcp_bootstrap', 20 );
function dcp_bootstrap() {
    if ( ! class_exists( 'WooCommerce' ) ) {
        add_action( 'admin_notices', function() {
            echo '<div class="notice notice-error"><p><strong>Delicate Courier Platform:</strong> WooCommerce must be installed and active.</p></div>';
        } );
        return;
    }

    // Shipping method (live rates from Shiplogic).
    add_action( 'woocommerce_shipping_init', 'dcp_load_shipping_method' );
    add_filter( 'woocommerce_shipping_methods', 'dcp_register_shipping_method' );

    // Order sync (push to platform).
    add_action( 'woocommerce_order_status_processing',         'dcp_sync_order' );
    add_action( 'woocommerce_order_status_completed',          'dcp_sync_order' );
    add_action( 'woocommerce_order_status_on-hold',            'dcp_sync_order' );
    add_action( 'woocommerce_payment_complete',                'dcp_sync_order' );
    add_action( 'woocommerce_checkout_order_processed',        'dcp_sync_order', 20 );

    // Admin UI.
    add_action( 'admin_menu',                                  'dcp_admin_menu' );
    add_filter( 'plugin_action_links_' . DCP_PLUGIN_BASENAME,  'dcp_action_links' );
    add_action( 'admin_init',                                  'dcp_register_settings' );
    add_action( 'add_meta_boxes',                              'dcp_register_order_meta_box' );

    // AJAX test handlers.
    add_action( 'wp_ajax_dcp_test_platform_health', 'dcp_ajax_test_platform_health' );
    add_action( 'wp_ajax_dcp_test_platform_order',  'dcp_ajax_test_platform_order' );
    add_action( 'wp_ajax_dcp_test_shiplogic_rates', 'dcp_ajax_test_shiplogic_rates' );
    add_action( 'wp_ajax_dcp_clear_debug_logs',     'dcp_ajax_clear_debug_logs' );
}

/* ============================================================================
 * SHIPPING METHOD — live Shiplogic rates
 * ========================================================================== */

function dcp_load_shipping_method() {
    if ( class_exists( 'WC_Shipping_Method' ) && ! class_exists( 'DCP_Shipping_Method' ) ) {

        class DCP_Shipping_Method extends WC_Shipping_Method {

            public function __construct( $instance_id = 0 ) {
                $this->id                 = 'delicate_courier_platform';
                $this->instance_id        = absint( $instance_id );
                $this->method_title       = __( 'Delicate Courier Platform', 'dcp' );
                $this->method_description = __( 'Live courier rates from Shiplogic via the Delicate Courier Platform.', 'dcp' );
                $this->supports           = array( 'shipping-zones', 'instance-settings', 'instance-settings-modal' );

                $this->init_form_fields();
                $this->init_settings();

                $this->title          = $this->get_option( 'title', 'Courier Delivery' );
                $this->tax_status     = $this->get_option( 'tax_status', 'taxable' );
                $this->markup_type    = $this->get_option( 'markup_type', 'none' );
                $this->markup_value   = floatval( $this->get_option( 'markup_value', 0 ) );

                $this->enabled = isset( $this->settings['enabled'] ) ? $this->settings['enabled'] : 'yes';

                add_action( 'woocommerce_update_options_shipping_' . $this->id, array( $this, 'process_admin_options' ) );
            }

            public function init_form_fields() {
                $this->instance_form_fields = array(
                    'title' => array(
                        'title'       => __( 'Method title', 'dcp' ),
                        'type'        => 'text',
                        'description' => __( 'Label shown to customers at checkout.', 'dcp' ),
                        'default'     => 'Courier Delivery',
                        'desc_tip'    => true,
                    ),
                    'tax_status' => array(
                        'title'   => __( 'Tax status', 'dcp' ),
                        'type'    => 'select',
                        'default' => 'taxable',
                        'options' => array(
                            'taxable' => __( 'Taxable', 'dcp' ),
                            'none'    => __( 'None', 'dcp' ),
                        ),
                    ),
                    'markup_type' => array(
                        'title'   => __( 'Rate markup', 'dcp' ),
                        'type'    => 'select',
                        'default' => 'none',
                        'options' => array(
                            'none'       => __( 'No markup', 'dcp' ),
                            'fixed'      => __( 'Fixed amount (R)', 'dcp' ),
                            'percentage' => __( 'Percentage (%)', 'dcp' ),
                        ),
                    ),
                    'markup_value' => array(
                        'title'             => __( 'Markup value', 'dcp' ),
                        'type'              => 'number',
                        'default'           => 0,
                        'custom_attributes' => array( 'step' => '0.01', 'min' => '0' ),
                    ),
                );
            }

            public function calculate_shipping( $package = array() ) {
                if ( ! dcp_live_rates_enabled() ) {
                    dcp_log( 'rates.skip', 'Live rates disabled in settings' );
                    return;
                }
                $bearer = dcp_shiplogic_bearer();
                if ( $bearer === '' ) {
                    dcp_log( 'rates.skip', 'No Shiplogic bearer token configured', 'error' );
                    return;
                }
                $account  = dcp_shiplogic_account_id();
                $provider = dcp_shiplogic_provider_id();
                if ( $account === '' || $provider === '' ) {
                    dcp_log( 'rates.skip', 'Missing Shiplogic account_id or provider_id', 'error' );
                    return;
                }

                $delivery = $this->build_delivery_address( $package );
                if ( ! $delivery ) {
                    dcp_log( 'rates.skip', 'Delivery address incomplete', 'warning' );
                    return;
                }

                $weight = $this->calculate_total_weight( $package );

                $payload = array(
                    'account_id'         => is_numeric( $account ) ? intval( $account ) : $account,
                    'provider_id'        => is_numeric( $provider ) ? intval( $provider ) : $provider,
                    'service_level_code' => dcp_service_level_code(),
                    'collection_address' => dcp_collection_address(),
                    'delivery_address'   => $delivery,
                    'parcels'            => array(
                        array(
                            'parcel_description'  => 'Package',
                            'submitted_length_cm' => 20,
                            'submitted_width_cm'  => 15,
                            'submitted_height_cm' => 10,
                            'submitted_weight_kg' => $weight,
                        ),
                    ),
                );

                // Transient cache to keep checkout snappy. Key = bearer (so a
                // token change invalidates) + service code + destination +
                // WooCommerce cart hash (falls back to a hash of the package
                // contents when the cart singleton isn't available, e.g. on
                // pure shipping-zone evaluation).
                $cart_hash = '';
                if ( function_exists( 'WC' ) && WC()->cart instanceof WC_Cart ) {
                    $cart_hash = WC()->cart->get_cart_hash();
                }
                if ( $cart_hash === '' ) {
                    $cart_hash = md5( wp_json_encode( $package['contents'] ?? array() ) );
                }
                $cache_key = 'dcp_rate_' . md5( $bearer . '|' . dcp_service_level_code() . '|' . wp_json_encode( $delivery ) . '|' . $cart_hash );
                $rates     = get_transient( $cache_key );
                if ( false === $rates ) {
                    $rates = dcp_shiplogic_fetch_rates( $bearer, $payload );
                    if ( ! is_wp_error( $rates ) ) {
                        // Short TTL — destination + cart hash collisions are
                        // extremely rare, but rate cards do change.
                        set_transient( $cache_key, $rates, intval( apply_filters( 'dcp_rate_cache_ttl_seconds', 300 ) ) );
                    }
                } else {
                    dcp_log( 'rates.cache_hit', 'Served from transient cache' );
                }
                if ( is_wp_error( $rates ) ) {
                    dcp_log( 'rates.error', $rates->get_error_message(), 'error' );
                    return;
                }
                if ( empty( $rates ) ) {
                    dcp_log( 'rates.empty', 'Shiplogic returned no rates' );
                    return;
                }

                $wanted = dcp_service_level_code();
                $added  = 0;
                foreach ( $rates as $rate ) {
                    $code = $rate['service_level']['code'] ?? '';
                    $name = $rate['service_level']['name'] ?? $code;
                    if ( $code === '' || ! isset( $rate['rate'] ) ) {
                        continue;
                    }
                    if ( $wanted !== '' && $code !== $wanted ) {
                        continue;
                    }

                    $cost = floatval( $rate['rate'] );
                    if ( $this->markup_type === 'fixed' ) {
                        $cost += $this->markup_value;
                    } elseif ( $this->markup_type === 'percentage' ) {
                        $cost += ( $cost * $this->markup_value / 100 );
                    }

                    $this->add_rate( array(
                        'id'        => $this->id . '_' . strtolower( $code ),
                        'label'     => esc_html( $name ),
                        'cost'      => $cost,
                        'meta_data' => array(
                            'service_level_code' => $code,
                        ),
                    ) );
                    $added++;
                    dcp_log( 'rates.added', $name . ' R' . number_format( $cost, 2 ) );
                }

                if ( $added === 0 ) {
                    dcp_log( 'rates.filtered', 'No rates matched service code ' . $wanted );
                }
            }

            private function build_delivery_address( $package ) {
                $dest = isset( $package['destination'] ) ? $package['destination'] : array();
                $street = trim( ( $dest['address']   ?? '' ) . ' ' . ( $dest['address_2'] ?? '' ) );
                $city   = $dest['city']     ?? '';
                $code   = $dest['postcode'] ?? '';
                $state  = $dest['state']    ?? '';

                if ( $street === '' || $city === '' || $code === '' ) {
                    return false;
                }

                return array(
                    'type'           => 'residential',
                    'company'        => null,
                    'street_address' => $street,
                    'local_area'     => '',
                    'city'           => $city,
                    'zone'           => dcp_normalize_province( $state ),
                    'code'           => $code,
                    'country'        => $dest['country'] ?? 'ZA',
                    'lat'            => null,
                    'lng'            => null,
                    'contact'        => array(
                        'name'          => '',
                        'mobile_number' => null,
                        'email'         => null,
                    ),
                );
            }

            private function calculate_total_weight( $package ) {
                $weight = 0;
                if ( ! empty( $package['contents'] ) ) {
                    foreach ( $package['contents'] as $item ) {
                        $product = $item['data'];
                        $qty     = $item['quantity'];
                        $w       = floatval( $product->get_weight() );
                        if ( $w <= 0 ) { $w = 1; }
                        $weight += $w * $qty;
                    }
                }
                return max( 1, $weight );
            }
        }
    }
}

function dcp_register_shipping_method( $methods ) {
    $methods['delicate_courier_platform'] = 'DCP_Shipping_Method';
    return $methods;
}

function dcp_normalize_province( $state ) {
    $map = array(
        'EC'  => 'Eastern Cape',
        'FS'  => 'Free State',
        'GP'  => 'Gauteng',
        'KZN' => 'KwaZulu-Natal',
        'LP'  => 'Limpopo',
        'MP'  => 'Mpumalanga',
        'NW'  => 'North West',
        'NC'  => 'Northern Cape',
        'WC'  => 'Western Cape',
    );
    if ( $state === '' ) {
        return '';
    }
    $upper = strtoupper( trim( $state ) );
    if ( isset( $map[ $upper ] ) ) {
        return $map[ $upper ];
    }
    return $state;
}

/* ============================================================================
 * SHIPLOGIC HTTP CLIENT
 * ========================================================================== */

function dcp_shiplogic_fetch_rates( $bearer, $payload ) {
    $url = DCP_SHIPLOGIC_BASE_URL . DCP_SHIPLOGIC_RATES_PATH;
    $response = wp_remote_post( $url, array(
        'timeout' => 30,
        'headers' => array(
            'Content-Type'  => 'application/json',
            'Accept'        => 'application/json',
            'Authorization' => 'Bearer ' . $bearer,
        ),
        'body' => wp_json_encode( $payload ),
    ) );

    if ( is_wp_error( $response ) ) {
        return $response;
    }
    $code = wp_remote_retrieve_response_code( $response );
    $body = wp_remote_retrieve_body( $response );

    if ( $code < 200 || $code >= 300 ) {
        return new WP_Error( 'shiplogic_http_' . $code, 'Shiplogic returned HTTP ' . $code . ': ' . substr( $body, 0, 500 ) );
    }
    $data = json_decode( $body, true );
    if ( ! is_array( $data ) || empty( $data['rates'] ) || ! is_array( $data['rates'] ) ) {
        return array();
    }
    return $data['rates'];
}

/* ============================================================================
 * PLATFORM HTTP CLIENT (signed)
 * ========================================================================== */

/**
 * POST a JSON body to the platform with HMAC-SHA256(rawBody, webhook_secret)
 * encoded as base64 in X-Plugin-Signature, and the Store ID in X-Store-ID.
 *
 * @return array { success: bool, status: int, body: array|string, raw: string }
 */
function dcp_platform_post_signed( $path, $payload ) {
    $store_id = dcp_store_id();
    $secret   = dcp_webhook_secret();

    if ( $store_id === '' || $secret === '' ) {
        return array(
            'success' => false,
            'status'  => 0,
            'body'    => array( 'message' => 'Plugin not configured: Store ID and Webhook Secret are required.' ),
            'raw'     => '',
        );
    }

    $body = wp_json_encode( $payload );
    $sig  = base64_encode( hash_hmac( 'sha256', $body, $secret, true ) );
    $url  = rtrim( dcp_platform_base_url(), '/' ) . $path;
    $args = array(
        'timeout' => 30,
        'headers' => array(
            'Content-Type'      => 'application/json',
            'Accept'            => 'application/json',
            'X-Store-ID'        => $store_id,
            'X-Plugin-Signature'=> $sig,
            'User-Agent'        => 'DelicateCourierPlatform/' . DCP_VERSION . ' WordPress/' . get_bloginfo( 'version' ),
        ),
        'body' => $body,
    );

    // Bounded retry with exponential backoff. Retry only on transport errors
    // and 5xx responses — never on 4xx (those mean our request is bad and a
    // retry will fail identically).
    $max_attempts = intval( apply_filters( 'dcp_platform_post_max_attempts', 3 ) );
    $last_error   = '';
    $last_status  = 0;
    $last_raw     = '';

    for ( $attempt = 1; $attempt <= $max_attempts; $attempt++ ) {
        $response = wp_remote_post( $url, $args );

        if ( is_wp_error( $response ) ) {
            $last_error  = $response->get_error_message();
            $last_status = 0;
            $last_raw    = '';
            dcp_log( 'platform.retry', 'Attempt ' . $attempt . '/' . $max_attempts . ' transport error: ' . $last_error, 'warning' );
        } else {
            $status = wp_remote_retrieve_response_code( $response );
            $raw    = wp_remote_retrieve_body( $response );
            $parsed = json_decode( $raw, true );

            // Success or non-retryable failure — return immediately.
            if ( $status < 500 ) {
                return array(
                    'success' => ( $status >= 200 && $status < 300 ),
                    'status'  => $status,
                    'body'    => is_array( $parsed ) ? $parsed : $raw,
                    'raw'     => $raw,
                );
            }
            $last_error  = 'HTTP ' . $status;
            $last_status = $status;
            $last_raw    = $raw;
            dcp_log( 'platform.retry', 'Attempt ' . $attempt . '/' . $max_attempts . ' got ' . $last_error, 'warning' );
        }

        if ( $attempt < $max_attempts ) {
            // 1s, 2s, 4s... — small enough not to hang admin UX.
            sleep( min( 4, pow( 2, $attempt - 1 ) ) );
        }
    }

    return array(
        'success' => false,
        'status'  => $last_status,
        'body'    => array( 'message' => 'Platform push failed after ' . $max_attempts . ' attempts: ' . $last_error ),
        'raw'     => $last_raw,
    );
}

/**
 * Best-effort wipe of cached Shiplogic rate transients. Called when the
 * settings page saves so a new token / endpoint takes effect immediately.
 */
function dcp_clear_rate_cache() {
    global $wpdb;
    $wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_dcp_rate_%' OR option_name LIKE '_transient_timeout_dcp_rate_%'" );
}

function dcp_platform_get( $path ) {
    $response = wp_remote_get( rtrim( dcp_platform_base_url(), '/' ) . $path, array(
        'timeout' => 15,
        'headers' => array( 'Accept' => 'application/json' ),
    ) );
    if ( is_wp_error( $response ) ) {
        return array( 'success' => false, 'status' => 0, 'body' => array( 'message' => $response->get_error_message() ) );
    }
    $status = wp_remote_retrieve_response_code( $response );
    $raw    = wp_remote_retrieve_body( $response );
    $parsed = json_decode( $raw, true );
    return array(
        'success' => ( $status >= 200 && $status < 300 ),
        'status'  => $status,
        'body'    => is_array( $parsed ) ? $parsed : $raw,
    );
}

/* ============================================================================
 * ORDER SYNC — push to platform
 * ========================================================================== */

function dcp_sync_order( $order_id ) {
    $order = wc_get_order( $order_id );
    if ( ! $order ) {
        return;
    }
    if ( ! dcp_auto_sync_enabled() ) {
        return;
    }
    if ( $order->get_meta( '_dcp_platform_order_id' ) ) {
        dcp_log( 'order.skip', 'Order ' . $order_id . ' already synced' );
        return;
    }
    if ( ! dcp_is_configured() ) {
        $order->add_order_note( 'Delicate Courier: order not synced — plugin missing Store ID or Webhook Secret.' );
        return;
    }

    $payload = dcp_build_order_payload( $order );
    $resp    = dcp_platform_post_signed( DCP_PLATFORM_ORDER_PATH, $payload );

    if ( $resp['success'] ) {
        $platform_id = is_array( $resp['body'] ) ? ( $resp['body']['orderId'] ?? '' ) : '';
        $order_num   = is_array( $resp['body'] ) ? ( $resp['body']['orderNumber'] ?? '' ) : '';
        $order->update_meta_data( '_dcp_platform_order_id', $platform_id );
        $order->update_meta_data( '_dcp_synced_at', current_time( 'mysql' ) );
        $order->save();
        $order->add_order_note( sprintf( 'Delicate Courier: order synced to platform (ID %s).', $platform_id ) );
        dcp_log( 'order.synced', 'Order ' . $order_id . ' -> platform ' . $platform_id );
    } else {
        $msg = is_array( $resp['body'] ) ? ( $resp['body']['message'] ?? 'Unknown error' ) : (string) $resp['body'];
        $order->add_order_note( 'Delicate Courier: sync failed (HTTP ' . $resp['status'] . ') — ' . $msg );
        dcp_log( 'order.failed', 'Order ' . $order_id . ' status=' . $resp['status'] . ' msg=' . $msg, 'error' );
    }
}

function dcp_build_order_payload( $order ) {
    $shipping = $order->get_address( 'shipping' );
    $billing  = $order->get_address( 'billing' );

    $street = trim( ( $shipping['address_1'] ?? '' ) . ' ' . ( $shipping['address_2'] ?? '' ) );
    if ( $street === '' ) {
        $street = trim( ( $billing['address_1'] ?? '' ) . ' ' . ( $billing['address_2'] ?? '' ) );
    }
    // ZA convention: WooCommerce has no native suburb field, merchants put
    // it in address_2. We still concatenate address_2 into $street above for
    // backward compatibility (older platform builds expect it there), and
    // ALSO send it as a dedicated `suburb` so Shiplogic can populate
    // `local_area` accurately.
    $suburb = trim( (string) ( $shipping['address_2'] ?? '' ) );
    if ( $suburb === '' ) {
        $suburb = trim( (string) ( $billing['address_2'] ?? '' ) );
    }
    $city     = $shipping['city']     ?: ( $billing['city']     ?? '' );
    $postcode = $shipping['postcode'] ?: ( $billing['postcode'] ?? '' );
    $state    = $shipping['state']    ?: ( $billing['state']    ?? '' );
    $country  = $shipping['country']  ?: ( $billing['country']  ?? 'ZA' );

    $name = trim( ( $shipping['first_name'] ?? '' ) . ' ' . ( $shipping['last_name'] ?? '' ) );
    if ( $name === '' ) {
        $name = trim( ( $billing['first_name'] ?? '' ) . ' ' . ( $billing['last_name'] ?? '' ) );
    }
    $phone = $shipping['phone'] ?? ( $billing['phone'] ?? '' );
    $email = $order->get_billing_email();

    $line_items   = array();
    $total_weight = 0;
    foreach ( $order->get_items() as $item ) {
        /** @var WC_Order_Item_Product $item */
        $product = $item->get_product();
        $weight  = $product ? floatval( $product->get_weight() ) : 1;
        if ( $weight <= 0 ) { $weight = 1; }
        $qty = $item->get_quantity();

        $line_items[] = array(
            'id'         => $item->get_id(),
            'product_id' => $item->get_product_id(),
            'name'       => $item->get_name(),
            'quantity'   => $qty,
            'price'      => floatval( $item->get_total() ),
            'sku'        => $product ? (string) $product->get_sku() : '',
        );
        $total_weight += $weight * $qty;
    }

    // Optional delivery/collection date+time and occasion: support the most
    // common merchant plugins. All optional — payload accepts nulls.
    list( $delivery_date, $delivery_time, $occasion ) = dcp_extract_delivery_meta( $order );

    $collection_date = $delivery_date;
    $collection_time = null;
    if ( ! empty( $delivery_time ) ) {
        $offset = dcp_collection_offset_minutes();
        $collection_time = dcp_apply_minutes_offset( $delivery_time, -$offset );
    }

    return array(
        'event'           => 'order.created',
        'woo_order_id'    => $order->get_id(),
        'order_number'    => (string) $order->get_order_number(),
        'status'          => $order->get_status(),
        'total'           => floatval( $order->get_total() ),
        'shipping_total'  => floatval( $order->get_shipping_total() ),
        'currency'        => $order->get_currency(),
        'payment_method'  => $order->get_payment_method_title(),
        'date_created'    => $order->get_date_created() ? $order->get_date_created()->format( 'Y-m-d H:i:s' ) : '',
        'customer_note'   => $order->get_customer_note(),
        'customer'        => array(
            'name'  => $name,
            'email' => $email,
            'phone' => $phone,
        ),
        'shipping_address' => array(
            'street'   => $street,
            'suburb'   => $suburb,
            'city'     => $city,
            'state'    => $state,
            'postcode' => $postcode,
            'country'  => $country ?: 'ZA',
        ),
        'line_items'      => $line_items,
        'total_weight'    => max( 1, $total_weight ),
        'store_url'       => home_url(),
        'store_id'        => dcp_store_id(),
        'delivery_date'   => $delivery_date,
        'delivery_time'   => $delivery_time,
        'collection_date' => $collection_date,
        'collection_time' => $collection_time,
        'occasion'        => $occasion,
    );
}

/**
 * Best-effort extraction of delivery date/time/occasion from common merchant
 * checkout plugins. Returns [ date YYYY-MM-DD or null, time HH:MM or null,
 * occasion string or null ].
 */
function dcp_extract_delivery_meta( $order ) {
    $date = null; $time = null; $occasion = null;

    // Delicate Two-Step Checkout (DTSC) — authoritative when present.
    $dtsc_date = $order->get_meta( '_dtsc_delivery_date' );
    $dtsc_time = $order->get_meta( '_dtsc_delivery_time' );
    if ( $dtsc_date ) { $date = $dtsc_date; }
    if ( $dtsc_time ) { $time = $dtsc_time; }

    // Fall back to WP Time Slots Booking and WAPF per line item.
    if ( ! $date || ! $time || ! $occasion ) {
        foreach ( $order->get_items() as $item ) {
            // WP Time Slots Booking
            $ts = $item->get_meta( 'woocommerce_wptimeslots_order_details', true );
            if ( is_array( $ts ) && isset( $ts['cff_params']['apps'][0] ) ) {
                if ( ! $date && ! empty( $ts['cff_params']['apps'][0]['date'] ) ) {
                    $date = $ts['cff_params']['apps'][0]['date'];
                }
                if ( ! $time && ! empty( $ts['cff_params']['apps'][0]['slot'] ) ) {
                    $time = $ts['cff_params']['apps'][0]['slot'];
                }
            }
            // WAPF (Advanced Product Fields)
            $wapf = $item->get_meta( '_wapf_meta', true );
            if ( is_array( $wapf ) && ! empty( $wapf['fields'] ) ) {
                foreach ( $wapf['fields'] as $f ) {
                    $label = strtolower( $f['label'] ?? '' );
                    $value = $f['value'] ?? '';
                    if ( ! $occasion && strpos( $label, 'occasion' ) !== false ) {
                        $occasion = $value;
                    }
                    if ( ! $date && ( strpos( $label, 'function date' ) !== false || strpos( $label, 'delivery date' ) !== false ) ) {
                        if ( preg_match( '/(\d{1,2})[\/\-](\d{1,2})(?:[\/\-](\d{2,4}))?/', (string) $value, $m ) ) {
                            $year = ! empty( $m[3] ) ? $m[3] : date( 'Y' );
                            if ( strlen( $year ) === 2 ) { $year = '20' . $year; }
                            $date = sprintf( '%04d-%02d-%02d', $year, $m[2], $m[1] );
                        }
                    }
                }
            }
            // Direct meta keys
            if ( ! $occasion ) {
                $direct = $item->get_meta( 'Occasion', true );
                if ( $direct ) { $occasion = $direct; }
            }
        }
    }

    return array( $date, $time, $occasion );
}

function dcp_apply_minutes_offset( $hhmm, $offset_minutes ) {
    if ( ! preg_match( '/^(\d{1,2}):(\d{2})/', $hhmm, $m ) ) {
        return $hhmm;
    }
    $total = intval( $m[1] ) * 60 + intval( $m[2] ) + intval( $offset_minutes );
    $total = max( 0, min( 24 * 60 - 1, $total ) );
    return sprintf( '%02d:%02d', intdiv( $total, 60 ), $total % 60 );
}

/* ============================================================================
 * ADMIN — settings page, action links, meta box
 * ========================================================================== */

function dcp_action_links( $links ) {
    array_unshift( $links, '<a href="' . esc_url( admin_url( 'admin.php?page=dcp-settings' ) ) . '">' . esc_html__( 'Settings', 'dcp' ) . '</a>' );
    return $links;
}

function dcp_admin_menu() {
    add_menu_page(
        __( 'Delicate Courier', 'dcp' ),
        __( 'Delicate Courier', 'dcp' ),
        'manage_woocommerce',
        'dcp-settings',
        'dcp_render_settings_page',
        'dashicons-airplane',
        56
    );
}

/**
 * Returns the platform base URL the plugin should POST orders / fetch
 * rates against. Prefers the per-site override saved via the admin
 * Settings page (option: dcp_platform_base_url); falls back to the
 * build-time DCP_PLATFORM_BASE_URL constant if the override is empty
 * or doesn't look like an http(s) URL.
 */
function dcp_platform_base_url() {
    $opt = trim( (string) get_option( 'dcp_platform_base_url', '' ) );
    if ( $opt !== '' && preg_match( '#^https?://#i', $opt ) ) {
        return rtrim( $opt, '/' );
    }
    return DCP_PLATFORM_BASE_URL;
}

/**
 * DNS bypass for hosts whose resolver can't reach the platform hostname.
 * If a merchant has set the "Platform Endpoint IP" override on the settings
 * page, hook the underlying cURL handle that WP_Http uses and pre-populate
 * CURLOPT_RESOLVE so cURL skips DNS for the platform host and connects
 * straight to the override IP. SNI + certificate validation still use the
 * real hostname, so TLS is not weakened. Only fires for requests whose
 * target host matches the configured platform host — never for anything
 * else WordPress is fetching.
 */
add_action( 'http_api_curl', 'dcp_curl_resolve_platform', 10, 3 );
function dcp_curl_resolve_platform( $handle, $args, $url ) {
    $ip = trim( (string) get_option( 'dcp_platform_endpoint_ip', '' ) );
    if ( $ip === '' || ! filter_var( $ip, FILTER_VALIDATE_IP ) ) {
        return;
    }
    $platform_host = parse_url( dcp_platform_base_url(), PHP_URL_HOST );
    $request_host  = parse_url( (string) $url, PHP_URL_HOST );
    if ( ! $platform_host || ! $request_host || strcasecmp( $platform_host, $request_host ) !== 0 ) {
        return;
    }
    curl_setopt( $handle, CURLOPT_RESOLVE, array(
        $platform_host . ':443:' . $ip,
        $platform_host . ':80:'  . $ip,
    ) );
}

function dcp_register_settings() {
    $options = array(
        // Secrets
        'dcp_store_id', 'dcp_webhook_secret', 'dcp_shiplogic_bearer',
        // Config
        'dcp_platform_base_url',
        'dcp_platform_endpoint_ip',
        // Toggles
        'dcp_enable_live_rates', 'dcp_auto_sync_orders', 'dcp_debug_logging',
    );
    // Default-build only: Account ID + Provider ID are merchant-entered.
    // Branded builds have these pre-baked as constants and never read the
    // option, so we don't register them there.
    if ( dcp_shiplogic_ids_are_editable() ) {
        $options[] = 'dcp_shiplogic_account_id';
        $options[] = 'dcp_shiplogic_provider_id';
    }
    foreach ( $options as $opt ) {
        register_setting( 'dcp_settings', $opt );
    }
}

function dcp_render_settings_page() {
    if ( ! current_user_can( 'manage_woocommerce' ) ) {
        wp_die( __( 'Insufficient permissions.', 'dcp' ) );
    }

    // Handle save.
    if ( isset( $_POST['dcp_save'] ) && check_admin_referer( 'dcp_save_settings' ) ) {
        $secrets = array( 'dcp_store_id', 'dcp_webhook_secret', 'dcp_shiplogic_bearer' );
        foreach ( $secrets as $name ) {
            $val = isset( $_POST[ $name ] ) ? sanitize_text_field( wp_unslash( $_POST[ $name ] ) ) : '';
            dcp_save_secret_option( $name, $val );
        }
        // Account ID + Provider ID are only saved for the default build —
        // branded builds use constants and ignore the option entirely.
        if ( dcp_shiplogic_ids_are_editable() ) {
            foreach ( array( 'dcp_shiplogic_account_id', 'dcp_shiplogic_provider_id' ) as $name ) {
                $val = isset( $_POST[ $name ] ) ? sanitize_text_field( wp_unslash( $_POST[ $name ] ) ) : '';
                update_option( $name, $val );
            }
        }
        // Platform endpoint URL — plain config, sanitize as URL, allow blank
        // (blank means "use the build-time default constant").
        $url_in = isset( $_POST['dcp_platform_base_url'] ) ? trim( wp_unslash( $_POST['dcp_platform_base_url'] ) ) : '';
        if ( $url_in === '' || preg_match( '#^https?://#i', $url_in ) ) {
            update_option( 'dcp_platform_base_url', $url_in === '' ? '' : esc_url_raw( $url_in ) );
        }
        // Platform endpoint IP override (advanced, DNS bypass). Accepts IPv4
        // or IPv6; blank disables. When set, see dcp_curl_resolve_platform().
        $ip_in = isset( $_POST['dcp_platform_endpoint_ip'] ) ? trim( wp_unslash( $_POST['dcp_platform_endpoint_ip'] ) ) : '';
        if ( $ip_in === '' || filter_var( $ip_in, FILTER_VALIDATE_IP ) ) {
            update_option( 'dcp_platform_endpoint_ip', $ip_in );
        }
        $toggles = array( 'dcp_enable_live_rates', 'dcp_auto_sync_orders', 'dcp_debug_logging' );
        foreach ( $toggles as $name ) {
            update_option( $name, isset( $_POST[ $name ] ) ? 'yes' : 'no' );
        }
        // Bust the rate cache so a new Shiplogic token / account takes effect immediately.
        dcp_clear_rate_cache();
        echo '<div class="notice notice-success is-dismissible"><p>Settings saved.</p></div>';
    }

    $ajax_nonce = wp_create_nonce( 'dcp_admin' );
    ?>
    <div class="wrap">
        <h1><span class="dashicons dashicons-airplane" style="font-size:30px;"></span> Delicate Courier Platform</h1>
        <p>Platform endpoint: <code><?php echo esc_html( dcp_platform_base_url() ); ?></code> &middot; Plugin version <?php echo esc_html( DCP_VERSION ); ?></p>

        <form method="post" action="">
            <?php wp_nonce_field( 'dcp_save_settings' ); ?>

            <h2 class="title">Platform credentials</h2>
            <p>These three values come from the Store record in the Delicate Courier admin portal. The Shiplogic token is from your Shiplogic dashboard.</p>
            <table class="form-table" role="presentation">
                <tr><th><label for="dcp_store_id">Store ID</label></th>
                    <td><input name="dcp_store_id" id="dcp_store_id" type="text" class="regular-text" value="<?php echo esc_attr( dcp_store_id() ); ?>" required></td></tr>
                <tr><th><label for="dcp_webhook_secret">Webhook Secret</label></th>
                    <td><input name="dcp_webhook_secret" id="dcp_webhook_secret" type="password" class="regular-text" value="<?php echo esc_attr( dcp_webhook_secret() ); ?>" autocomplete="off" required>
                        <p class="description">Used to HMAC-sign every order pushed to the platform.</p></td></tr>
                <tr><th><label for="dcp_shiplogic_bearer">Shiplogic Bearer Token</label></th>
                    <td><input name="dcp_shiplogic_bearer" id="dcp_shiplogic_bearer" type="password" class="regular-text" value="<?php echo esc_attr( dcp_shiplogic_bearer() ); ?>" autocomplete="off" required>
                        <p class="description">Sent directly to Shiplogic for live rate quotes at checkout.</p></td></tr>
                <?php if ( dcp_shiplogic_ids_are_editable() ) : ?>
                <tr><th><label for="dcp_shiplogic_account_id">Shiplogic Account ID</label></th>
                    <td><input name="dcp_shiplogic_account_id" id="dcp_shiplogic_account_id" type="text" class="regular-text" value="<?php echo esc_attr( dcp_shiplogic_account_id() ); ?>" required>
                        <p class="description">Your numeric Shiplogic account ID. Found in your Shiplogic dashboard. Required for live rate quotes.</p></td></tr>
                <tr><th><label for="dcp_shiplogic_provider_id">Shiplogic Provider ID</label></th>
                    <td><input name="dcp_shiplogic_provider_id" id="dcp_shiplogic_provider_id" type="text" class="regular-text" value="<?php echo esc_attr( dcp_shiplogic_provider_id() ); ?>" required>
                        <p class="description">The numeric ID of the Shiplogic courier provider you want to quote. Required for live rate quotes.</p></td></tr>
                <?php endif; ?>
                <tr><th><label for="dcp_platform_base_url">Platform Endpoint URL <em>(optional)</em></label></th>
                    <td><input name="dcp_platform_base_url" id="dcp_platform_base_url" type="url" class="regular-text" value="<?php echo esc_attr( get_option( 'dcp_platform_base_url', '' ) ); ?>" placeholder="<?php echo esc_attr( DCP_PLATFORM_BASE_URL ); ?>">
                        <p class="description">Leave blank to use the default (<code><?php echo esc_html( DCP_PLATFORM_BASE_URL ); ?></code>). Only change this if instructed by your platform administrator &mdash; e.g. to point at staging, or as a fallback while DNS for the custom domain propagates.</p></td></tr>
                <tr><th><label for="dcp_platform_endpoint_ip">Platform Endpoint IP <em>(advanced &mdash; DNS bypass)</em></label></th>
                    <td><input name="dcp_platform_endpoint_ip" id="dcp_platform_endpoint_ip" type="text" class="regular-text" value="<?php echo esc_attr( get_option( 'dcp_platform_endpoint_ip', '' ) ); ?>" placeholder="e.g. 34.111.179.208">
                        <p class="description"><strong>Leave blank unless your server cannot resolve the platform hostname via DNS.</strong> When set, the plugin tells cURL to connect directly to this IP for the platform host above, skipping DNS entirely. TLS (SNI &amp; certificate validation) still uses the hostname, so the connection stays secure. The IP is not contractually stable &mdash; treat this as a temporary workaround while your hosting provider fixes their DNS.</p></td></tr>
            </table>

            <h2 class="title">Behaviour</h2>
            <table class="form-table" role="presentation">
                <tr><th>Live rates at checkout</th>
                    <td><label><input type="checkbox" name="dcp_enable_live_rates" <?php checked( dcp_live_rates_enabled() ); ?>> Enable</label></td></tr>
                <tr><th>Auto-sync orders to platform</th>
                    <td><label><input type="checkbox" name="dcp_auto_sync_orders" <?php checked( dcp_auto_sync_enabled() ); ?>> Enable</label></td></tr>
                <tr><th>Debug logging</th>
                    <td><label><input type="checkbox" name="dcp_debug_logging" <?php checked( dcp_debug_enabled() ); ?>> Enable</label>
                        <p class="description">Keeps the last 200 events in the database. View them at the bottom of this page.</p></td></tr>
            </table>

            <p class="submit"><button type="submit" name="dcp_save" class="button button-primary">Save changes</button></p>
        </form>

        <hr>
        <h2>Pre-configured values (read-only)</h2>
        <p class="description">These values are derived from this plugin build or from your WooCommerce store address. To change them, override with a small code snippet using the documented filters, or ask your platform administrator for a custom-branded plugin build.</p>
        <?php $addr = dcp_collection_address(); ?>
        <table class="form-table" role="presentation">
            <?php if ( ! dcp_shiplogic_ids_are_editable() ) : ?>
            <tr><th>Shiplogic Account ID</th><td><code><?php echo esc_html( dcp_shiplogic_account_id() ?: '(not set)' ); ?></code></td></tr>
            <tr><th>Shiplogic Provider ID</th><td><code><?php echo esc_html( dcp_shiplogic_provider_id() ?: '(not set)' ); ?></code></td></tr>
            <?php endif; ?>
            <tr><th>Service Level Code</th><td><code><?php echo esc_html( dcp_service_level_code() ); ?></code></td></tr>
            <tr><th>Collection address</th><td>
                <code><?php echo esc_html( trim( ($addr['company'] ?? '') . ', ' . ($addr['street_address'] ?? '') . ', ' . ($addr['city'] ?? '') . ' ' . ($addr['code'] ?? '') . ', ' . ($addr['country'] ?? ''), ', ' ) ); ?></code>
                <?php if ( ! DCP_DEFAULT_COLLECTION_STREET ) : ?><p class="description">Falls back to your WooCommerce store address (Settings → General).</p><?php endif; ?>
            </td></tr>
        </table>

        <hr>
        <h2>Connection tests</h2>
        <p>
            <button type="button" class="button" id="dcp-test-health">Test platform connection</button>
            <button type="button" class="button" id="dcp-test-order">Send signed test order</button>
            <button type="button" class="button" id="dcp-test-rates">Test Shiplogic rates</button>
        </p>
        <pre id="dcp-test-output" style="background:#1d2327;color:#e3e7ee;padding:12px;border-radius:4px;min-height:80px;white-space:pre-wrap;"></pre>

        <hr>
        <h2>Debug log</h2>
        <p>
            <button type="button" class="button" id="dcp-clear-logs">Clear log</button>
        </p>
        <table class="widefat striped" style="max-width:1200px;">
            <thead><tr><th style="width:160px;">Time</th><th style="width:70px;">Level</th><th style="width:170px;">Context</th><th>Detail</th></tr></thead>
            <tbody>
            <?php
            $logs = get_option( 'dcp_debug_logs', array() );
            if ( empty( $logs ) ) {
                echo '<tr><td colspan="4"><em>No log entries.</em></td></tr>';
            } else {
                foreach ( array_reverse( $logs ) as $row ) {
                    echo '<tr>';
                    echo '<td>' . esc_html( $row['time'] ?? '' ) . '</td>';
                    echo '<td>' . esc_html( $row['level'] ?? '' ) . '</td>';
                    echo '<td>' . esc_html( $row['context'] ?? '' ) . '</td>';
                    echo '<td><code>' . esc_html( $row['detail'] ?? '' ) . '</code></td>';
                    echo '</tr>';
                }
            }
            ?>
            </tbody>
        </table>
    </div>

    <script>
    (function(){
        var nonce = '<?php echo esc_js( $ajax_nonce ); ?>';
        var out = document.getElementById('dcp-test-output');
        function run(action, label){
            out.textContent = label + '...';
            var fd = new FormData();
            fd.append('action', action);
            fd.append('_ajax_nonce', nonce);
            fetch(ajaxurl, { method:'POST', credentials:'same-origin', body: fd })
                .then(function(r){ return r.json(); })
                .then(function(j){ out.textContent = JSON.stringify(j, null, 2); })
                .catch(function(e){ out.textContent = 'Request failed: ' + e; });
        }
        document.getElementById('dcp-test-health').addEventListener('click', function(){ run('dcp_test_platform_health', 'Pinging platform'); });
        document.getElementById('dcp-test-order').addEventListener('click', function(){ run('dcp_test_platform_order', 'Sending signed test order'); });
        document.getElementById('dcp-test-rates').addEventListener('click', function(){ run('dcp_test_shiplogic_rates', 'Requesting Shiplogic rates'); });
        document.getElementById('dcp-clear-logs').addEventListener('click', function(){
            if (!confirm('Clear the debug log?')) return;
            run('dcp_clear_debug_logs', 'Clearing log');
            setTimeout(function(){ location.reload(); }, 600);
        });
    })();
    </script>
    <?php
}

/* ============================================================================
 * AJAX HANDLERS
 * ========================================================================== */

function dcp_check_ajax() {
    check_ajax_referer( 'dcp_admin' );
    if ( ! current_user_can( 'manage_woocommerce' ) ) {
        wp_send_json_error( array( 'message' => 'Insufficient permissions.' ), 403 );
    }
}

function dcp_ajax_test_platform_health() {
    dcp_check_ajax();
    $resp = dcp_platform_get( DCP_PLATFORM_HEALTH_PATH );
    wp_send_json( $resp );
}

function dcp_ajax_test_platform_order() {
    dcp_check_ajax();
    if ( ! dcp_is_configured() ) {
        wp_send_json( array( 'success' => false, 'status' => 0, 'body' => array( 'message' => 'Store ID and Webhook Secret are required first.' ) ) );
    }
    $payload = array(
        'event'           => 'order.test',
        'woo_order_id'    => 999999,
        'order_number'    => 'TEST-' . wp_generate_password( 6, false, false ),
        'status'          => 'processing',
        'total'           => 100.00,
        'shipping_total'  => 0,
        'currency'        => get_woocommerce_currency(),
        'payment_method'  => 'test',
        'date_created'    => current_time( 'mysql' ),
        'customer_note'   => 'Plugin connectivity test',
        'customer'        => array(
            'name'  => 'Plugin Test Customer',
            'email' => 'test@example.com',
            'phone' => '0820000000',
        ),
        'shipping_address' => array(
            'street'   => '1 Test Street',
            'suburb'   => 'Test Suburb',
            'city'     => 'Pretoria',
            'state'    => 'Gauteng',
            'postcode' => '0001',
            'country'  => 'ZA',
        ),
        'line_items' => array( array(
            'id' => 1, 'product_id' => 1, 'name' => 'Test product', 'quantity' => 1, 'price' => 100.00, 'sku' => 'TEST',
        ) ),
        'total_weight'    => 1,
        'store_url'       => home_url(),
        'store_id'        => dcp_store_id(),
        'delivery_date'   => null,
        'delivery_time'   => null,
        'collection_date' => null,
        'collection_time' => null,
        'occasion'        => null,
    );
    $resp = dcp_platform_post_signed( DCP_PLATFORM_ORDER_PATH, $payload );
    wp_send_json( $resp );
}

function dcp_ajax_test_shiplogic_rates() {
    dcp_check_ajax();
    $bearer = dcp_shiplogic_bearer();
    if ( $bearer === '' ) {
        wp_send_json( array( 'success' => false, 'status' => 0, 'body' => array( 'message' => 'Shiplogic Bearer Token is required first.' ) ) );
    }
    $payload = array(
        'account_id'         => is_numeric( dcp_shiplogic_account_id() ) ? intval( dcp_shiplogic_account_id() ) : dcp_shiplogic_account_id(),
        'provider_id'        => is_numeric( dcp_shiplogic_provider_id() ) ? intval( dcp_shiplogic_provider_id() ) : dcp_shiplogic_provider_id(),
        'service_level_code' => dcp_service_level_code(),
        'collection_address' => dcp_collection_address(),
        'delivery_address'   => array(
            'type'           => 'residential',
            'company'        => null,
            'street_address' => '1 Test Street',
            'local_area'     => '',
            'city'           => 'Johannesburg',
            'zone'           => 'Gauteng',
            'code'           => '2000',
            'country'        => 'ZA',
            'lat'            => null,
            'lng'            => null,
            'contact'        => array( 'name' => 'Test', 'mobile_number' => null, 'email' => null ),
        ),
        'parcels' => array( array(
            'parcel_description'  => 'Test Parcel',
            'submitted_length_cm' => 20,
            'submitted_width_cm'  => 15,
            'submitted_height_cm' => 10,
            'submitted_weight_kg' => 1,
        ) ),
    );
    $rates = dcp_shiplogic_fetch_rates( $bearer, $payload );
    if ( is_wp_error( $rates ) ) {
        wp_send_json( array( 'success' => false, 'status' => 0, 'body' => array( 'message' => $rates->get_error_message() ) ) );
    }
    wp_send_json( array( 'success' => true, 'status' => 200, 'body' => array( 'rates' => $rates ) ) );
}

function dcp_ajax_clear_debug_logs() {
    dcp_check_ajax();
    update_option( 'dcp_debug_logs', array(), false );
    wp_send_json( array( 'success' => true ) );
}

/* ============================================================================
 * ORDER METABOX — show platform sync status
 * ========================================================================== */

function dcp_register_order_meta_box() {
    $screen = class_exists( '\Automattic\WooCommerce\Internal\DataStores\Orders\CustomOrdersTableController' )
        && wc_get_container()->get( \Automattic\WooCommerce\Internal\DataStores\Orders\CustomOrdersTableController::class )->custom_orders_table_usage_is_enabled()
        ? wc_get_page_screen_id( 'shop-order' )
        : 'shop_order';

    add_meta_box( 'dcp_order_sync', 'Delicate Courier', 'dcp_render_order_meta_box', $screen, 'side', 'default' );
}

function dcp_render_order_meta_box( $post_or_order ) {
    $order = ( $post_or_order instanceof WP_Post ) ? wc_get_order( $post_or_order->ID ) : $post_or_order;
    if ( ! $order ) {
        echo '<em>Order not found.</em>';
        return;
    }
    $platform_id = $order->get_meta( '_dcp_platform_order_id' );
    $synced_at   = $order->get_meta( '_dcp_synced_at' );
    ?>
    <p><strong>Platform ID:</strong> <?php echo $platform_id ? esc_html( $platform_id ) : '<em>not synced</em>'; ?></p>
    <p><strong>Synced at:</strong> <?php echo $synced_at ? esc_html( $synced_at ) : '—'; ?></p>
    <?php if ( ! $platform_id ) : ?>
        <p><a class="button button-secondary" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=dcp_manual_sync&order_id=' . $order->get_id() ), 'dcp_manual_sync_' . $order->get_id() ) ); ?>">Sync to platform now</a></p>
    <?php endif;
}

add_action( 'admin_post_dcp_manual_sync', function() {
    $order_id = isset( $_GET['order_id'] ) ? intval( $_GET['order_id'] ) : 0;
    if ( ! $order_id || ! current_user_can( 'manage_woocommerce' ) ) {
        wp_die( 'Forbidden' );
    }
    check_admin_referer( 'dcp_manual_sync_' . $order_id );
    dcp_sync_order( $order_id );
    wp_safe_redirect( wp_get_referer() ?: admin_url() );
    exit;
} );
